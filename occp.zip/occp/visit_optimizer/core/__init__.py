"""
core/__init__.py
core 层：注册表 + 调度器 + 基类（Context、约束、Pipeline、BaseBrand）
"""
from .registry import (
    Registry, ALGORITHM_REGISTRY, CONSTRAINT_REGISTRY,
    EVALUATOR_REGISTRY, BRAND_REGISTRY, PIPELINE_STEP_REGISTRY,
)
from .scheduler import BrandProblem, MultiBrandScheduler
from .base import (
    Context,
    HardConstraint, SoftConstraint, BaseBrand,
    PipelineStep, Pipeline,
)

__all__ = [
    "Registry",
    "ALGORITHM_REGISTRY", "CONSTRAINT_REGISTRY", "EVALUATOR_REGISTRY", "BRAND_REGISTRY",
    "PIPELINE_STEP_REGISTRY",
    "BrandProblem", "MultiBrandScheduler",
    "Context",
    "HardConstraint", "SoftConstraint", "BaseBrand",
    "PipelineStep", "Pipeline",
]
