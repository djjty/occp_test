"""
core/tracking.py — MLflow 优化过程记录 + task_id 存库

功能：
  1. MLflow 记录：每次优化的 params, metrics(fitness history), artifacts(genes)
  2. task_id 生成（UUID4）并持久化到 SQLite 任务表
  3. 可选：完全降级（无 mlflow 时仅打日志）

用法：
    tracker = OptimizationTracker(experiment="visit_opt", db_path="tasks.db")
    with tracker.start_run(brand_id="brand_a", task_id=problem.task_id, config=cfg):
        result = problem.solve()
        tracker.log_result(result)
"""
from __future__ import annotations
import logging
import os
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import mlflow
    _HAS_MLFLOW = True
except Exception:
    _HAS_MLFLOW = False
    logger.warning("mlflow not available; tracking disabled.")


# ─────────────────────────────────────────────────────────────────────────────
# Task 数据库（SQLite，异步写入见 io/async_db.py）
# ─────────────────────────────────────────────────────────────────────────────

_CREATE_TASK_TABLE = """
CREATE TABLE IF NOT EXISTS optimization_tasks (
    task_id     TEXT PRIMARY KEY,
    brand_id    TEXT NOT NULL,
    algo        TEXT,
    status      TEXT DEFAULT 'running',
    best_fitness REAL,
    n_iters     INTEGER,
    elapsed_sec REAL,
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
);
"""


class TaskStore:
    """轻量级 SQLite 任务存储（同步版，异步版见 io/async_db.py）"""

    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(_CREATE_TASK_TABLE)

    def upsert_task(self, task_id: str, brand_id: str, algo: str = "",
                    status: str = "running", best_fitness: float = float("nan"),
                    n_iters: int = 0, elapsed_sec: float = 0.0):
        sql = """
        INSERT INTO optimization_tasks
            (task_id, brand_id, algo, status, best_fitness, n_iters, elapsed_sec, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
        ON CONFLICT(task_id) DO UPDATE SET
            status=excluded.status,
            best_fitness=excluded.best_fitness,
            n_iters=excluded.n_iters,
            elapsed_sec=excluded.elapsed_sec,
            updated_at=datetime('now')
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(sql, (task_id, brand_id, algo, status,
                               best_fitness, n_iters, elapsed_sec))

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM optimization_tasks WHERE task_id=?", (task_id,)
            ).fetchone()
        if row is None:
            return None
        cols = ["task_id","brand_id","algo","status","best_fitness",
                "n_iters","elapsed_sec","created_at","updated_at"]
        return dict(zip(cols, row))


# ─────────────────────────────────────────────────────────────────────────────
# OptimizationTracker
# ─────────────────────────────────────────────────────────────────────────────

class OptimizationTracker:
    """
    统一追踪器：MLflow + SQLite task 表。

    参数：
        experiment  str   MLflow 实验名，默认 "visit_optimizer"
        tracking_uri str  MLflow tracking server URI，默认本地文件
        db_path     str   SQLite 任务库路径
    """

    def __init__(
        self,
        experiment: str = "visit_optimizer",
        tracking_uri: Optional[str] = None,
        db_path: str = "tasks.db",
    ):
        self.experiment = experiment
        self.task_store = TaskStore(db_path)
        if _HAS_MLFLOW:
            if tracking_uri:
                mlflow.set_tracking_uri(tracking_uri)
            mlflow.set_experiment(experiment)

    def new_task_id(self) -> str:
        return str(uuid.uuid4())

    @contextmanager
    def start_run(self, brand_id: str, task_id: Optional[str] = None,
                  config: Optional[Dict[str, Any]] = None,
                  algo: str = ""):
        """
        上下文管理器，包裹一次优化运行：
          - 在 SQLite 中标记 running
          - 启动 MLflow run（若可用）
          - yield，yield 后记录完成状态
        """
        tid = task_id or self.new_task_id()
        self.task_store.upsert_task(tid, brand_id, algo=algo, status="running")

        if _HAS_MLFLOW:
            with mlflow.start_run(run_name=f"{brand_id}_{tid[:8]}"):
                mlflow.set_tags({"brand_id": brand_id, "task_id": tid, "algo": algo})
                if config:
                    # 仅记录可序列化的标量参数
                    flat_cfg = {k: v for k, v in config.items()
                                if isinstance(v, (int, float, str, bool))}
                    mlflow.log_params(flat_cfg)
                try:
                    yield tid
                except Exception as e:
                    self.task_store.upsert_task(tid, brand_id, algo=algo, status="failed")
                    raise
        else:
            try:
                yield tid
            except Exception:
                self.task_store.upsert_task(tid, brand_id, algo=algo, status="failed")
                raise

    def log_result(self, result: Any, task_id: Optional[str] = None) -> None:
        """
        记录优化结果：
          - MLflow metrics（fitness 曲线 + 最终指标）
          - SQLite 更新状态为 completed
        """
        tid = task_id or getattr(result, "task_id", None) or self.new_task_id()
        best_fit = result.best_individual.fitness
        elapsed  = result.extra.get("elapsed_sec", 0.0)
        algo     = result.extra.get("algo", "")

        if _HAS_MLFLOW:
            try:
                # 记录 fitness 曲线
                for step, f in enumerate(result.history):
                    mlflow.log_metric("fitness", f, step=step)
                mlflow.log_metrics({
                    "best_fitness":  best_fit,
                    "best_penalty":  result.best_individual.penalty,
                    "elapsed_sec":   elapsed,
                    "iterations_run": result.iterations_run,
                })
            except Exception as e:
                logger.warning("[Tracker] MLflow log failed: %s", e)

        self.task_store.upsert_task(
            tid, result.brand_id, algo=algo, status="completed",
            best_fitness=best_fit, n_iters=result.iterations_run, elapsed_sec=elapsed,
        )
        logger.info("[Tracker] task_id=%s brand=%s fitness=%.4f saved",
                    tid, result.brand_id, best_fit)
