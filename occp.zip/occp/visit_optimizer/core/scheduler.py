"""
core/scheduler.py — MultiBrandScheduler + BrandProblem

BrandProblem 封装单品牌的优化任务（data+constraints+fitness+optimizer）。
支持 Pipeline 集成：输入/输出 Pipeline 自动执行。
MultiBrandScheduler 管理多品牌任务，支持串行/并行/异步三种模式。
"""
from __future__ import annotations
import asyncio
import logging
import uuid
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# BrandProblem — 单品牌优化问题封装
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BrandProblem:
    """
    封装单品牌的完整优化问题：
      data       → Context（通过 input Pipeline 构建）
      constraints → (hard, soft)
      fitness    → BaseFitnessEvaluator
      optimizer  → BaseOptimizer

    通常通过 BrandProblem.from_brand() 工厂方法创建。

    Pipeline 集成：
      如果品牌声明了 input_pipeline_steps，from_brand() 会自动运行输入 Pipeline。
      solve() 之后可以调用 run_output_pipeline() 运行输出 Pipeline。
    """
    brand_id: str
    ctx: Any             # Context
    hard: List[Any]      # List[HardConstraint]
    soft: List[Any]      # List[SoftConstraint]
    evaluator: Any       # BaseFitnessEvaluator
    optimizer: Any       # BaseOptimizer
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    meta: Dict[str, Any] = field(default_factory=dict)
    #: 保存 input_pipeline 运行后的 Context（供输出 Pipeline 复用）
    _input_ctx: Any = field(default=None, repr=False)
    #: 品牌实例引用（用于输出 Pipeline）
    _brand: Any = field(default=None, repr=False)

    @classmethod
    def from_brand(cls, brand_id: str, raw: Dict[str, Any],
                   algo_override: Optional[Dict[str, Any]] = None) -> "BrandProblem":
        """
        工厂方法：从注册表构建完整 BrandProblem。

        如果品牌声明了 input_pipeline_steps，会自动运行输入 Pipeline。
        """
        from ..core.registry import BRAND_REGISTRY, ALGORITHM_REGISTRY
        brand = BRAND_REGISTRY.build(brand_id)

        # ── 输入 Pipeline（如果品牌声明了步骤）───────────────────────────────
        input_ctx = None
        if hasattr(brand, 'input_pipeline_steps') and brand.input_pipeline_steps:
            from ..core.base import Pipeline, Context
            from ..constraints.common.common_input import make_input_context
            pipeline = Pipeline(brand.input_pipeline_steps)
            input_ctx = pipeline.run(make_input_context(raw))
            # 品牌从 pipeline context 构建 Context
            ctx = brand._build_context_from_pipeline(input_ctx)
        else:
            # 直接构造（无 Pipeline 的品牌）
            ctx = brand.build_context(raw)

        hard = brand.get_hard_constraints()
        soft = brand.get_soft_constraints(ctx)
        evaluator = brand.get_fitness_evaluator()
        cfg = {**brand.get_algorithm_config(), **(algo_override or {})}
        optimizer = ALGORITHM_REGISTRY.build(brand.get_algorithm_key(), config=cfg)

        return cls(
            brand_id=brand_id, ctx=ctx, hard=hard, soft=soft,
            evaluator=evaluator, optimizer=optimizer,
            _input_ctx=input_ctx,
            _brand=brand,
        )

    def solve(self) -> Any:  # OptimizationResult
        """执行优化，注入 task_id"""
        logger.info("[Problem][%s] task_id=%s start", self.brand_id, self.task_id)
        result = self.optimizer.optimize(self.ctx, self.evaluator, self.hard, self.soft)
        result.task_id = self.task_id
        logger.info("[Problem][%s] task_id=%s done fit=%.4f",
                    self.brand_id, self.task_id, result.best_individual.fitness)
        return result

    def run_output_pipeline(
        self,
        result: OptimizationResult,
        channels: Optional[List[str]] = None,
    ) -> Any:
        """
        运行品牌的输出 Pipeline。
        返回 Context（包含 output_rows 等数据）。
        如果品牌未声明 output_pipeline_steps，返回 None。
        """
        if self._brand is None:
            return None
        return self._brand.build_output(result, channels)


# ─────────────────────────────────────────────────────────────────────────────
# MultiBrandScheduler — 多品牌任务调度器
# ─────────────────────────────────────────────────────────────────────────────

class MultiBrandScheduler:
    """
    多品牌优化调度器。

    支持三种执行模式：
      - serial   : 逐个品牌串行执行（默认，调试友好）
      - thread   : 多线程并行（IO 密集型，适合评估器已向量化的场景）
      - process  : 多进程并行（CPU 密集型，绕过 GIL）
      - async    : asyncio 异步（适合评估器有异步 IO 的场景）

    用法：
        problems = [BrandProblem.from_brand("brand_a", raw_a),
                    BrandProblem.from_brand("brand_b", raw_b)]
        scheduler = MultiBrandScheduler(problems, mode="thread", max_workers=4)
        results = scheduler.run()          # dict: brand_id -> OptimizationResult
    """

    MODES = ("serial", "thread", "process", "async")

    def __init__(
        self,
        problems: List[BrandProblem],
        mode: str = "serial",
        max_workers: int = 4,
        on_complete: Optional[Callable[[str, Any], None]] = None,
    ):
        if mode not in self.MODES:
            raise ValueError(f"mode must be one of {self.MODES}, got {mode!r}")
        self.problems = problems
        self.mode = mode
        self.max_workers = max_workers
        self.on_complete = on_complete  # 回调：(brand_id, result) -> None

    # ── 串行 ──────────────────────────────────────────────────────────────────
    def _run_serial(self) -> Dict[str, Any]:
        results = {}
        for p in self.problems:
            try:
                r = p.solve()
                results[p.brand_id] = r
                if self.on_complete:
                    self.on_complete(p.brand_id, r)
            except Exception as e:
                logger.error("[Scheduler] %s failed: %s", p.brand_id, e, exc_info=True)
        return results

    # ── 线程池 ────────────────────────────────────────────────────────────────
    def _run_thread(self) -> Dict[str, Any]:
        results = {}
        with ThreadPoolExecutor(max_workers=self.max_workers) as ex:
            futures = {ex.submit(p.solve): p.brand_id for p in self.problems}
            for f in as_completed(futures):
                bid = futures[f]
                try:
                    r = f.result()
                    results[bid] = r
                    if self.on_complete:
                        self.on_complete(bid, r)
                except Exception as e:
                    logger.error("[Scheduler] thread %s failed: %s", bid, e, exc_info=True)
        return results

    # ── 进程池 ────────────────────────────────────────────────────────────────
    def _run_process(self) -> Dict[str, Any]:
        results = {}
        with ProcessPoolExecutor(max_workers=self.max_workers) as ex:
            futures = {ex.submit(p.solve): p.brand_id for p in self.problems}
            for f in as_completed(futures):
                bid = futures[f]
                try:
                    r = f.result()
                    results[bid] = r
                    if self.on_complete:
                        self.on_complete(bid, r)
                except Exception as e:
                    logger.error("[Scheduler] process %s failed: %s", bid, e, exc_info=True)
        return results

    # ── asyncio ───────────────────────────────────────────────────────────────
    async def _run_async_inner(self) -> Dict[str, Any]:
        loop = asyncio.get_event_loop()
        results = {}

        async def _run_one(p: BrandProblem):
            r = await loop.run_in_executor(None, p.solve)
            results[p.brand_id] = r
            if self.on_complete:
                self.on_complete(p.brand_id, r)

        await asyncio.gather(*[_run_one(p) for p in self.problems])
        return results

    def run_async(self) -> Dict[str, Any]:
        """异步模式入口（在同步上下文调用）"""
        return asyncio.run(self._run_async_inner())

    # ── 统一入口 ──────────────────────────────────────────────────────────────
    def run(self) -> Dict[str, Any]:
        """
        执行所有品牌优化任务。
        返回 {brand_id: OptimizationResult}
        """
        logger.info("[Scheduler] mode=%s n_problems=%d", self.mode, len(self.problems))
        dispatch = {
            "serial":  self._run_serial,
            "thread":  self._run_thread,
            "process": self._run_process,
            "async":   self.run_async,
        }
        return dispatch[self.mode]()
