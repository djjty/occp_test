"""
core/base.py — 核心基类（实际定义）

包含：
  - Context（统一上下文：数据库读写、数据处理、优化全流程）
  - HardConstraint, SoftConstraint（所有约束的基类）
  - BaseBrand（品牌定义基类，声明式 Pipeline 集成）
  - PipelineStep, Pipeline（Pipeline 基础设施）

说明：
  - BaseFitnessEvaluator, BaseOptimizer 在 optimizer/algorithms/base.py
  - Individual, OptimizationResult 在 optimizer/types.py（从 core.base 导入 Context）
"""
from __future__ import annotations

import logging
from abc import ABCMeta, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np

from .registry import PIPELINE_STEP_REGISTRY

logger = logging.getLogger(__name__)


# ═════════════════════════════════════════════════════════════════════════════
# Context — 统一上下文
# ═════════════════════════════════════════════════════════════════════════════

class Context:
    """
    统一上下文：贯穿数据库读写、数据处理、优化全流程。

    功能：
      - dict 风格访问：ctx["key"]、ctx.get(key)、ctx.require(key)
      - 品牌属性：brand_id, channels, bounds, shared, extra
      - 便捷属性：n_reps, n_hcps, n_channels, shape, lo, hi
      - 导出方法：to_shared_dict(), to_raw_dict()

    构造方式：
      1. 数据处理 Pipeline 中：Context(initial={"raw": raw_dict})
      2. 优化流程中：Context(brand_id=..., channels=..., bounds=..., shared=...)
      3. 输出 Pipeline 中：Context(initial={result=..., channels=...})
    """

    def __init__(
        self,
        brand_id: str = "",
        channels: Optional[List[str]] = None,
        bounds: Optional[np.ndarray] = None,
        shared: Optional[Dict[str, Any]] = None,
        extra: Optional[Dict[str, Any]] = None,
        initial: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.brand_id: str = brand_id
        self.channels: List[str] = channels or []
        self.bounds: np.ndarray = bounds if bounds is not None else np.zeros((0, 0, 0, 2), dtype=np.int32)
        self.shared: Dict[str, Any] = shared if shared is not None else {}
        self.extra: Dict[str, Any] = extra if extra is not None else {}
        self._data: Dict[str, Any] = dict(initial or {})

    # ── dict 风格访问 ──────────────────────────────────────────────────
    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> "Context":
        self._data[key] = value
        return self

    def update(self, d: Dict[str, Any]) -> "Context":
        self._data.update(d)
        return self

    def require(self, key: str) -> Any:
        if key not in self._data:
            raise KeyError(
                f"[Context] Required key '{key}' not found. "
                f"Available: {sorted(self._data.keys())}"
            )
        return self._data[key]

    def keys(self):
        return self._data.keys()

    # ── 品牌属性 ──────────────────────────────────────────────────────
    @property
    def n_reps(self) -> int: return self.bounds.shape[0]

    @property
    def n_hcps(self) -> int: return self.bounds.shape[1]

    @property
    def n_channels(self) -> int: return len(self.channels)

    @property
    def shape(self) -> Tuple[int, int, int]:
        return (self.n_reps, self.n_hcps, self.n_channels)

    @property
    def lo(self) -> np.ndarray: return self.bounds[..., 0]

    @property
    def hi(self) -> np.ndarray: return self.bounds[..., 1]

    @property
    def hi_max_safe(self) -> int:
        """安全上限：用于归一化等场景。当 per-gene bounds 未设限时
        回退到合理值，避免 int32 溢出。"""
        m = int(self.hi.max())
        if m > 1_000_000:
            return 1_000_000
        return m

    # ── 导出方法 ──────────────────────────────────────────────────────
    def to_raw_dict(self) -> Dict[str, Any]:
        return dict(self._data)

    def to_shared_dict(self, keys: Optional[List[str]] = None) -> Dict[str, Any]:
        if keys is not None:
            return {k: self._data[k] for k in keys if k in self._data}
        return {k: v for k, v in self._data.items() if k != "raw"}

    def __repr__(self) -> str:
        return (f"Context(brand_id={self.brand_id!r}, "
                f"shape={self.shape if self.bounds.size > 0 else ()}, "
                f"keys={sorted(self._data.keys())})")


# ═════════════════════════════════════════════════════════════════════════════
# Pipeline 基础设施
# ═════════════════════════════════════════════════════════════════════════════

class PipelineStep(metaclass=ABCMeta):
    """
    管道单步处理基类。

    子类必须实现 ``process(ctx) -> Context``。
    步骤通过 @PIPELINE_STEP_REGISTRY.register("key") 注册。
    """
    name: str = ""

    @abstractmethod
    def process(self, ctx: Context) -> Context:
        """执行本步骤，从 ctx 读取输入、向 ctx 写入输出，返回 ctx。"""
        ...

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name!r})"


_StepSpec = Union[
    PipelineStep,
    Tuple[str, PipelineStep],
    str,  # 注册键，由 run() 时动态解析
]


class Pipeline:
    """
    有序步骤管道。
    步骤列表：PipelineStep 实例 | (label, PipelineStep) | 注册键字符串
    """
    def __init__(self, steps: List[_StepSpec]) -> None:
        self._steps: List[Tuple[str, Any]] = []
        for s in steps:
            if isinstance(s, PipelineStep):
                self._steps.append((s.name or s.__class__.__name__, s))
            elif isinstance(s, tuple) and len(s) == 2:
                label, step = s
                self._steps.append((label, step))
            elif isinstance(s, str):
                self._steps.append((s, s))  # type: ignore[arg-type]
            else:
                raise TypeError(f"Invalid step spec: {s!r}")

    def run(self, ctx: Context) -> Context:
        for label, step_or_key in self._steps:
            if isinstance(step_or_key, str):
                step: PipelineStep = PIPELINE_STEP_REGISTRY.build(step_or_key)
            else:
                step = step_or_key

            logger.debug("[Pipeline] running step: %s", label)
            try:
                ctx = step.process(ctx)
            except Exception as exc:
                raise RuntimeError(
                    f"[Pipeline] step '{label}' failed: {exc}"
                ) from exc
            logger.debug("[Pipeline] step '%s' done. ctx keys: %s",
                         label, sorted(ctx.keys()))
        return ctx

    def __len__(self) -> int:
        return len(self._steps)

    def __repr__(self) -> str:
        names = [lbl for lbl, _ in self._steps]
        return f"Pipeline(steps={names})"

    @classmethod
    def from_keys(cls, keys: List[str]) -> "Pipeline":
        return cls(keys)

    def append(self, step: PipelineStep, label: Optional[str] = None) -> "Pipeline":
        new_steps = list(self._steps) + [(label or step.name or step.__class__.__name__, step)]
        p = Pipeline.__new__(Pipeline)
        p._steps = new_steps
        return p

    def prepend(self, step: PipelineStep, label: Optional[str] = None) -> "Pipeline":
        new_steps = [(label or step.name or step.__class__.__name__, step)] + list(self._steps)
        p = Pipeline.__new__(Pipeline)
        p._steps = new_steps
        return p


# ═════════════════════════════════════════════════════════════════════════════
# 约束基类
# ═════════════════════════════════════════════════════════════════════════════

class HardConstraint(metaclass=ABCMeta):
    """硬约束：check() 返回 False 时个体被拒绝，触发修复/重采样"""
    constraint_type = "hard"
    description: str = ""

    @abstractmethod
    def check(self, ind: Any, ctx: Any) -> bool: ...

    def repair(self, genes: np.ndarray, ctx: Any,
               rng: np.random.Generator) -> np.ndarray:
        """可选修复钩子：子类覆盖以提供启发式修复，减少随机重试"""
        return genes


class SoftConstraint(metaclass=ABCMeta):
    """
    软约束：penalty() 返回归一化惩罚值 [0, 1]。
    各约束先各自归一化，再乘以 weight 汇总。
    """
    constraint_type = "soft"
    description: str = ""
    weight: float = 1.0

    @abstractmethod
    def raw_penalty(self, ind: Any, ctx: Any) -> float:
        """返回原始惩罚值（未归一化）"""
        ...

    def normalize(self, raw: float, ctx: Any) -> float:
        """归一化到 [0, 1]，子类可覆盖"""
        ref = float(np.prod(ctx.shape)) * float(ctx.hi_max_safe - ctx.lo.min() + 1)
        return raw / (ref + 1e-9)

    def penalty(self, ind: Any, ctx: Any) -> float:
        """归一化后乘以权重，供 fitness 评估器使用"""
        return self.weight * self.normalize(self.raw_penalty(ind, ctx), ctx)


# ═════════════════════════════════════════════════════════════════════════════
# BaseBrand — 品牌定义基类
# ═════════════════════════════════════════════════════════════════════════════

_PipelineStepSpec = Union[
    PipelineStep,
    str,
    tuple,
]


class BaseBrand(metaclass=ABCMeta):
    """
    品牌定义基类：声明约束、评估器、算法配置，以及数据读写逻辑。

    Pipeline 集成：
      子类通过 input_pipeline_steps / output_pipeline_steps 声明步骤。
      步骤使用统一的 Context。
    """
    brand_id: str = NotImplemented
    input_pipeline_steps: Optional[List[_PipelineStepSpec]] = None
    output_pipeline_steps: Optional[List[_PipelineStepSpec]] = None

    @abstractmethod
    def build_context(self, raw: Dict[str, Any]) -> Context:
        """构建 Context（从 Pipeline 或直接构造）"""
        ...

    @abstractmethod
    def get_hard_constraints(self) -> List[HardConstraint]: ...

    @abstractmethod
    def get_soft_constraints(self, ctx: Any) -> List[SoftConstraint]: ...

    @abstractmethod
    def get_fitness_evaluator(self) -> Any:
        """返回 BaseFitnessEvaluator 实例"""
        ...

    def get_algorithm_key(self) -> str: return "ga"
    def get_algorithm_config(self) -> Dict[str, Any]: return {}

    # ── Pipeline 集成方法 ──────────────────────────────────────────────

    def _build_context_from_pipeline(
        self, ctx: Context
    ) -> Context:
        """
        从 Pipeline 上下文构建 Context（最终优化用的）。
        子类覆盖此方法，从 ctx 中提取 bounds/shared/extra 等。
        """
        raise NotImplementedError(
            f"{self.__class__.__name__}: 声明了 input_pipeline_steps 但未实现 "
            "_build_context_from_pipeline(ctx)"
        )

    def build_output(
        self,
        result: Any,
        channels: Optional[List[str]] = None,
    ) -> Optional[Context]:
        """运行输出 Pipeline 处理优化结果。"""
        if not self.output_pipeline_steps:
            return None

        pipeline = Pipeline(self.output_pipeline_steps)
        out_ctx = Context(initial={
            "result": result,
            "channels": channels or [],
            "brand_id": self.brand_id,
            "task_id": result.task_id or "",
        })
        return pipeline.run(out_ctx)
