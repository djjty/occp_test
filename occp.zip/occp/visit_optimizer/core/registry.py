"""
core/registry.py — 泛型注册表（元编程核心）

所有注册表统一使用 Registry[T] 泛型实现，包括：
  - ALGORITHM_REGISTRY   : 优化算法
  - CONSTRAINT_REGISTRY  : 约束
  - EVALUATOR_REGISTRY   : 评估器
  - BRAND_REGISTRY       : 品牌
  - PIPELINE_STEP_REGISTRY: 数据处理管道步骤（输入/输出均使用此注册表）
"""
from __future__ import annotations
from typing import Dict, Generic, Type, TypeVar
import logging

logger = logging.getLogger(__name__)
T = TypeVar("T")


class Registry(Generic[T]):
    """
    通用注册表：装饰器自动注册，工厂方法统一构建。
    用法：
        REG = Registry("my")
        @REG.register("foo")
        class Foo: ...
        obj = REG.build("foo", **kwargs)
    """

    def __init__(self, name: str) -> None:
        self._name = name
        self._map: Dict[str, Type[T]] = {}

    def register(self, key: str):
        def _deco(cls: Type[T]) -> Type[T]:
            if key in self._map:
                logger.warning("[%s] overwriting '%s'", self._name, key)
            self._map[key] = cls
            cls._registry_key = key  # type: ignore[attr-defined]
            return cls
        return _deco

    def build(self, key: str, *args, **kwargs) -> T:
        if key not in self._map:
            raise KeyError(f"[{self._name}] '{key}' not found. Available: {self.keys()}")
        return self._map[key](*args, **kwargs)

    def get_class(self, key: str) -> Type[T]:
        if key not in self._map:
            raise KeyError(f"[{self._name}] '{key}' not found. Available: {self.keys()}")
        return self._map[key]

    def keys(self): return list(self._map.keys())
    def __contains__(self, k): return k in self._map
    def __repr__(self): return f"Registry(name={self._name!r}, keys={self.keys()})"


# ── 全局注册表 ──────────────────────────────────────────────────────────────
ALGORITHM_REGISTRY: Registry = Registry("algorithm")
CONSTRAINT_REGISTRY: Registry = Registry("constraint")
EVALUATOR_REGISTRY: Registry = Registry("evaluator")
BRAND_REGISTRY: Registry = Registry("brand")
#: Pipeline 步骤注册表（输入/输出步骤统一注册于此，不再有独立的 PipelineStepRegistry）
PIPELINE_STEP_REGISTRY: Registry = Registry("pipeline_step")
