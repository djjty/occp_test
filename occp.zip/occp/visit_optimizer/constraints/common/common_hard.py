"""
constraints/common/common_hard.py — 通用硬约束

命名规范：约束类名以 common_ 开头（通过注册键体现）。
所有约束均可被任意品牌复用。
"""
from __future__ import annotations
from typing import List, Optional
import numpy as np
from ...core.base import HardConstraint, Context
from ...optimizer.types import Individual
from ...core.registry import CONSTRAINT_REGISTRY


@CONSTRAINT_REGISTRY.register("common_hard.bounds")
class CommonHardBounds(HardConstraint):
    """每个 (rep, hcp, channel) 拜访次数必须在 bounds [lo, hi] 范围内"""
    description = "拜访次数在边界范围内"

    def check(self, ind: Individual, ctx: Context) -> bool:
        return bool(np.all(ind.genes >= ctx.lo) and np.all(ind.genes <= ctx.hi))

    def repair(self, genes: np.ndarray, ctx: Context, rng) -> np.ndarray:
        return np.clip(genes, ctx.lo, ctx.hi).astype(np.int32)


@CONSTRAINT_REGISTRY.register("common_hard.rep_workload_range")
class CommonHardRepWorkloadRange(HardConstraint):
    """
    每个 rep 的总工作量（所有 hcp 所有渠道）必须在 [lo_total, hi_total] 范围内。
    lo_total / hi_total 优先从 ctx.shared['rep_workload_bounds'] 读取（per-rep array），
    否则使用构造参数。
    """
    description = "每个 rep 工作量上下限"

    def __init__(self, lo_total: int = 1, hi_total: int = 10000):
        self.lo_total = lo_total
        self.hi_total = hi_total

    def check(self, ind: Individual, ctx: Context) -> bool:
        bounds = ctx.shared.get("rep_workload_bounds")  # shape (n_reps, 2) or None
        totals = ind.genes.sum(axis=(1, 2))              # (n_reps,)
        if bounds is not None:
            lo = bounds[:, 0]
            hi = bounds[:, 1]
        else:
            lo = np.full(ctx.n_reps, self.lo_total)
            hi = np.full(ctx.n_reps, self.hi_total)
        return bool(np.all(totals >= lo) and np.all(totals <= hi))


@CONSTRAINT_REGISTRY.register("common_hard.hcp_workload_range")
class CommonHardHcpWorkloadRange(HardConstraint):
    """
    每个 hcp 被所有 rep 拜访的总次数（所有渠道）必须在 [lo, hi] 范围内。
    优先从 ctx.shared['hcp_workload_bounds'] (shape n_hcps×2) 读取。
    """
    description = "每个 hcp 工作量上下限"

    def __init__(self, lo_total: int = 0, hi_total: int = 99999):
        self.lo_total = lo_total
        self.hi_total = hi_total

    def check(self, ind: Individual, ctx: Context) -> bool:
        bounds = ctx.shared.get("hcp_workload_bounds")  # (n_hcps, 2) or None
        totals = ind.genes.sum(axis=(0, 2))              # (n_hcps,) sum over reps & channels
        if bounds is not None:
            lo, hi = bounds[:, 0], bounds[:, 1]
        else:
            lo = np.full(ctx.n_hcps, self.lo_total)
            hi = np.full(ctx.n_hcps, self.hi_total)
        return bool(np.all(totals >= lo) and np.all(totals <= hi))


@CONSTRAINT_REGISTRY.register("common_hard.total_visits_range")
class CommonHardTotalVisitsRange(HardConstraint):
    """
    全体总拜访次数必须在 [lo_total, hi_total] 范围内。
    优先从 ctx.shared['total_visits_bounds'] = (lo, hi) 读取。
    """
    description = "整体总拜访次数上下限"

    def __init__(self, lo_total: int = 0, hi_total: int = 999999):
        self.lo_total = lo_total
        self.hi_total = hi_total

    def check(self, ind: Individual, ctx: Context) -> bool:
        b = ctx.shared.get("total_visits_bounds")
        lo = b[0] if b else self.lo_total
        hi = b[1] if b else self.hi_total
        total = int(ind.genes.sum())
        return lo <= total <= hi


@CONSTRAINT_REGISTRY.register("common_hard.channel_exclusive")
class CommonHardChannelExclusive(HardConstraint):
    """
    互斥渠道：同一 (rep, hcp) 组合最多只有一个互斥渠道有拜访次数 > 0。
    参数：exclusive_channels list[str]
    """
    description = "互斥渠道不能同时被访问"

    def __init__(self, exclusive_channels: List[str]):
        self.exclusive_channels = exclusive_channels

    def check(self, ind: Individual, ctx: Context) -> bool:
        idxs = [ctx.channels.index(c) for c in self.exclusive_channels if c in ctx.channels]
        if len(idxs) < 2:
            return True
        nonzero = (ind.genes[:, :, idxs] > 0).sum(axis=2)  # (n_reps, n_hcps)
        return bool(np.all(nonzero <= 1))

    def repair(self, genes: np.ndarray, ctx: Context, rng) -> np.ndarray:
        idxs = [ctx.channels.index(c) for c in self.exclusive_channels if c in ctx.channels]
        if len(idxs) < 2:
            return genes
        subset = genes[:, :, idxs]
        nonzero_cnt = (subset > 0).sum(axis=2)
        for rep, hcp in np.argwhere(nonzero_cnt > 1):
            keep = int(rng.integers(0, len(idxs)))
            for k, ch in enumerate(idxs):
                if k != keep:
                    genes[rep, hcp, ch] = 0
        return genes


# ─────────────────────────────────────────────────────────────────────────────
# HCP 渠道约束
# ─────────────────────────────────────────────────────────────────────────────

@CONSTRAINT_REGISTRY.register("common_hard.hcp_channel_bounds")
class CommonHardHcpChannelBounds(HardConstraint):
    """
    HCP 渠道约束：每个 hcp 在指定渠道（或全渠道）的总拜访次数必须在 [lo, hi] 范围内。

    两种模式：
      - 指定渠道（channels=["f2f"]）：
          对每个 hcp，sum over all reps，在该渠道的总拜访次数 ∈ [lo_h, hi_h]。
          参数 bounds_per_channel: (n_hcps, n_channels, 2) — 不同 hcp 在不同渠道有不同的上下限。
          也支持 ctx.shared['hcp_channel_bounds'] 覆盖。
      - 全渠道（channels=None）：
          对每个 hcp，sum over all reps & all channels 的总拜访次数 ∈ [lo_h, hi_h]。
          参数 bounds_total: (n_hcps, 2) — 不同 hcp 有不同的全渠道上下限。
          也支持 ctx.shared['hcp_total_bounds'] 覆盖。

    参数：
        channels          list[str]|None  限定渠道列表，None=全渠道
        bounds_per_channel ndarray|null   (n_hcps, n_channels, 2) 每渠道上下限
        bounds_total      ndarray|null    (n_hcps, 2) 全渠道上下限
        default_lo        int             默认下限（bounds 未提供时的回退值）
        default_hi        int             默认上限
    """
    description = "hcp 渠道拜访次数上下限"

    def __init__(
        self,
        channels: Optional[List[str]] = None,
        bounds_per_channel: Optional[np.ndarray] = None,
        bounds_total: Optional[np.ndarray] = None,
        default_lo: int = 0,
        default_hi: int = 10,
    ):
        self.channels = channels
        self._bounds_per_channel = bounds_per_channel
        self._bounds_total = bounds_total
        self.default_lo = default_lo
        self.default_hi = default_hi

    def check(self, ind: Individual, ctx: Context) -> bool:
        if self.channels is not None:
            # ── 每渠道模式 ──
            ch_idx = [ctx.channels.index(c) for c in self.channels if c in ctx.channels]
            if not ch_idx:
                return True
            bounds = ctx.shared.get("hcp_channel_bounds")
            if bounds is None:
                bounds = self._bounds_per_channel
            if bounds is not None:
                # bounds shape: (n_hcps, n_channels, 2)
                lo_arr = bounds[:, ch_idx, 0]  # (n_hcps, len(ch_idx))
                hi_arr = bounds[:, ch_idx, 1]
            else:
                n_ch = len(ch_idx)
                lo_arr = np.full((ctx.n_hcps, n_ch), self.default_lo)
                hi_arr = np.full((ctx.n_hcps, n_ch), self.default_hi)
            # hcp_totals: (n_hcps, len(ch_idx)) — sum over reps
            hcp_totals = ind.genes[:, :, ch_idx].sum(axis=0)
            return bool(np.all(hcp_totals >= lo_arr) and np.all(hcp_totals <= hi_arr))
        else:
            # ── 全渠道模式 ──
            bounds = ctx.shared.get("hcp_total_bounds")
            if bounds is None:
                bounds = self._bounds_total
            if bounds is not None:
                lo_arr = bounds[:, 0]  # (n_hcps,)
                hi_arr = bounds[:, 1]
            else:
                lo_arr = np.full(ctx.n_hcps, self.default_lo)
                hi_arr = np.full(ctx.n_hcps, self.default_hi)
            hcp_totals = ind.genes.sum(axis=(0, 2))  # (n_hcps,) sum over reps & channels
            return bool(np.all(hcp_totals >= lo_arr) and np.all(hcp_totals <= hi_arr))

    def repair(self, genes: np.ndarray, ctx: Context, rng) -> np.ndarray:
        """按比例缩放超限 hcp 的拜访次数"""
        if self.channels is not None:
            ch_idx = [ctx.channels.index(c) for c in self.channels if c in ctx.channels]
            if not ch_idx:
                return genes
            bounds = ctx.shared.get("hcp_channel_bounds")
            if bounds is None:
                bounds = self._bounds_per_channel
            if bounds is not None:
                hi_arr = bounds[:, ch_idx, 1]  # (n_hcps, len(ch_idx))
            else:
                hi_arr = np.full((ctx.n_hcps, len(ch_idx)), self.default_hi)
            hcp_totals = genes[:, :, ch_idx].sum(axis=0)  # (n_hcps, n_ch_idx)
            for h in range(ctx.n_hcps):
                for k, ci in enumerate(ch_idx):
                    total = hcp_totals[h, k]
                    limit = hi_arr[h, k]
                    if total > limit:
                        scale = limit / (total + 1e-9)
                        genes[:, h, ci] = np.floor(genes[:, h, ci] * scale).astype(np.int32)
        else:
            bounds = ctx.shared.get("hcp_total_bounds")
            if bounds is None:
                bounds = self._bounds_total
            if bounds is not None:
                hi_arr = bounds[:, 1]  # (n_hcps,)
            else:
                hi_arr = np.full(ctx.n_hcps, self.default_hi)
            hcp_totals = genes.sum(axis=(0, 2))  # (n_hcps,)
            for h in range(ctx.n_hcps):
                if hcp_totals[h] > hi_arr[h]:
                    scale = hi_arr[h] / (hcp_totals[h] + 1e-9)
                    genes[:, h, :] = np.floor(genes[:, h, :] * scale).astype(np.int32)
        return genes


# ─────────────────────────────────────────────────────────────────────────────
# Rep 渠道约束
# ─────────────────────────────────────────────────────────────────────────────

@CONSTRAINT_REGISTRY.register("common_hard.rep_channel_bounds")
class CommonHardRepChannelBounds(HardConstraint):
    """
    Rep 渠道约束：每个 rep 在指定渠道（或全渠道）的总工作量必须在 [lo, hi] 范围内。

    两种模式：
      - 指定渠道（channels=["f2f"]）：
          对每个 rep，sum over all hcps，在该渠道的总工作量 ∈ [lo_r, hi_r]。
          参数 bounds_per_channel: (n_reps, n_channels, 2) — 不同 rep 在不同渠道有不同的上下限。
          也支持 ctx.shared['rep_channel_bounds'] 覆盖。
      - 全渠道（channels=None）：
          对每个 rep，sum over all hcps & all channels 的总工作量 ∈ [lo_r, hi_r]。
          参数 bounds_total: (n_reps, 2) — 不同 rep 有不同的全渠道上下限。
          也支持 ctx.shared['rep_total_bounds'] 覆盖。

    参数：
        channels          list[str]|None  限定渠道列表，None=全渠道
        bounds_per_channel ndarray|null   (n_reps, n_channels, 2) 每渠道上下限
        bounds_total      ndarray|null    (n_reps, 2) 全渠道上下限
        default_lo        int             默认下限（bounds 未提供时的回退值）
        default_hi        int             默认上限

    Rep-HCP 配对表（v12 新增）：
        assignment_mask: (n_reps, n_hcps) bool — True 表示该 rep 选择了该 hcp
        从 ctx.shared['assignment_mask'] 读取。
        为 False 的 (rep, hcp) 组合，genes[r, h, :] 必须全为 0。

    Rep 下界松弛（v12 新增）：
        当某个 rep 的所有已选 HCP（assignment_mask=True）均已达到上限，
        且该 rep 未选择任何 spillover HCP（guidance=0），则允许该 rep
        的工作量低于下界（不视为违反约束）。
    """
    description = "rep 渠道工作量上下限"

    def __init__(
        self,
        channels: Optional[List[str]] = None,
        bounds_per_channel: Optional[np.ndarray] = None,
        bounds_total: Optional[np.ndarray] = None,
        default_lo: int = 60,
        default_hi: int = 100,
    ):
        self.channels = channels
        self._bounds_per_channel = bounds_per_channel
        self._bounds_total = bounds_total
        self.default_lo = default_lo
        self.default_hi = default_hi

    # ── 配对表支持 ──────────────────────────────────────────────────────

    def _get_assignment_mask(self, ctx: Context) -> Optional[np.ndarray]:
        """获取 Rep-HCP 配对表。
        优先读取 ctx.shared['assignment_mask']，支持两种形状：
          - (n_reps, n_hcps, n_channels): per-channel 配对表
          - (n_reps, n_hcps): 全渠道配对表（广播到所有渠道）
        返回 (n_reps, n_hcps) bool，表示 rep 对 hcp 的全局可访问性。
        对于 per-channel mask，取 OR（任一渠道可访问即视为可访问）。
        """
        mask = ctx.shared.get("assignment_mask")
        if mask is None:
            return None
        mask = np.asarray(mask, dtype=bool)
        if mask.ndim == 3:
            # (n_reps, n_hcps, n_channels) -> OR across channels -> (n_reps, n_hcps)
            return mask.any(axis=2)
        return mask

    def _get_channel_assignment_mask(
        self, ctx: Context, channel_idx: int
    ) -> Optional[np.ndarray]:
        """获取某个渠道的 Rep-HCP 配对表 (n_reps, n_hcps) bool。
        如果 assignment_mask 是 3D (n_reps, n_hcps, n_channels)，返回该渠道的 slice。
        如果是 2D (n_reps, n_hcps)，直接返回。
        """
        mask = ctx.shared.get("assignment_mask")
        if mask is None:
            return None
        mask = np.asarray(mask, dtype=bool)
        if mask.ndim == 3:
            return mask[:, :, channel_idx]
        return mask  # 2D: broadcast

    def _check_assignment(self, genes: np.ndarray, ctx: Context) -> bool:
        """检查配对表：mask=False 的位置 genes 必须全为 0"""
        mask3d = ctx.shared.get("assignment_mask")
        if mask3d is None:
            return True
        mask3d = np.asarray(mask3d, dtype=bool)
        if mask3d.ndim == 3:
            return bool(genes[~mask3d].sum() == 0)
        else:
            # 2D mask: broadcast to all channels
            return bool(genes[~mask3d[:, :, None]].sum() == 0)

    def _repair_assignment(self, genes: np.ndarray, ctx: Context) -> np.ndarray:
        """修复配对表：将 mask=False 的位置清零"""
        mask3d = ctx.shared.get("assignment_mask")
        if mask3d is None:
            return genes
        mask3d = np.asarray(mask3d, dtype=bool)
        if mask3d.ndim == 3:
            genes[~mask3d] = 0
        else:
            genes[~mask3d[:, :, None]] = 0
        return genes

    def _get_hcp_channel_hi(self, ctx: Context, h: int, ch: int) -> int:
        """获取 HCP h 在渠道 ch 的拜访上限。"""
        # 优先从 hcp_channel_bounds 获取
        ch_bounds = ctx.shared.get("hcp_channel_bounds")
        if ch_bounds is not None:
            return int(ch_bounds[h, ch, 1])
        # 回退到全渠道上限
        return self._get_hcp_hi(ctx, h)

    def _compute_rep_capacity(
        self,
        genes: np.ndarray,
        ctx: Context,
        r: int,
        spillover_mask: Optional[np.ndarray],
        assignment_mask: Optional[np.ndarray],
        channel_idx: Optional[int] = None,
    ) -> int:
        """
        计算 rep r 在其已选 HCP 中（排除已满的非 spillover HCP）的最大剩余容量。
        channel_idx: 如果指定，只考虑该渠道；否则全渠道。
        """
        capacity = 0
        for h in range(ctx.n_hcps):
            if assignment_mask is not None and not assignment_mask[r, h]:
                continue
            if spillover_mask is not None and spillover_mask[h]:
                continue
            if channel_idx is not None:
                hcp_total = int(genes[:, h, channel_idx].sum())
                hcp_hi = self._get_hcp_channel_hi(ctx, h, channel_idx)
                rep_room = int(max(0, ctx.hi[r, h, channel_idx] - genes[r, h, channel_idx]))
            else:
                hcp_total = int(genes[:, h, :].sum())
                hcp_hi = self._get_hcp_hi(ctx, h)
                rep_room = int((ctx.hi[r, h, :] - genes[r, h, :]).clip(min=0).sum())
            hcp_room = max(0, hcp_hi - hcp_total)
            capacity += min(rep_room, hcp_room)
        return capacity

    def _get_hcp_hi(self, ctx: Context, h: int) -> int:
        """获取 HCP h 的全渠道总拜访上限"""
        bounds = ctx.shared.get("hcp_total_bounds")
        if bounds is not None:
            return int(bounds[h, 1])
        return 99999

    def _has_spillover_access(
        self,
        r: int,
        spillover_mask: Optional[np.ndarray],
        assignment_mask: Optional[np.ndarray],
    ) -> bool:
        """检查 rep r 是否有权限访问任何 spillover HCP"""
        if spillover_mask is None:
            return False
        if assignment_mask is None:
            return bool(spillover_mask.any())
        return bool((spillover_mask & assignment_mask[r]).any())

    def _total_rep_capacity(
        self,
        r: int,
        genes: np.ndarray,
        ctx: Context,
        spillover_mask: Optional[np.ndarray],
        assignment_mask: Optional[np.ndarray],
        channel_idx: Optional[int] = None,
    ) -> int:
        """
        计算 rep r 在所有已选 HCP（含 spillover）中的总剩余容量。
        channel_idx: 如果指定，只考虑该渠道；否则全渠道。
        """
        total_cap = 0

        # 非 spillover HCP 容量
        total_cap += self._compute_rep_capacity(
            genes, ctx, r, spillover_mask, assignment_mask, channel_idx=channel_idx
        )

        # Spillover HCP 容量
        if spillover_mask is not None and self._has_spillover_access(r, spillover_mask, assignment_mask):
            for h in range(ctx.n_hcps):
                if not spillover_mask[h]:
                    continue
                if assignment_mask is not None and not assignment_mask[r, h]:
                    continue
                if channel_idx is not None:
                    hcp_total = int(genes[:, h, channel_idx].sum())
                    hcp_hi = self._get_hcp_channel_hi(ctx, h, channel_idx)
                    rep_room = int(max(0, ctx.hi[r, h, channel_idx] - genes[r, h, channel_idx]))
                else:
                    hcp_total = int(genes[:, h, :].sum())
                    hcp_hi = self._get_hcp_hi(ctx, h)
                    rep_room = int((ctx.hi[r, h, :] - genes[r, h, :]).clip(min=0).sum())
                hcp_room = max(0, hcp_hi - hcp_total)
                total_cap += min(rep_room, hcp_room)

        return total_cap

    def _rep_can_reach_lo(
        self,
        r: int,
        genes: np.ndarray,
        ctx: Context,
        lo: int,
        spillover_mask: Optional[np.ndarray],
        assignment_mask: Optional[np.ndarray],
        channel_idx: Optional[int] = None,
    ) -> bool:
        """
        检查 rep r 是否有可能达到其下界 lo。
        先仅用正常 HCP（非 spillover）的容量判断，只有正常 HCP 全满时
        才考虑 spillover HCP 作为最后手段。
        channel_idx: 如果指定，只考虑该渠道的工作量和容量。
        """
        if channel_idx is not None:
            current = int(genes[r, :, channel_idx].sum())
        else:
            current = int(genes[r].sum())

        # 先检查仅用正常 HCP（非 spillover）的容量
        normal_capacity = self._compute_rep_capacity(
            genes, ctx, r, spillover_mask, assignment_mask, channel_idx=channel_idx
        )
        if current + normal_capacity >= lo:
            return True

        # 正常 HCP 不够，检查是否可以借助 spillover HCP
        total_capacity = self._total_rep_capacity(
            r, genes, ctx, spillover_mask, assignment_mask, channel_idx=channel_idx
        )
        return (current + total_capacity) >= lo

    # ── check ───────────────────────────────────────────────────────────

    def check(self, ind: Individual, ctx: Context) -> bool:
        # 配对表检查
        if not self._check_assignment(ind.genes, ctx):
            return False

        spillover = self._get_spillover_hcps(ctx)
        assignment = self._get_assignment_mask(ctx)

        if self.channels is not None:
            ch_idx = [ctx.channels.index(c) for c in self.channels if c in ctx.channels]
            if not ch_idx:
                return True
            bounds = ctx.shared.get("rep_channel_bounds")
            if bounds is None:
                bounds = self._bounds_per_channel
            if bounds is not None:
                lo_arr = bounds[:, ch_idx, 0]
                hi_arr = bounds[:, ch_idx, 1]
            else:
                n_ch = len(ch_idx)
                lo_arr = np.full((ctx.n_reps, n_ch), self.default_lo)
                hi_arr = np.full((ctx.n_reps, n_ch), self.default_hi)
            rep_totals = ind.genes[:, :, ch_idx].sum(axis=1)
            for r in range(ctx.n_reps):
                for k, ci in enumerate(ch_idx):
                    total = rep_totals[r, k]
                    lo, hi = int(lo_arr[r, k]), int(hi_arr[r, k])
                    if total > hi:
                        return False
                    # v18: 下限必须达到，不再松弛
                    if total < lo:
                        return False
            return True
        else:
            # 全渠道模式：跨所有渠道的总体约束
            bounds = ctx.shared.get("rep_total_bounds")
            if bounds is None:
                bounds = self._bounds_total
            if bounds is not None:
                lo_arr = bounds[:, 0]
                hi_arr = bounds[:, 1]
            else:
                lo_arr = np.full(ctx.n_reps, self.default_lo)
                hi_arr = np.full(ctx.n_reps, self.default_hi)
            rep_totals = ind.genes.sum(axis=(1, 2))
            for r in range(ctx.n_reps):
                lo, hi = int(lo_arr[r]), int(hi_arr[r])
                total = int(rep_totals[r])
                if total > hi:
                    return False
                # v18: 下限必须达到，不再松弛
                if total < lo:
                    return False
            return True

    # ── Spillover 识别与缩减 ───────────────────────────────────────────

    def _reduce_rep_channel(
        self,
        genes: np.ndarray,
        r: int,
        ci: int,
        hi: int,
        assignment_mask: Optional[np.ndarray],
        spillover_mask: Optional[np.ndarray],
        rng,
    ) -> None:
        """
        将 rep r 在渠道 ci 的工作量缩减到 hi 以下。
        策略：优先缩减 spillover HCP（NA），保护正常 HCP 的值。
        只有 spillover HCP 全部缩到 0 仍不够时，才按比例缩减所有 HCP。
        """
        total = int(genes[r, :, ci].sum())
        if total <= hi:
            return

        excess = total - hi

        # Step 1: 优先缩减 spillover HCP
        if spillover_mask is not None:
            for h in range(genes.shape[1]):
                if not spillover_mask[h]:
                    continue
                if assignment_mask is not None and not assignment_mask[r, h]:
                    continue
                reduce_amt = min(int(genes[r, h, ci]), excess)
                genes[r, h, ci] -= reduce_amt
                excess -= reduce_amt
                if excess <= 0:
                    return

        # Step 2: spillover 全部清零仍不够，按比例缩减所有 HCP
        if excess > 0:
            current_total = int(genes[r, :, ci].sum())
            if current_total > hi:
                scale = hi / (current_total + 1e-9)
                genes[r, :, ci] = np.floor(genes[r, :, ci] * scale).astype(np.int32)

    def _reduce_rep_overall(
        self,
        genes: np.ndarray,
        r: int,
        hi: int,
        assignment_mask: Optional[np.ndarray],
        spillover_mask: Optional[np.ndarray],
        rng,
    ) -> None:
        """
        将 rep r 的全渠道工作量缩减到 hi 以下。
        策略：优先缩减 spillover HCP（NA），保护正常 HCP。
        """
        total = int(genes[r].sum())
        if total <= hi:
            return

        excess = total - hi

        # Step 1: 优先缩减 spillover HCP 的所有渠道
        if spillover_mask is not None:
            for h in range(genes.shape[1]):
                if not spillover_mask[h]:
                    continue
                if assignment_mask is not None and not assignment_mask[r, h]:
                    continue
                for ci in range(genes.shape[2]):
                    reduce_amt = min(int(genes[r, h, ci]), excess)
                    genes[r, h, ci] -= reduce_amt
                    excess -= reduce_amt
                    if excess <= 0:
                        return

        # Step 2: spillover 全部清零仍不够，按比例缩减所有 HCP
        if excess > 0:
            current_total = int(genes[r].sum())
            if current_total > hi:
                scale = hi / (current_total + 1e-9)
                genes[r, :, :] = np.floor(genes[r, :, :] * scale).astype(np.int32)

    def _get_spillover_hcps(self, ctx: Context) -> Optional[np.ndarray]:
        """
        识别可以吸收多余工作量的 HCP 索引。
        通过 ctx.shared['hcp_segment'] 找到 segment 类别为 'NA' 的 HCP。
        返回 bool mask (n_hcps,)，True 表示该 HCP 可接收溢出工作量。
        如果无法识别，返回 None（退回均匀分配）。
        """
        segments = ctx.shared.get("hcp_segment")
        if not segments:
            return None
        mask = np.array([s == "NA" for s in segments], dtype=bool)
        return mask if mask.any() else None

    def _fill_deficit_prefer_spillover(
        self,
        genes: np.ndarray,
        r: int,
        deficit: int,
        hi_gene: np.ndarray,
        rng,
        spillover_mask: Optional[np.ndarray],
        assignment_mask: Optional[np.ndarray],
        hcp_total_hi: Optional[np.ndarray] = None,
        all_genes: Optional[np.ndarray] = None,
        channel_idx: Optional[int] = None,
    ) -> np.ndarray:
        """
        将 deficit 分配给正常 HCP（A/B/C/D），**不分配给 spillover HCP**。

        v18 策略变更：
          - 只分配给正常 HCP（A/B/C/D），spillover HCP 不再作为填充目标
          - 正常 HCP 未满时，绝对不分配给 NA
          - 如果正常 HCP 全满但 deficit 仍有剩余，接受低于下界（由 repair 后续处理）

        genes: shape (n_hcps, n_channels) 或 (n_hcps, 1) — rep r 的基因切片
        hi_gene: shape 与 genes 相同
        spillover_mask: (n_hcps,) bool — 可溢出的 HCP（NA 类）
        assignment_mask: (n_reps, n_hcps) bool — rep 已选 HCP（None 表示无限制）
        hcp_total_hi: (n_hcps,) int — 每个 HCP 的总量上限
        all_genes: (n_reps, n_hcps, n_channels) — 完整基因矩阵
        channel_idx: 如果指定，HCP 总量只计算该渠道
        """
        remaining = deficit
        is_1d = genes.ndim == 1
        if is_1d:
            genes = genes[:, None]
            hi_gene = hi_gene[:, None]

        n_hcps_local = genes.shape[0]

        # 确定 rep r 可以访问的 HCP
        if assignment_mask is not None:
            accessible = assignment_mask[r]  # (n_hcps,) bool
        else:
            accessible = np.ones(n_hcps_local, dtype=bool)

        # 只分配给正常 HCP（不包含 spillover）
        if remaining > 0:
            if spillover_mask is not None:
                normal_accessible = ~spillover_mask & accessible
            else:
                normal_accessible = accessible

            if normal_accessible.any():
                normal_indices = np.where(normal_accessible)[0]
                # 贪心策略：反复遍历所有正常 HCP
                while remaining > 0:
                    filled_any = False
                    for h in normal_indices:
                        if remaining <= 0:
                            break
                        gene_room = (hi_gene[h] - genes[h]).astype(np.int32).clip(min=0)
                        if hcp_total_hi is not None and all_genes is not None:
                            if channel_idx is not None:
                                hcp_total = int(all_genes[:, h, channel_idx].sum())
                            else:
                                hcp_total = int(all_genes[:, h, :].sum())
                            hcp_hi_val = int(hcp_total_hi[h]) if isinstance(hcp_total_hi, np.ndarray) else int(hcp_total_hi)
                            hcp_room = max(0, hcp_hi_val - hcp_total)
                            total_gene_room = int(gene_room.sum())
                            if hcp_room < total_gene_room:
                                if total_gene_room > 0:
                                    scale = hcp_room / total_gene_room
                                    gene_room = np.floor(gene_room.astype(float) * scale).astype(np.int32)
                                else:
                                    gene_room = np.zeros_like(gene_room)

                        fill_amount = min(remaining, int(gene_room.sum()))
                        if fill_amount <= 0:
                            continue
                        filled_any = True
                        room_sum = int(gene_room.sum())
                        if room_sum > 0:
                            prob = gene_room.astype(float) / room_sum
                            added = rng.multinomial(fill_amount, prob)
                            genes[h] = np.clip(
                                genes[h] + added, 0, hi_gene[h]
                            ).astype(np.int32)
                            remaining -= fill_amount
                    if not filled_any:
                        break  # 所有正常 HCP 都满了

        # v18: 不再进入 Phase 2（不分配给 spillover HCP）

        if is_1d:
            return genes.flatten()
        return genes

    def _compute_room_with_hcp_limit(
        self,
        current_genes: np.ndarray,
        hi_gene: np.ndarray,
        accessible_mask: np.ndarray,
        hcp_total_hi: Optional[np.ndarray],
        all_genes: Optional[np.ndarray],
        channel_idx: Optional[int] = None,
    ) -> np.ndarray:
        """
        计算每个 (hcp, channel) 的可用空间，同时考虑：
        1. 单基因上限 (hi_gene)
        2. HCP 总量上限 (hcp_total_hi)
        current_genes 和 room 的行索引是 accessible_mask 中的局部行（不是全局 hcp 索引）。
        channel_idx: 如果指定，HCP 总量只计算该渠道。
        返回与 current_genes 同形状的 int32 数组。
        """
        # 基础空间：单基因上限 - 当前值
        room = (hi_gene - current_genes).astype(np.int32).clip(min=0)

        if hcp_total_hi is not None and all_genes is not None:
            # accessible_mask 给出的是全局 hcp 索引
            accessible_indices = np.where(accessible_mask)[0]
            for local_h, global_h in enumerate(accessible_indices):
                # 当前该 HCP 的总拜访次数（所有 rep）
                if channel_idx is not None:
                    hcp_total = int(all_genes[:, global_h, channel_idx].sum())
                else:
                    hcp_total = int(all_genes[:, global_h, :].sum())
                hcp_limit = int(hcp_total_hi[global_h])
                # 该 HCP 还能接收多少次（总量维度）
                hcp_room = max(0, hcp_limit - hcp_total)
                # 如果总量空间 < 当前 rep 的基因空间，按比例缩减
                rep_room = int(room[local_h, :].sum())
                if hcp_room < rep_room:
                    total_room = room[local_h, :].sum()
                    if total_room > 0:
                        scale = hcp_room / total_room
                        room[local_h, :] = np.floor(room[local_h, :].astype(float) * scale).astype(np.int32)

        return room

    # ── repair ──────────────────────────────────────────────────────────

    def repair(self, genes: np.ndarray, ctx: Context, rng) -> np.ndarray:
        """
        按比例缩放/放大 rep 的拜访次数，使其满足上下界。
        - 配对表修复：mask=False 的位置清零
        - 超过上界：按比例缩减
        - 低于下界：优先分配给正常 HCP（A/B/C/D 等），剩余不足时才分配给
          spillover HCP（NA 类）作为最后手段。
          分配时考虑 HCP 总量上限，避免突破 HCP 约束。
          如果所有已选 HCP（含 spillover）均已满（无空间），
          则接受低于下界（下界松弛）。
        - 每渠道模式：对每个渠道独立执行上述逻辑
        - 全渠道模式：跨所有渠道执行
        """
        # Step 0: 配对表修复
        genes = self._repair_assignment(genes, ctx)
        spillover_mask = self._get_spillover_hcps(ctx)
        assignment = self._get_assignment_mask(ctx)
        hcp_total_hi = self._get_all_hcp_hi(ctx)  # (n_hcps,) 每个 HCP 总量上限

        if self.channels is not None:
            # ── 每渠道模式：对每个渠道独立 check/repair ──
            ch_idx = [ctx.channels.index(c) for c in self.channels if c in ctx.channels]
            if not ch_idx:
                return genes
            bounds = ctx.shared.get("rep_channel_bounds")
            if bounds is None:
                bounds = self._bounds_per_channel
            if bounds is not None:
                lo_arr = bounds[:, ch_idx, 0]
                hi_arr = bounds[:, ch_idx, 1]
            else:
                n_ch = len(ch_idx)
                lo_arr = np.full((ctx.n_reps, n_ch), self.default_lo)
                hi_arr = np.full((ctx.n_reps, n_ch), self.default_hi)

            for k, ci in enumerate(ch_idx):
                ch_assign = self._get_channel_assignment_mask(ctx, ci)
                hcp_ch_hi = self._get_all_hcp_channel_hi(ctx, ci)

                rep_totals_ch = genes[:, :, ci].sum(axis=1)
                for r in range(ctx.n_reps):
                    total = rep_totals_ch[r]
                    lo, hi = int(lo_arr[r, k]), int(hi_arr[r, k])
                    if total > hi and hi > 0:
                        self._reduce_rep_channel(
                            genes, r, ci, hi, ch_assign,
                            spillover_mask, rng,
                        )
                    elif total < lo:
                        # v18: 强制分配给正常 HCP 直到下界达到，不给 NA 分配
                        deficit = lo - int(genes[r, :, ci].sum())
                        if deficit <= 0:
                            continue
                        hi_gene = ctx.hi[r, :, ci:ci+1]  # (n_hcps, 1)
                        filled = self._fill_deficit_prefer_spillover(
                            genes[r, :, ci:ci+1], r, deficit, hi_gene,
                            rng, spillover_mask, ch_assign,
                            hcp_total_hi=hcp_ch_hi,
                            all_genes=genes,
                            channel_idx=ci,
                        )
                        genes[r, :, ci] = filled.flatten()
                        if ch_assign is not None:
                            genes[r, ~ch_assign[r], ci] = 0
        else:
            # ── 全渠道模式 ──
            bounds = ctx.shared.get("rep_total_bounds")
            if bounds is None:
                bounds = self._bounds_total
            if bounds is not None:
                lo_arr = bounds[:, 0]
                hi_arr = bounds[:, 1]
            else:
                lo_arr = np.full(ctx.n_reps, self.default_lo)
                hi_arr = np.full(ctx.n_reps, self.default_hi)
            rep_totals = genes.sum(axis=(1, 2))
            for r in range(ctx.n_reps):
                lo, hi = int(lo_arr[r]), int(hi_arr[r])
                total = int(rep_totals[r])
                if total > hi and hi > 0:
                    self._reduce_rep_overall(
                        genes, r, hi, assignment, spillover_mask, rng,
                    )
                elif total < lo:
                    # v18: 强制分配给正常 HCP 直到下界达到，不给 NA 分配
                    deficit = lo - total
                    if deficit <= 0:
                        continue
                    hi_gene = ctx.hi[r, :, :]
                    genes[r, :, :] = self._fill_deficit_prefer_spillover(
                        genes[r, :, :], r, deficit, hi_gene, rng, spillover_mask, assignment,
                        hcp_total_hi, genes,
                    )
                    if assignment is not None:
                        genes[r, ~assignment[r], :] = 0
        return genes

    def _get_all_hcp_channel_hi(self, ctx: Context, channel_idx: int) -> Optional[np.ndarray]:
        """获取所有 HCP 在指定渠道的拜访上限 (n_hcps,)"""
        ch_bounds = ctx.shared.get("hcp_channel_bounds")
        if ch_bounds is not None:
            return ch_bounds[:, channel_idx, 1].astype(int)
        return None

    def _get_all_hcp_hi(self, ctx: Context) -> Optional[np.ndarray]:
        """获取所有 HCP 的全渠道总拜访上限 (n_hcps,)"""
        bounds = ctx.shared.get("hcp_total_bounds")
        if bounds is not None:
            return bounds[:, 1].astype(int)
        return None
