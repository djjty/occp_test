"""
constraints/common/common_output.py — 通用输出处理步骤

优化结果→数据处理→写入数据库之间的标准步骤。
每个步骤从 ctx 中读取优化结果，处理后写入 ctx 供后续步骤或写库使用。

步骤清单（按推荐执行顺序）
--------------------------
1. GenesTo3DArray        — 提取 genes 为 3D numpy 数组
2. FlattenGenesToLongTable — 将 genes 展平为长表格式
3. AddMetaColumns        — 添加 task_id / brand_id / timestamp 等元数据
4. RoundVisitsToInt      — 确保拜访次数为整数
5. FilterOutputColumns   — 只保留指定输出列

注册使用 core/registry.py 中的 PIPELINE_STEP_REGISTRY，不再有独立注册表。
"""
from __future__ import annotations
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import numpy as np

from ...core.base import PipelineStep, Context
from ...core.registry import PIPELINE_STEP_REGISTRY

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# 1. GenesTo3DArray
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("genes_to_3d_array")
class GenesTo3DArray(PipelineStep):
    """
    从 ctx['result'] 中提取最优 genes，写入 ctx['output_genes'] (np.ndarray)。

    ctx 依赖：result (OptimizationResult)
    ctx 写入：output_genes (np.ndarray, shape n_reps×n_hcps×n_channels)
    """
    name = "genes_to_3d_array"

    def process(self, ctx: Context) -> Context:
        result = ctx.require("result")
        ctx["output_genes"] = result.best_individual.genes
        logger.debug("[GenesTo3DArray] shape=%s", ctx["output_genes"].shape)
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 2. FlattenGenesToLongTable
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("flatten_genes_to_long_table")
class FlattenGenesToLongTable(PipelineStep):
    """
    将 output_genes 展平为长表列表 (List[Dict])。

    ctx 依赖：output_genes, channels (list[str]), task_id, brand_id
    ctx 写入：output_rows (List[Dict])
    """
    name = "flatten_genes_to_long_table"

    def process(self, ctx: Context) -> Context:
        genes = ctx.require("output_genes")
        channels: List[str] = ctx.require("channels")
        task_id: str = ctx.get("task_id", "")
        brand_id: str = ctx.get("brand_id", "")

        n_reps, n_hcps, n_ch = genes.shape
        rep_idx = np.repeat(np.arange(n_reps), n_hcps * n_ch)
        hcp_idx = np.tile(np.repeat(np.arange(n_hcps), n_ch), n_reps)
        ch_idx = np.tile(np.arange(n_ch), n_reps * n_hcps)
        ch_names = [channels[i] if i < len(channels) else f"ch_{i}" for i in ch_idx]
        visits = genes.flatten()

        rows = []
        for i in range(len(visits)):
            rows.append({
                "task_id": task_id,
                "brand_id": brand_id,
                "rep_idx": int(rep_idx[i]),
                "hcp_idx": int(hcp_idx[i]),
                "channel": ch_names[i],
                "visits": int(visits[i]),
            })

        ctx["output_rows"] = rows
        logger.debug("[FlattenGenesToLongTable] n_rows=%d", len(rows))
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 3. AddMetaColumns
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("add_meta_columns")
class AddMetaColumns(PipelineStep):
    """
    为输出行添加元数据列。

    ctx 依赖：output_rows (List[Dict])
    ctx 写入：output_rows (修改原列表)
    """
    name = "add_meta_columns"

    def __init__(
        self,
        extra_columns: Optional[Dict[str, Any]] = None,
        add_timestamp: bool = True,
    ):
        self.extra_columns = extra_columns or {}
        self.add_timestamp = add_timestamp

    def process(self, ctx: Context) -> Context:
        rows: List[Dict] = ctx.require("output_rows")
        ts = datetime.now().isoformat() if self.add_timestamp else None

        for row in rows:
            if ts:
                row["created_at"] = ts
            for k, v in self.extra_columns.items():
                row[k] = v

        logger.debug("[AddMetaColumns] added %d extra columns + timestamp=%s",
                     len(self.extra_columns), self.add_timestamp)
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 4. RoundVisitsToInt
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("round_visits_to_int")
class RoundVisitsToInt(PipelineStep):
    """
    确保输出行中 visits 列为整数。

    ctx 依赖：output_rows
    ctx 写入：output_rows
    """
    name = "round_visits_to_int"

    def process(self, ctx: Context) -> Context:
        rows: List[Dict] = ctx.require("output_rows")
        for row in rows:
            if "visits" in row:
                row["visits"] = int(round(row["visits"]))
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 5. FilterOutputColumns
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("filter_output_columns")
class FilterOutputColumns(PipelineStep):
    """
    只保留指定的输出列，用于适配不同品牌的写库表结构。

    ctx 依赖：output_rows
    ctx 写入：output_rows
    """
    name = "filter_output_columns"

    def __init__(self, columns: Optional[List[str]] = None):
        self.columns = columns

    def process(self, ctx: Context) -> Context:
        rows: List[Dict] = ctx.require("output_rows")
        if self.columns is None:
            return ctx
        ctx["output_rows"] = [{k: row[k] for k in self.columns if k in row} for row in rows]
        logger.debug("[FilterOutputColumns] kept columns: %s", self.columns)
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 辅助：构建标准输出上下文
# ─────────────────────────────────────────────────────────────────────────────

def make_output_context(
    result: Any,
    channels: List[str],
    brand_id: str = "",
    task_id: str = "",
) -> Context:
    """从 OptimizationResult 创建输出 Context。"""
    return Context(initial={
        "result": result,
        "channels": channels,
        "brand_id": brand_id,
        "task_id": task_id or (result.task_id if result else ""),
    })
