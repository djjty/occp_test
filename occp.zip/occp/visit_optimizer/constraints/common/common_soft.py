"""
constraints/common/common_soft.py — 通用软约束

设计原则：
  1. 每个约束实现 raw_penalty()，基类自动归一化后乘以 weight。
  2. 归一化参考量来自 Context.shape 和 bounds，无硬编码。
  3. 新增 HCP 分级评分约束（正态分布打分）。
"""
from __future__ import annotations
from typing import Dict, List, Optional
import numpy as np

from ...core.base import SoftConstraint, Context
from ...optimizer.types import Individual
from ...core.registry import CONSTRAINT_REGISTRY


@CONSTRAINT_REGISTRY.register("common_soft.rep_workload_balance")
class CommonSoftRepWorkloadBalance(SoftConstraint):
    """各 rep 工作量方差惩罚（归一化后加权）"""
    description = "各 rep 工作量方差越小越好"

    def __init__(self, weight: float = 1.0):
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        return float(np.var(ind.genes.sum(axis=(1, 2)).astype(float)))

    def normalize(self, raw: float, ctx: Context) -> float:
        max_visits_per_rep = float(ctx.n_hcps * ctx.n_channels * ctx.hi_max_safe)
        return raw / (max_visits_per_rep ** 2 + 1e-9)


@CONSTRAINT_REGISTRY.register("common_soft.hcp_workload_balance")
class CommonSoftHcpWorkloadBalance(SoftConstraint):
    """各 hcp 被拜访总次数方差惩罚"""
    description = "各 hcp 工作量方差越小越好"

    def __init__(self, weight: float = 1.0):
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        return float(np.var(ind.genes.sum(axis=(0, 2)).astype(float)))

    def normalize(self, raw: float, ctx: Context) -> float:
        max_v = float(ctx.n_reps * ctx.n_channels * ctx.hi_max_safe)
        return raw / (max_v ** 2 + 1e-9)


@CONSTRAINT_REGISTRY.register("common_soft.budget")
class CommonSoftBudget(SoftConstraint):
    """
    总拜访成本不超过预算。超出部分线性惩罚。
    cost_matrix 优先从 ctx.shared['cost_matrix'] 读取。
    """
    description = "总拜访成本不超预算"

    def __init__(self, budget: float, cost_matrix: Optional[np.ndarray] = None,
                 weight: float = 1.0):
        self.budget = budget
        self._cost_matrix = cost_matrix
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        cost = self._cost_matrix if self._cost_matrix is not None \
            else ctx.shared.get("cost_matrix", np.ones(ctx.shape))
        total = float(np.sum(ind.genes * cost))
        return max(0.0, total - self.budget)

    def normalize(self, raw: float, ctx: Context) -> float:
        return raw / (self.budget + 1e-9)


@CONSTRAINT_REGISTRY.register("common_soft.channel_balance")
class CommonSoftChannelBalance(SoftConstraint):
    """各渠道总拜访次数方差惩罚"""
    description = "各渠道总拜访次数方差越小越好"

    def __init__(self, weight: float = 1.0):
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        return float(np.var(ind.genes.sum(axis=(0, 1)).astype(float)))

    def normalize(self, raw: float, ctx: Context) -> float:
        max_v = float(ctx.n_reps * ctx.n_hcps * ctx.hi_max_safe)
        return raw / (max_v ** 2 + 1e-9)


@CONSTRAINT_REGISTRY.register("common_soft.hcp_seg_score")
class CommonSoftHcpSegScore(SoftConstraint):
    """
    HCP 分级评分软约束（正态分布打分）。

    对于指定渠道（或全渠道），每个 hcp 被拜访总次数越接近其分级对应的
    正态分布均值，评分越高（惩罚越低）。

    参数：
        seg_call_guidance  dict[str, float]   分级→推荐拜访次数（均值），
                           如 {"A":5, "B":3, "C":2, "D":1, "V":1, "NA":1000}
        sigma              float              正态分布标准差，默认 1.0
        channels           list[str]|None     限定渠道，None=全渠道
        listing_only       bool               True=只对 listing=True 的 hcp 评分
        weight             float

    归一化：最大惩罚 = n_hcps（每个 hcp 都在分布尾部时的理论上限≈1）
    """
    description = "HCP 分级评分：拜访次数越接近正态分布均值，得分越高"

    def __init__(
        self,
        seg_call_guidance: Dict[str, float],
        sigma: float = 1.0,
        channels: Optional[List[str]] = None,
        listing_only: bool = False,
        weight: float = 1.0,
    ):
        self.seg_call_guidance = seg_call_guidance
        self.sigma = sigma
        self.channels = channels
        self.listing_only = listing_only
        self.weight = weight

    def _get_mu_array(self, ctx: Context) -> np.ndarray:
        """从 ctx.shared['hcp_seg'] 读取每个 hcp 的目标拜访次数（均值）"""
        hcp_seg: List[str] = ctx.shared.get("hcp_seg", [])
        default_mu = float(np.mean(list(self.seg_call_guidance.values())))
        mu = np.array(
            [self.seg_call_guidance.get(s, default_mu) for s in hcp_seg],
            dtype=float,
        )
        if len(mu) != ctx.n_hcps:
            mu = np.full(ctx.n_hcps, default_mu)
        return mu

    def _get_mask(self, ctx: Context) -> np.ndarray:
        """返回需要评分的 hcp bool 掩码"""
        mask = np.ones(ctx.n_hcps, dtype=bool)
        if self.listing_only:
            listing: List[bool] = ctx.shared.get("hcp_listing", [])
            if len(listing) == ctx.n_hcps:
                mask = np.array(listing, dtype=bool)
        return mask

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        # ── 确定目标渠道索引 ──────────────────────────────────────────────────
        if self.channels:
            ch_idx = [ctx.channels.index(c) for c in self.channels if c in ctx.channels]
        else:
            ch_idx = list(range(ctx.n_channels))

        if not ch_idx:
            return 0.0

        # ── 汇总拜访次数：(n_hcps,) ──────────────────────────────────────────
        visits = ind.genes[:, :, ch_idx].sum(axis=(0, 2)).astype(float)  # sum reps & ch

        mu = self._get_mu_array(ctx)
        mask = self._get_mask(ctx)

        # 正态分布概率密度（越接近均值 pdf 越大，惩罚 = 1 - normalized_pdf）
        # normalized_pdf ∈ [0,1]，峰值=1
        diff = visits[mask] - mu[mask]
        pdf = np.exp(-0.5 * (diff / (self.sigma + 1e-9)) ** 2)  # ∈ (0, 1]
        penalty = float(np.sum(1.0 - pdf))                       # ∈ [0, n_active_hcps]
        return penalty

    def normalize(self, raw: float, ctx: Context) -> float:
        n_active = int(self._get_mask(ctx).sum())
        return raw / (n_active + 1e-9)
