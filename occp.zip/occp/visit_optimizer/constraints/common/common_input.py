"""
constraints/common/common_input.py — 通用输入处理步骤

数据读取→数据处理→构建约束之间的标准步骤。
约束通过 ctx.shared 读取数据，这些步骤负责把中间数据写入 ctx，
并最终通过 build_context() 传入 Context.shared。

步骤清单（按推荐执行顺序）
--------------------------
1. FillDefaultBounds         — 填充默认上下界（bounds_lo, bounds_hi）
2. ParseHcpSegListing        — 解析并标准化 hcp_seg / hcp_listing
3. ComputeListingBounds      — 依据 listing 状态计算 per-hcp 上界矩阵
4. ComputeCostMatrix         — 计算或注入 cost_matrix
5. NormalizeTotalVisitsBounds— 标准化 total_visits_bounds 为 (lo, hi) tuple
6. InjectSegCallGuidance     — 从 raw.extra 注入 seg_call_guidance

每个步骤都是独立可组合的，品牌可以：
  - 全部使用（通用品牌）
  - 只选其中几个
  - 在任意位置插入品牌专属步骤
  - 覆盖某个公共步骤（相同步骤名的品牌专属版本）

注册使用 core/registry.py 中的 PIPELINE_STEP_REGISTRY，不再有独立注册表。
"""
from __future__ import annotations
import logging
from typing import Any, Dict, List, Optional

import numpy as np

from ...core.base import PipelineStep, Context
from ...core.registry import PIPELINE_STEP_REGISTRY

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# 1. FillDefaultBounds
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("fill_default_bounds")
class FillDefaultBounds(PipelineStep):
    """
    若 raw 中未提供 bounds_lo / bounds_hi，则填充默认值。

    ctx 依赖：raw（包含 n_reps, n_hcps）
    ctx 写入：bounds_lo (int), bounds_hi (int)
    """
    name = "fill_default_bounds"

    def __init__(self, default_lo: int = 0, default_hi: int = 2**31 - 1) -> None:
        self.default_lo = default_lo
        self.default_hi = default_hi

    def process(self, ctx: Context) -> Context:
        raw = ctx.require("raw")
        ctx["bounds_lo"] = raw.get("bounds_lo", self.default_lo)
        ctx["bounds_hi"] = raw.get("bounds_hi", self.default_hi)
        logger.debug("[FillDefaultBounds] lo=%s hi=%s", ctx["bounds_lo"], ctx["bounds_hi"])
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 2. ParseHcpSegListing
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("parse_hcp_seg_listing")
class ParseHcpSegListing(PipelineStep):
    """
    从 raw 解析并标准化 hcp_seg（分级标签列表）和 hcp_listing（bool 列表）。

    ctx 依赖：raw（包含 n_hcps）
    ctx 写入：hcp_seg (List[str]), hcp_listing (List[bool])
    """
    name = "parse_hcp_seg_listing"

    def __init__(
        self,
        default_seg: str = "C",
        default_listing: bool = True,
    ) -> None:
        self.default_seg = default_seg
        self.default_listing = default_listing

    def process(self, ctx: Context) -> Context:
        raw = ctx.require("raw")
        n_hcps: int = raw.get("n_hcps", 0)

        # ── hcp_seg ──────────────────────────────────────────────────────
        hcp_seg: List[str] = raw.get("hcp_seg", [])
        if not hcp_seg or len(hcp_seg) != n_hcps:
            hcp_seg = [self.default_seg] * n_hcps
            logger.debug("[ParseHcpSegListing] hcp_seg not provided; using default '%s'",
                         self.default_seg)
        ctx["hcp_seg"] = list(hcp_seg)

        # ── hcp_listing ───────────────────────────────────────────────────
        hcp_listing: List[bool] = raw.get("hcp_listing", [])
        if not hcp_listing or len(hcp_listing) != n_hcps:
            hcp_listing = [self.default_listing] * n_hcps
            logger.debug("[ParseHcpSegListing] hcp_listing not provided; using default %s",
                         self.default_listing)
        ctx["hcp_listing"] = [bool(v) for v in hcp_listing]

        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 3. ComputeListingBounds
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("compute_listing_bounds")
class ComputeListingBounds(PipelineStep):
    """
    根据 hcp_listing 计算 per-hcp 上下界矩阵（shape n_hcps×2）。
    listing=True  的 hcp：上界 hi_listing；
    listing=False 的 hcp：上界 hi_unlisting。
    结果写入 ctx['listing_bounds']，供 BrandAHardListingWorkload 等约束直接读取。

    ctx 依赖：hcp_listing（由 ParseHcpSegListing 写入）
    ctx 写入：listing_bounds (np.ndarray shape n_hcps×2)
    """
    name = "compute_listing_bounds"

    def __init__(
        self,
        lo_listing: int = 0,
        hi_listing: int = 10,
        lo_unlisting: int = 0,
        hi_unlisting: int = 8,
    ) -> None:
        self.lo_listing = lo_listing
        self.hi_listing = hi_listing
        self.lo_unlisting = lo_unlisting
        self.hi_unlisting = hi_unlisting

    def process(self, ctx: Context) -> Context:
        hcp_listing: List[bool] = ctx.require("hcp_listing")
        arr = np.array(hcp_listing, dtype=bool)
        lo = np.where(arr, self.lo_listing, self.lo_unlisting).astype(np.int32)
        hi = np.where(arr, self.hi_listing, self.hi_unlisting).astype(np.int32)
        ctx["listing_bounds"] = np.stack([lo, hi], axis=1)  # (n_hcps, 2)
        logger.debug("[ComputeListingBounds] shape=%s", ctx["listing_bounds"].shape)
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 4. ComputeCostMatrix
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("compute_cost_matrix")
class ComputeCostMatrix(PipelineStep):
    """
    计算或注入 cost_matrix（shape n_reps×n_hcps×n_channels）。

    若 raw 中已有 cost_matrix，直接使用；
    否则按默认值（全 1）构建，并可选地从 hcp_df / rep_df 提取权重。

    ctx 依赖：raw（包含 n_reps, n_hcps）；可选 n_channels
    ctx 写入：cost_matrix (np.ndarray)
    """
    name = "compute_cost_matrix"

    def __init__(self, default_cost: float = 1.0, n_channels: Optional[int] = None) -> None:
        self.default_cost = default_cost
        self._n_channels = n_channels

    def process(self, ctx: Context) -> Context:
        raw = ctx.require("raw")
        existing = raw.get("cost_matrix")
        if existing is not None:
            ctx["cost_matrix"] = np.asarray(existing)
            return ctx

        n_reps = raw["n_reps"]
        n_hcps = raw["n_hcps"]
        n_ch   = self._n_channels or ctx.get("n_channels", 3)
        ctx["cost_matrix"] = np.full((n_reps, n_hcps, n_ch), self.default_cost)
        logger.debug("[ComputeCostMatrix] built default cost_matrix (%d,%d,%d)",
                     n_reps, n_hcps, n_ch)
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 5. NormalizeTotalVisitsBounds
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("normalize_total_visits_bounds")
class NormalizeTotalVisitsBounds(PipelineStep):
    """
    将 raw 中的 total_visits_bounds（list/tuple/None）标准化为 (lo, hi) 或 None。
    写入 ctx['total_visits_bounds']，供 CommonHardTotalVisitsRange 使用。

    ctx 依赖：raw
    ctx 写入：total_visits_bounds ((int,int) | None)
    """
    name = "normalize_total_visits_bounds"

    def process(self, ctx: Context) -> Context:
        raw = ctx.require("raw")
        b = raw.get("total_visits_bounds")
        if b is None:
            ctx["total_visits_bounds"] = None
        elif isinstance(b, (list, tuple)) and len(b) == 2:
            ctx["total_visits_bounds"] = (int(b[0]), int(b[1]))
        else:
            logger.warning("[NormalizeTotalVisitsBounds] unexpected format: %r; ignoring", b)
            ctx["total_visits_bounds"] = None
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 6. InjectSegCallGuidance
# ─────────────────────────────────────────────────────────────────────────────

@PIPELINE_STEP_REGISTRY.register("inject_seg_call_guidance")
class InjectSegCallGuidance(PipelineStep):
    """
    从 raw.extra 中注入 seg_call_guidance 字典（分级→推荐拜访次数）。
    写入 ctx['seg_call_guidance']，同时更新 ctx['extra']['seg_call_guidance']。

    ctx 依赖：raw
    ctx 写入：seg_call_guidance (dict)；extra (dict，合并写入)
    """
    name = "inject_seg_call_guidance"

    def __init__(
        self,
        default_guidance: Optional[Dict[str, float]] = None,
    ) -> None:
        self.default_guidance = default_guidance or {"A": 5, "B": 3, "C": 2, "D": 1, "V": 1, "NA": 0}

    def process(self, ctx: Context) -> Context:
        raw = ctx.require("raw")
        extra: Dict[str, Any] = raw.get("extra", {})
        guidance = extra.get("seg_call_guidance", self.default_guidance)
        ctx["seg_call_guidance"] = dict(guidance)

        # 同时保持 extra 字典完整（约束层也从 ctx.extra 读）
        merged_extra = dict(extra)
        merged_extra["seg_call_guidance"] = guidance
        ctx["extra"] = merged_extra

        logger.debug("[InjectSegCallGuidance] guidance=%s", guidance)
        return ctx


# ─────────────────────────────────────────────────────────────────────────────
# 辅助：构建标准输入上下文（raw dict → Context）
# ─────────────────────────────────────────────────────────────────────────────

def make_input_context(raw: Dict[str, Any]) -> Context:
    """
    从 raw dict 创建初始 Context，并注入 raw 本身。
    各步骤通过 ctx.require("raw") 读取原始数据。
    """
    return Context(initial={"raw": raw})
