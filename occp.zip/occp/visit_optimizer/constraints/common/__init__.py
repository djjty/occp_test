"""constraints/common/__init__.py"""
from .common_hard import (
    CommonHardBounds,
    CommonHardRepWorkloadRange,
    CommonHardHcpWorkloadRange,
    CommonHardTotalVisitsRange,
    CommonHardChannelExclusive,
    CommonHardHcpChannelBounds,
    CommonHardRepChannelBounds,
)
from .common_soft import (
    CommonSoftRepWorkloadBalance,
    CommonSoftHcpWorkloadBalance,
    CommonSoftBudget,
    CommonSoftChannelBalance,
    CommonSoftHcpSegScore,
)
# 导入通用 Pipeline 步骤，触发注册到 PIPELINE_STEP_REGISTRY
from .common_input import (
    FillDefaultBounds,
    ParseHcpSegListing,
    ComputeListingBounds,
    ComputeCostMatrix,
    NormalizeTotalVisitsBounds,
    InjectSegCallGuidance,
    make_input_context,
)
from .common_output import (
    GenesTo3DArray,
    FlattenGenesToLongTable,
    AddMetaColumns,
    RoundVisitsToInt,
    FilterOutputColumns,
    make_output_context,
)

__all__ = [
    # 硬约束
    "CommonHardBounds", "CommonHardRepWorkloadRange", "CommonHardHcpWorkloadRange",
    "CommonHardTotalVisitsRange", "CommonHardChannelExclusive",
    "CommonHardHcpChannelBounds", "CommonHardRepChannelBounds",
    # 软约束
    "CommonSoftRepWorkloadBalance", "CommonSoftHcpWorkloadBalance",
    "CommonSoftBudget", "CommonSoftChannelBalance", "CommonSoftHcpSegScore",
    # 通用输入 Pipeline 步骤
    "FillDefaultBounds", "ParseHcpSegListing", "ComputeListingBounds",
    "ComputeCostMatrix", "NormalizeTotalVisitsBounds", "InjectSegCallGuidance",
    "make_input_context",
    # 通用输出 Pipeline 步骤
    "GenesTo3DArray", "FlattenGenesToLongTable", "AddMetaColumns",
    "RoundVisitsToInt", "FilterOutputColumns", "make_output_context",
]
