"""constraints/__init__.py"""
from .common import *           # noqa 注册通用约束
from . import brands            # noqa 自动扫描品牌约束
