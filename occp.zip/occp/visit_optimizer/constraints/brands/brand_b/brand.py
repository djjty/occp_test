"""
constraints/brands/brand_b/brand.py — 品牌 B 定义

渠道：face_to_face, email, conference
Pipeline 集成：声明式输入/输出处理步骤，品牌 B 的步骤顺序与 A 不同。
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional
import numpy as np

from ....core.base import BaseBrand, HardConstraint, SoftConstraint, Context
from ....optimizer.algorithms.base import BaseFitnessEvaluator
from ....core.registry import BRAND_REGISTRY
from ....constraints.common import (
    CommonHardBounds, CommonHardRepWorkloadRange, CommonHardHcpWorkloadRange,
    CommonHardTotalVisitsRange,
    CommonSoftChannelBalance, CommonSoftRepWorkloadBalance,
)
from .brand_b_soft import BrandBSoftConferenceCap, BrandBSoftHcpSegScoreAll
from ....optimizer.evaluators import DummyEvaluator


@BRAND_REGISTRY.register("brand_b")
class BrandB(BaseBrand):
    brand_id = "brand_b"
    CHANNELS = ["face_to_face", "email", "conference"]

    # ── 输入 Pipeline 步骤（品牌 B 的顺序与 A 不同）──────────────────────
    input_pipeline_steps: Optional[List] = [
        "fill_default_bounds",
        "parse_hcp_seg_listing",
        # 注意：brand_b 没有 compute_listing_bounds（不使用 listing）
        "compute_cost_matrix",
        "normalize_total_visits_bounds",
        "inject_seg_call_guidance",
    ]

    # ── 输出 Pipeline 步骤 ─────────────────────────────────────────────────
    # 注意：品牌B输出到不同的表结构，使用 FilterOutputColumns 过滤列
    output_pipeline_steps: Optional[List] = None  # 示例：品牌B暂不启用输出 Pipeline

    def _build_context_from_pipeline(self, ctx: Context) -> Context:
        """从 Context 构建 Context（品牌 B 版本）"""
        raw = ctx.require("raw")
        n_reps = raw["n_reps"]
        n_hcps = raw["n_hcps"]
        n_ch = len(self.CHANNELS)

        bounds_lo = ctx.get("bounds_lo", 0)
        # 不再限制每个基因的拜访上限
        bounds_hi = ctx.get("bounds_hi", 2**31 - 1)

        lo = np.full((n_reps, n_hcps, n_ch), bounds_lo, dtype=np.int32)
        hi = np.full((n_reps, n_hcps, n_ch), bounds_hi, dtype=np.int32)

        shared = ctx.to_shared_dict(keys=[
            "hcp_seg", "hcp_listing",
            "cost_matrix", "total_visits_bounds",
            "seg_call_guidance",
        ])
        shared["hcp_df"] = raw.get("hcp_df")
        shared["rep_df"] = raw.get("rep_df")

        return Context(
            brand_id=self.brand_id,
            channels=self.CHANNELS,
            bounds=np.stack([lo, hi], axis=-1),
            shared=shared,
            extra=ctx.get("extra", {}),
        )

    def build_context(self, raw: Dict[str, Any]) -> Context:
        n_reps, n_hcps, n_ch = raw["n_reps"], raw["n_hcps"], len(self.CHANNELS)
        lo = np.full((n_reps, n_hcps, n_ch), raw.get("bounds_lo", 0),  dtype=np.int32)
        hi = np.full((n_reps, n_hcps, n_ch), raw.get("bounds_hi", 2**31 - 1), dtype=np.int32)

        shared = {
            "hcp_seg":     raw.get("hcp_seg", []),
            "hcp_listing": raw.get("hcp_listing", [True] * n_hcps),
            "cost_matrix": raw.get("cost_matrix", np.ones((n_reps, n_hcps, n_ch))),
            "hcp_df":      raw.get("hcp_df"),
            "rep_df":      raw.get("rep_df"),
        }
        return Context(
            brand_id=self.brand_id,
            channels=self.CHANNELS,
            bounds=np.stack([lo, hi], axis=-1),
            shared=shared,
            extra=raw.get("extra", {}),
        )

    def get_hard_constraints(self) -> List[HardConstraint]:
        return [
            CommonHardBounds(),
            CommonHardRepWorkloadRange(lo_total=2),
            CommonHardHcpWorkloadRange(lo_total=0, hi_total=50),
        ]

    def get_soft_constraints(self, ctx: Context) -> List[SoftConstraint]:
        seg_cfg = ctx.extra.get("seg_call_guidance",
                                {"A": 5, "B": 3, "C": 2, "D": 1, "V": 1, "NA": 0})
        return [
            CommonSoftChannelBalance(weight=1.0),
            CommonSoftRepWorkloadBalance(weight=1.0),
            BrandBSoftConferenceCap(weight=2.0),
            BrandBSoftHcpSegScoreAll(seg_call_guidance=seg_cfg, sigma=1.0, weight=1.5),
        ]

    def get_fitness_evaluator(self) -> BaseFitnessEvaluator:
        return DummyEvaluator()

    def get_algorithm_key(self) -> str: return "ga"

    def get_algorithm_config(self) -> Dict[str, Any]:
        return {
            "pop_size": 120,
            "n_generations": 150,
            "cx_prob": 0.75,
            "mut_prob": 0.03,
            "penalty_weight": 1.0,
            "seed": 0,
            "log_every": 30,
        }
