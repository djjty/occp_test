"""
constraints/brands/brand_b/brand_b_soft.py — 品牌 B 专属软约束

conference 渠道拜访不超过 face_to_face，超出二次惩罚。
"""
from __future__ import annotations
from typing import Optional, List
import numpy as np

from ....core.base import SoftConstraint, Context
from ....optimizer.types import Individual
from ....core.registry import CONSTRAINT_REGISTRY


@CONSTRAINT_REGISTRY.register("brand_b_soft.conference_cap")
class BrandBSoftConferenceCap(SoftConstraint):
    """品牌 B：conference 次数不超过 face_to_face，超出二次惩罚"""
    description = "brand_b: conference <= face_to_face"

    def __init__(self, weight: float = 1.0):
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        try:
            ftf = ind.genes[:, :, ctx.channels.index("face_to_face")].astype(float)
            conf = ind.genes[:, :, ctx.channels.index("conference")].astype(float)
        except ValueError:
            return 0.0
        return float(np.sum(np.maximum(0.0, conf - ftf) ** 2))

    def normalize(self, raw: float, ctx: Context) -> float:
        max_v = float(ctx.n_reps * ctx.n_hcps * ctx.hi_max_safe ** 2)
        return raw / (max_v + 1e-9)


@CONSTRAINT_REGISTRY.register("brand_b_soft.hcp_seg_score_all_channels")
class BrandBSoftHcpSegScoreAll(SoftConstraint):
    """
    品牌 B：全渠道 HCP 分级评分（listing=False 的 hcp 也参与）。
    """
    description = "brand_b: 全渠道 HCP 分级评分"

    def __init__(self, seg_call_guidance: Optional[dict] = None,
                 sigma: float = 1.0, weight: float = 1.0):
        from ....constraints.common.common_soft import CommonSoftHcpSegScore
        guide = seg_call_guidance or {"A": 5, "B": 3, "C": 2, "D": 1, "V": 1, "NA": 0}
        self._inner = CommonSoftHcpSegScore(
            seg_call_guidance=guide, sigma=sigma,
            channels=None, listing_only=False, weight=weight,
        )
        self.weight = weight

    def raw_penalty(self, ind, ctx): return self._inner.raw_penalty(ind, ctx)
    def normalize(self, raw, ctx):   return self._inner.normalize(raw, ctx)
