"""
constraints/brands/__init__.py — 自动扫描并导入所有品牌子包

pkgutil 元编程：新增品牌只需建子目录，无需修改此文件。
"""
import importlib
import pkgutil
import pathlib

_brands_dir = pathlib.Path(__file__).parent
for _finder, _name, _ispkg in pkgutil.iter_modules([str(_brands_dir)]):
    if _ispkg:
        importlib.import_module(f".{_name}.brand", package=__package__)
