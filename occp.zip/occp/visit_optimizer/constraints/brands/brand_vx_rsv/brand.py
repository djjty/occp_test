"""
constraints/brands/brand_vx_rsv/brand.py — VX_RSV 品牌定义

VX_RSV（呼吸道合胞病毒疫苗）品牌：
  - 渠道：f2f, online_event
  - 优化算法：finite_diff（有限差分）/ GA
  - 硬约束：bounds + rep 工作量范围 + HCP 全渠道拜访限制 + Rep 全渠道工作量限制
  - 软约束：高优先级 HCP 最低拜访 + f2f 占比鼓励 + rep 工作量均衡 + HCP 分级评分

Pipeline 集成：使用公共输入/输出 Pipeline 步骤。
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional
import numpy as np

from ....core.base import BaseBrand, HardConstraint, SoftConstraint, Context
from ....optimizer.algorithms.base import BaseFitnessEvaluator
from ....core.registry import BRAND_REGISTRY
from ....constraints.common import (
    CommonHardBounds,
    CommonHardRepWorkloadRange,
    CommonHardHcpChannelBounds,
    CommonHardRepChannelBounds,
    CommonSoftRepWorkloadBalance,
    CommonSoftHcpSegScore,
)
from .brand_vx_rsv_soft import (
    BrandVxRsvSoftSegmentUrgency,
    BrandVxRsvSoftF2fPriority,
)
from ....optimizer.evaluators import DummyEvaluator


# ─────────────────────────────────────────────────────────────────────────────
# 品牌注册
# ─────────────────────────────────────────────────────────────────────────────

@BRAND_REGISTRY.register("vx_rsv")
class BrandVxRsv(BaseBrand):
    brand_id = "vx_rsv"
    CHANNELS = ["f2f", "online_event"]

    # ── 输入 Pipeline 步骤（使用公共步骤）────────────────────────────────
    input_pipeline_steps: Optional[List] = [
        "fill_default_bounds",
        "parse_hcp_seg_listing",
        "compute_cost_matrix",
        "normalize_total_visits_bounds",
        "inject_seg_call_guidance",
    ]

    # ── 输出 Pipeline 步骤 ───────────────────────────────────────────────
    output_pipeline_steps: Optional[List] = [
        "genes_to_3d_array",
        "flatten_genes_to_long_table",
        "add_meta_columns",
        "round_visits_to_int",
    ]

    def _build_context_from_pipeline(self, ctx: Context) -> Context:
        """从 Pipeline 上下文构建 Context（VX_RSV 版本）"""
        raw = ctx.require("raw")
        n_reps = raw["n_reps"]
        n_hcps = raw["n_hcps"]
        n_ch = len(self.CHANNELS)

        bounds_lo = ctx.get("bounds_lo", 0)
        # 不再限制每个基因的拜访上限
        bounds_hi = ctx.get("bounds_hi", 2**31 - 1)

        lo = np.full((n_reps, n_hcps, n_ch), bounds_lo, dtype=np.int32)
        hi = np.full((n_reps, n_hcps, n_ch), bounds_hi, dtype=np.int32)

        shared = ctx.to_shared_dict(keys=[
            "hcp_segment", "hcp_listing",
            "cost_matrix", "total_visits_bounds",
            "seg_call_guidance",
        ])
        # CommonSoftHcpSegScore 从 ctx.shared['hcp_seg'] 读取分级
        if "hcp_segment" in shared:
            shared["hcp_seg"] = shared["hcp_segment"]
        # 保留 polars DataFrame（如有）
        shared["hcp_df"] = raw.get("hcp_df")
        shared["rep_df"] = raw.get("rep_df")

        return Context(
            brand_id=self.brand_id,
            channels=self.CHANNELS,
            bounds=np.stack([lo, hi], axis=-1),
            shared=shared,
            extra=ctx.get("extra", {}),
        )

    def build_context(self, raw: Dict[str, Any]) -> Context:
        """构建 Context"""
        n_reps  = raw["n_reps"]
        n_hcps  = raw["n_hcps"]
        n_ch    = len(self.CHANNELS)

        lo = np.full((n_reps, n_hcps, n_ch), raw.get("bounds_lo", 0),  dtype=np.int32)
        # v23: ctx.hi 直接取 hcp_channel_bounds，让 optimizer 天然限制 NA 基因为 0
        if "hcp_channel_bounds" in raw:
            hcp_ch = raw["hcp_channel_bounds"]  # (n_hcps, n_ch, 2)
            hi = np.full((n_reps, n_hcps, n_ch), 0, dtype=np.int32)
            for h in range(n_hcps):
                for ch in range(n_ch):
                    gene_hi = int(hcp_ch[h, ch, 1])  # hi bound for this (hcp, channel)
                    hi[:, h, ch] = gene_hi
        else:
            hi = np.full((n_reps, n_hcps, n_ch), raw.get("bounds_hi", 2**31 - 1), dtype=np.int32)

        shared = {
            "hcp_segment":    raw.get("hcp_segment", []),
            "hcp_listing":    raw.get("hcp_listing", [True] * n_hcps),
            "cost_matrix":    raw.get("cost_matrix", np.ones((n_reps, n_hcps, n_ch))),
            "total_visits_bounds": raw.get("total_visits_bounds", None),
            # polars DataFrames（如有）
            "hcp_df": raw.get("hcp_df"),
            "rep_df": raw.get("rep_df"),
        }

        # CommonSoftHcpSegScore 从 ctx.shared['hcp_seg'] 读取分级
        hcp_segment = shared["hcp_segment"]
        if hcp_segment:
            shared["hcp_seg"] = hcp_segment

        # HCP per-channel bounds (n_hcps, n_channels, 2) — 分渠道约束
        if "hcp_channel_bounds" in raw:
            shared["hcp_channel_bounds"] = raw["hcp_channel_bounds"]

        # HCP 全渠道 bounds (n_hcps, 2) — 总体约束
        if "hcp_total_bounds" in raw:
            shared["hcp_total_bounds"] = raw["hcp_total_bounds"]

        # Rep per-channel bounds (n_reps, n_channels, 2) — 分渠道约束
        if "rep_channel_bounds" in raw:
            shared["rep_channel_bounds"] = raw["rep_channel_bounds"]

        # Rep 全渠道 bounds (n_reps, 2) — 总体约束
        if "rep_total_bounds" in raw:
            shared["rep_total_bounds"] = raw["rep_total_bounds"]

        # Rep-HCP 配对表:
        #   (n_reps, n_hcps, n_channels) — per-channel 配对表
        #   (n_reps, n_hcps) — 全渠道配对表（广播到所有渠道）
        if "assignment_mask" in raw:
            shared["assignment_mask"] = np.asarray(raw["assignment_mask"], dtype=bool)

        return Context(
            brand_id=self.brand_id,
            channels=self.CHANNELS,
            bounds=np.stack([lo, hi], axis=-1),
            shared=shared,
            extra=raw.get("extra", {}),
        )

    def get_hard_constraints(self) -> List[HardConstraint]:
        return [
            CommonHardBounds(),
            CommonHardRepWorkloadRange(lo_total=1),
            # Per-channel HCP bounds: 每个渠道独立约束
            CommonHardHcpChannelBounds(
                channels=self.CHANNELS,
                default_lo=0,
                default_hi=10,
            ),
            # Per-channel Rep bounds: 每个渠道独立约束
            CommonHardRepChannelBounds(
                channels=self.CHANNELS,
                default_lo=30,
                default_hi=100,
            ),
            # Overall (all-channel) HCP bounds: 总体约束
            CommonHardHcpChannelBounds(channels=None, default_lo=0, default_hi=10),
            # Overall (all-channel) Rep bounds: 总体约束
            CommonHardRepChannelBounds(channels=None, default_lo=60, default_hi=100),
        ]

    # 默认分级推荐拜访次数（A/B/C/D/NA）
    DEFAULT_SEG_GUIDANCE = {"A": 6, "B": 3, "C": 1, "D": 1, "NA": 0}
    # 默认分级最低拜访次数（A/B 必须达到最低次数）
    DEFAULT_SEG_MIN = {"A": 6, "B": 3, "C": 1, "D": 1, "NA": 0}

    def get_soft_constraints(self, ctx: Context) -> List[SoftConstraint]:
        # 从 extra 或 shared 中获取 seg_call_guidance（分级→推荐拜访次数）
        guidance = ctx.extra.get("seg_call_guidance", ctx.shared.get("seg_call_guidance", None))
        if guidance is None:
            guidance = self.DEFAULT_SEG_GUIDANCE

        # 从 extra 或 shared 中获取 seg_min（分级→最低拜访次数）
        seg_min = ctx.extra.get("seg_min", ctx.shared.get("seg_min", None))
        if seg_min is None:
            seg_min = self.DEFAULT_SEG_MIN

        return [
            CommonSoftRepWorkloadBalance(weight=1.0),
            BrandVxRsvSoftSegmentUrgency(
                seg_min=seg_min,
                weight=2.0,
            ),
            BrandVxRsvSoftF2fPriority(
                target_ratio=0.5, weight=1.0,
            ),
            CommonSoftHcpSegScore(
                seg_call_guidance=guidance,
                sigma=1.0,
                weight=1.5,
            ),
        ]

    def get_fitness_evaluator(self) -> BaseFitnessEvaluator:
        return DummyEvaluator()

    def get_algorithm_key(self) -> str:
        return "finite_diff"

    def get_algorithm_config(self) -> Dict[str, Any]:
        return {
            "n_iterations": 30,
            "step": 1,
            "penalty_weight": 1.0,
            "seed": 42,
            "log_every": 10,
        }
