"""
constraints/brands/brand_vx_rsv/brand_vx_rsv_soft.py — VX_RSV 品牌专属软约束

疫苗（RSV）品牌场景：
  1. SegmentUrgency — 高优先级分级（A/B/C/D/NA）的 HCP 最低拜访次数不足惩罚
  2. F2fPriority — 鼓励更多 f2f 拜访（与 online_event 比例平衡）
"""
from __future__ import annotations
from typing import Dict, List, Optional
import numpy as np

from ....core.base import SoftConstraint, Context
from ....optimizer.types import Individual
from ....core.registry import CONSTRAINT_REGISTRY

# 默认分级最低拜访次数映射（向后兼容旧的 p1/p2/p3 分级和新的 A/B/C/D/NA 分级）
_DEFAULT_SEG_MIN: Dict[str, int] = {
    # 新分级 A/B/C/D/NA
    "A": 6, "B": 3, "C": 1, "D": 1, "NA": 0,
    # 旧分级 p1/p2/p3（向后兼容）
    "p1": 6, "p2": 3, "p3": 1,
}


@CONSTRAINT_REGISTRY.register("brand_vx_rsv_soft.segment_urgency")
class BrandVxRsvSoftSegmentUrgency(SoftConstraint):
    """
    VX_RSV：高优先级 HCP 最低拜访次数不足惩罚。

    从 ctx.shared['hcp_segment'] 读取分级（支持 A/B/C/D/NA 或旧的 p1/p2/p3）。
    每个分级 HCP 的总拜访次数不足 seg_min[seg] 时产生惩罚。

    参数：
        seg_min   dict[str, int]   分级 -> 最低拜访次数，None 时使用内置默认值
                  新分级示例：{"A":6, "B":3, "C":1, "D":1, "NA":0}
        channels  list[str]|None  限定渠道，None=全渠道
        weight    float
    """
    description = "vx_rsv: 高优先级 HCP 最低拜访惩罚"

    def __init__(
        self,
        seg_min: Optional[Dict[str, int]] = None,
        channels: Optional[List[str]] = None,
        weight: float = 2.0,
        # 向后兼容旧参数
        p1_min: Optional[int] = None,
        p2_min: Optional[int] = None,
    ):
        # 构建 seg_min 映射
        if seg_min is not None:
            self.seg_min = dict(seg_min)
        else:
            self.seg_min = dict(_DEFAULT_SEG_MIN)
        # 向后兼容：如果仍然传了 p1_min/p2_min，覆盖对应键
        if p1_min is not None:
            self.seg_min["p1"] = p1_min
            self.seg_min["A"] = p1_min
        if p2_min is not None:
            self.seg_min["p2"] = p2_min
            self.seg_min["B"] = p2_min

        self.channels = channels
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        segments: List[str] = ctx.shared.get("hcp_segment", [])
        if not segments:
            return 0.0

        ch_idx = (
            [ctx.channels.index(c) for c in self.channels if c in ctx.channels]
            if self.channels
            else list(range(ctx.n_channels))
        )
        if not ch_idx:
            return 0.0

        penalty = 0.0
        for i, seg in enumerate(segments):
            min_visits = self.seg_min.get(seg, 0)
            if min_visits <= 0:
                continue
            visits = float(ind.genes[:, i, :][:, ch_idx].sum())
            if visits < min_visits:
                shortfall = min_visits - visits
                # 高优先级（A/p1）用平方惩罚，其余用线性惩罚
                if seg in ("A", "p1"):
                    penalty += shortfall ** 2
                else:
                    penalty += shortfall

        return penalty

    def normalize(self, raw: float, ctx: Context) -> float:
        segments: List[str] = ctx.shared.get("hcp_segment", [])
        # 统计有最低要求的 HCP 数量
        n_high = sum(1 for s in segments if self.seg_min.get(s, 0) > 0)
        if n_high == 0:
            return 0.0
        max_min = max(self.seg_min.values()) if self.seg_min else 6
        max_pen = max_min ** 3  # 粗略上界
        return min(raw / (max_pen * n_high + 1e-9), 1.0)


@CONSTRAINT_REGISTRY.register("brand_vx_rsv_soft.f2f_priority")
class BrandVxRsvSoftF2fPriority(SoftConstraint):
    """
    VX_RSV：鼓励更多 f2f 拜访。
    当 f2f 占比低于 target_ratio 时产生惩罚（线性）。
    f2f_channel 默认为 "f2f"，可通过参数覆盖。
    """
    description = "vx_rsv: f2f 占比不足惩罚"

    def __init__(self, target_ratio: float = 0.5, weight: float = 1.0,
                 f2f_channel: str = "f2f"):
        self.target_ratio = target_ratio
        self.weight = weight
        self.f2f_channel = f2f_channel

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        try:
            f2f_idx = ctx.channels.index(self.f2f_channel)
        except ValueError:
            return 0.0

        f2f_total = float(ind.genes[:, :, f2f_idx].sum())
        all_total = float(ind.genes.sum())
        if all_total < 1e-9:
            return 0.0

        actual_ratio = f2f_total / all_total
        if actual_ratio >= self.target_ratio:
            return 0.0

        shortfall = self.target_ratio - actual_ratio
        return shortfall * all_total  # 按总量缩放

    def normalize(self, raw: float, ctx: Context) -> float:
        max_total = float(ctx.n_reps * ctx.n_hcps * ctx.hi_max_safe)
        return min(raw / (max_total + 1e-9), 1.0)
