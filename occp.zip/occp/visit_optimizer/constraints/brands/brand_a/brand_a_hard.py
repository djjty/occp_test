"""
constraints/brands/brand_a/brand_a_hard.py — 品牌 A 专属硬约束

品牌 A 场景：
  - hcp 有 listing 状态（True/False），listing 影响拜访次数上下限
  - listing=True  的 hcp：每个 (rep, hcp) 总拜访次数上下限 [0, 10]
  - listing=False 的 hcp：每个 (rep, hcp) 总拜访次数上下限 [0, 8]
"""
from __future__ import annotations
import numpy as np
from ....core.base import HardConstraint, Context
from ....optimizer.types import Individual
from ....core.registry import CONSTRAINT_REGISTRY


@CONSTRAINT_REGISTRY.register("brand_a_hard.listing_workload")
class BrandAHardListingWorkload(HardConstraint):
    """
    品牌 A 专属：按 hcp listing 状态限制每个 (rep, hcp) 的总拜访次数。

    参数（可被 ctx.shared['listing_bounds'] 覆盖）：
        lo_listing     int   listing=True  时下限，默认 0
        hi_listing     int   listing=True  时上限，默认 10
        lo_unlisting   int   listing=False 时下限，默认 0
        hi_unlisting   int   listing=False 时上限，默认 8
    """
    description = "brand_a: listing 状态决定 hcp 工作量上下限"

    def __init__(self, lo_listing: int = 0, hi_listing: int = 10,
                 lo_unlisting: int = 0, hi_unlisting: int = 8):
        self.lo_listing = lo_listing
        self.hi_listing = hi_listing
        self.lo_unlisting = lo_unlisting
        self.hi_unlisting = hi_unlisting

    def _get_bounds(self, ctx: Context):
        """返回 per-hcp 的 (lo_arr, hi_arr)，shape (n_hcps,)"""
        override = ctx.shared.get("listing_bounds")   # optional (n_hcps, 2) array
        if override is not None:
            return override[:, 0], override[:, 1]

        listing: list = ctx.shared.get("hcp_listing", [])
        if not listing or len(listing) != ctx.n_hcps:
            lo_arr = np.zeros(ctx.n_hcps, dtype=np.int32)
            hi_arr = np.full(ctx.n_hcps, self.hi_listing, dtype=np.int32)
            return lo_arr, hi_arr

        lo_arr = np.where(listing, self.lo_listing, self.lo_unlisting).astype(np.int32)
        hi_arr = np.where(listing, self.hi_listing, self.hi_unlisting).astype(np.int32)
        return lo_arr, hi_arr

    def check(self, ind: Individual, ctx: Context) -> bool:
        lo_arr, hi_arr = self._get_bounds(ctx)
        # per-hcp 总拜访 = sum over reps and channels → (n_hcps,)
        hcp_totals = ind.genes.sum(axis=(0, 2))
        return bool(np.all(hcp_totals >= lo_arr) and np.all(hcp_totals <= hi_arr))

    def repair(self, genes: np.ndarray, ctx: Context, rng) -> np.ndarray:
        lo_arr, hi_arr = self._get_bounds(ctx)
        for h in range(ctx.n_hcps):
            total = genes[:, h, :].sum()
            limit = hi_arr[h]
            if total > limit:
                # 按比例缩放该 hcp 的所有拜访次数
                scale = limit / (total + 1e-9)
                genes[:, h, :] = np.floor(genes[:, h, :] * scale).astype(np.int32)
        return genes
