"""
constraints/brands/brand_a/brand_a_output.py — 品牌 A 专属输出处理步骤

品牌 A 独有的输出数据处理逻辑，通过在 brand.py 中 import 触发注册。
注册使用 core/registry.py 中的 PIPELINE_STEP_REGISTRY。

目前品牌 A 的输出 Pipeline 使用公共步骤（genes_to_3d_array 等），
此文件预留品牌 A 扩展输出逻辑的空间。
"""
from __future__ import annotations
import logging
from typing import Any, Dict, List, Optional

from ....core.base import PipelineStep, Context
from ....core.registry import PIPELINE_STEP_REGISTRY

logger = logging.getLogger(__name__)


@PIPELINE_STEP_REGISTRY.register("brand_a_enrich_output")
class BrandAEnrichOutput(PipelineStep):
    """
    品牌 A 专属：为输出行添加品牌 A 特有的字段（如 territory、product_line 等）。

    ctx 依赖：output_rows (List[Dict])
    ctx 写入：output_rows（追加 brand_a_version 字段）

    注意：此步骤为预留扩展，默认仅添加 brand_a_version 标记。
    """
    name = "brand_a_enrich_output"

    def __init__(self, version: str = "v1", extra_fields: Optional[Dict[str, Any]] = None):
        self.version = version
        self.extra_fields = extra_fields or {}

    def process(self, ctx: Context) -> Context:
        rows: List[Dict] = ctx.require("output_rows")
        for row in rows:
            row["brand_a_version"] = self.version
            for k, v in self.extra_fields.items():
                row[k] = v
        logger.debug("[BrandAEnrichOutput] enriched %d rows with version=%s",
                     len(rows), self.version)
        return ctx
