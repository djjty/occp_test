"""
constraints/brands/brand_a/brand.py — 品牌 A 定义

渠道：face_to_face, remote_call, digital
Pipeline 集成：声明式输入/输出处理步骤。

品牌专属步骤（brand_a_input.py / brand_a_output.py）通过 import 触发注册，
然后在 input_pipeline_steps / output_pipeline_steps 中通过注册键字符串引用。
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional
import numpy as np

from ....core.base import BaseBrand, HardConstraint, SoftConstraint, Context
from ....optimizer.algorithms.base import BaseFitnessEvaluator
from ....core.registry import BRAND_REGISTRY
from ....constraints.common import (
    CommonHardBounds, CommonHardRepWorkloadRange, CommonHardChannelExclusive,
    CommonHardTotalVisitsRange,
    CommonSoftRepWorkloadBalance, CommonSoftHcpSegScore,
)
from .brand_a_hard import BrandAHardListingWorkload
from .brand_a_soft import BrandASoftHcpMinVisitTierA, BrandASoftChannelExclusivePenalty
from ....optimizer.evaluators import DummyEvaluator

# 导入品牌专属 Pipeline 步骤，触发注册到 PIPELINE_STEP_REGISTRY
from . import brand_a_input  # noqa: F401 — 触发 BrandADigitalChannelCap 注册
from . import brand_a_output  # noqa: F401 — 触发 BrandAEnrichOutput 注册


# ─────────────────────────────────────────────────────────────────────────────
# 品牌注册
# ─────────────────────────────────────────────────────────────────────────────

@BRAND_REGISTRY.register("brand_a")
class BrandA(BaseBrand):
    brand_id = "brand_a"
    CHANNELS = ["face_to_face", "remote_call", "digital"]

    # ── 输入 Pipeline 步骤（声明式顺序）────────────────────────────────────
    # 公共步骤通过注册键字符串引用，品牌专属步骤同样使用注册键
    # 所有步骤均已通过 import 触发注册到 core/registry.py 的 PIPELINE_STEP_REGISTRY
    input_pipeline_steps: Optional[List] = [
        "fill_default_bounds",              # 公共步骤（constraints/common/common_input.py）
        "parse_hcp_seg_listing",            # 公共步骤
        "compute_listing_bounds",           # 公共步骤
        "brand_a_digital_channel_cap",      # 品牌专属（brand_a_input.py）
        "compute_cost_matrix",              # 公共步骤
        "normalize_total_visits_bounds",    # 公共步骤
        "inject_seg_call_guidance",         # 公共步骤
    ]

    # ── 输出 Pipeline 步骤 ─────────────────────────────────────────────────
    output_pipeline_steps: Optional[List] = [
        "genes_to_3d_array",
        "flatten_genes_to_long_table",
        "add_meta_columns",
        "round_visits_to_int",
    ]

    def _build_context_from_pipeline(self, ctx: Context) -> Context:
        """
        从 Context 构建 Context。
        Pipeline 已将所有中间数据写入 ctx，这里负责组装最终的 Context。
        """
        raw = ctx.require("raw")
        n_reps = raw["n_reps"]
        n_hcps = raw["n_hcps"]
        n_ch = len(self.CHANNELS)

        bounds_lo = ctx.get("bounds_lo", 0)
        # 不再限制每个基因的拜访上限；由 listing/digital 等渠道级约束控制
        bounds_hi = ctx.get("bounds_hi", 2**31 - 1)

        lo = np.full((n_reps, n_hcps, n_ch), bounds_lo, dtype=np.int32)
        hi = np.full((n_reps, n_hcps, n_ch), bounds_hi, dtype=np.int32)

        # brand_a 特有：digital 渠道上限更低
        dig_cap = ctx.get("brand_a_digital_channel_cap", 5)
        dig_idx = self.CHANNELS.index("digital")
        hi[:, :, dig_idx] = np.minimum(hi[:, :, dig_idx], dig_cap)

        shared = ctx.to_shared_dict(keys=[
            "hcp_seg", "hcp_listing", "listing_bounds",
            "cost_matrix", "total_visits_bounds",
            "seg_call_guidance",
        ])
        # 保留 polars DataFrame
        shared["hcp_df"] = raw.get("hcp_df")
        shared["rep_df"] = raw.get("rep_df")

        return Context(
            brand_id=self.brand_id,
            channels=self.CHANNELS,
            bounds=np.stack([lo, hi], axis=-1),
            shared=shared,
            extra=ctx.get("extra", {}),
        )

    def build_context(self, raw: Dict[str, Any]) -> Context:
        """
        构建 Context。
        当 input_pipeline_steps 非空时由 BrandProblem.from_brand() 通过
        Pipeline 自动调用 _build_context_from_pipeline()。
        """
        n_reps  = raw["n_reps"]
        n_hcps  = raw["n_hcps"]
        n_ch    = len(self.CHANNELS)

        lo = np.full((n_reps, n_hcps, n_ch), raw.get("bounds_lo", 0),  dtype=np.int32)
        hi = np.full((n_reps, n_hcps, n_ch), raw.get("bounds_hi", 2**31 - 1), dtype=np.int32)

        # brand_a 特有：digital 渠道上限更低
        dig_idx = self.CHANNELS.index("digital")
        hi[:, :, dig_idx] = np.minimum(hi[:, :, dig_idx], 5)

        # listing 状态驱动的 per-hcp 上下限矩阵存入 shared
        hcp_listing = raw.get("hcp_listing", [True] * n_hcps)
        listing_arr  = np.array(hcp_listing, dtype=bool)
        listing_bounds = np.stack([
            np.zeros(n_hcps, dtype=np.int32),
            np.where(listing_arr, 10, 8).astype(np.int32),
        ], axis=1)  # (n_hcps, 2)

        shared = {
            "hcp_listing":          hcp_listing,
            "listing_bounds":       listing_bounds,
            "hcp_seg":              raw.get("hcp_seg", []),
            "cost_matrix":          raw.get("cost_matrix", np.ones((n_reps, n_hcps, n_ch))),
            "total_visits_bounds":  raw.get("total_visits_bounds", None),
            # polars DataFrames（如有）
            "hcp_df":  raw.get("hcp_df"),
            "rep_df":  raw.get("rep_df"),
        }

        return Context(
            brand_id=self.brand_id,
            channels=self.CHANNELS,
            bounds=np.stack([lo, hi], axis=-1),
            shared=shared,
            extra=raw.get("extra", {}),
        )

    def get_hard_constraints(self) -> List[HardConstraint]:
        return [
            CommonHardBounds(),
            CommonHardRepWorkloadRange(lo_total=1),
            CommonHardChannelExclusive(exclusive_channels=["remote_call", "digital"]),
            BrandAHardListingWorkload(),
        ]

    def get_soft_constraints(self, ctx: Context) -> List[SoftConstraint]:
        seg_cfg = ctx.extra.get("seg_call_guidance",
                                {"A": 5, "B": 3, "C": 2, "D": 1, "V": 1, "NA": 0})
        return [
            CommonSoftRepWorkloadBalance(weight=1.0),
            CommonSoftHcpSegScore(
                seg_call_guidance=seg_cfg,
                sigma=1.5,
                listing_only=True,
                weight=2.0,
            ),
            BrandASoftHcpMinVisitTierA(min_visits=3, weight=1.5),
            BrandASoftChannelExclusivePenalty(weight=0.5),
        ]

    def get_fitness_evaluator(self) -> BaseFitnessEvaluator:
        return DummyEvaluator()

    def get_algorithm_key(self) -> str: return "ga"

    def get_algorithm_config(self) -> Dict[str, Any]:
        return {
            "pop_size": 100,
            "n_generations": 200,
            "cx_prob": 0.8,
            "mut_prob": 0.02,
            "penalty_weight": 1.0,
            "seed": 42,
            "log_every": 50,
        }
