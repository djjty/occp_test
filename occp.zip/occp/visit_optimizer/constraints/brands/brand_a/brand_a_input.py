"""
constraints/brands/brand_a/brand_a_input.py — 品牌 A 专属输入处理步骤

品牌 A 独有的数据处理逻辑，通过在 brand.py 中 import 触发注册。
注册使用 core/registry.py 中的 PIPELINE_STEP_REGISTRY。
"""
from __future__ import annotations
import logging

from ....core.base import PipelineStep, Context
from ....core.registry import PIPELINE_STEP_REGISTRY

logger = logging.getLogger(__name__)


@PIPELINE_STEP_REGISTRY.register("brand_a_digital_channel_cap")
class BrandADigitalChannelCap(PipelineStep):
    """
    品牌 A 专属：digital 渠道上限更低（max=5）。
    这个步骤在 ComputeListingBounds 之后执行，向 ctx 写入 digital cap。

    ctx 依赖：raw（n_reps, n_hcps）
    ctx 写入：brand_a_digital_cap (int)
    """
    name = "brand_a_digital_channel_cap"

    def __init__(self, max_digital: int = 5):
        self.max_digital = max_digital

    def process(self, ctx: Context) -> Context:
        ctx["brand_a_digital_channel_cap"] = self.max_digital
        logger.debug("[BrandADigitalChannelCap] digital cap=%d", self.max_digital)
        return ctx
