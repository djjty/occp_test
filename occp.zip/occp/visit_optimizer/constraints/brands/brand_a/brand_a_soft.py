"""
constraints/brands/brand_a/brand_a_soft.py — 品牌 A 专属软约束

示例：
  1. remote_call 与 digital 渠道互斥惩罚（软版本）
  2. A 类 HCP 最低拜访次数不足惩罚
"""
from __future__ import annotations
from typing import List, Optional
import numpy as np

from ....core.base import SoftConstraint, Context
from ....optimizer.types import Individual
from ....core.registry import CONSTRAINT_REGISTRY


@CONSTRAINT_REGISTRY.register("brand_a_soft.hcp_min_visit_tier_a")
class BrandASoftHcpMinVisitTierA(SoftConstraint):
    """
    品牌 A：A 类 HCP（hcp_seg=='A'）的总拜访次数不足 min_visits 时惩罚。
    从 ctx.shared['hcp_seg'] 读取分级。
    """
    description = "brand_a: A 类 HCP 最低拜访次数"

    def __init__(self, min_visits: int = 3, channels: Optional[List[str]] = None,
                 weight: float = 1.0):
        self.min_visits = min_visits
        self.channels = channels
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        hcp_seg: List[str] = ctx.shared.get("hcp_seg", [])
        a_idx = [i for i, s in enumerate(hcp_seg) if s == "A"]
        if not a_idx:
            return 0.0
        ch_idx = ([ctx.channels.index(c) for c in self.channels if c in ctx.channels]
                  if self.channels else list(range(ctx.n_channels)))
        visits = ind.genes[:, a_idx, :][:, :, ch_idx].sum(axis=(0, 2))  # (n_a,)
        return float(np.maximum(0, self.min_visits - visits).sum())

    def normalize(self, raw: float, ctx: Context) -> float:
        hcp_seg = ctx.shared.get("hcp_seg", [])
        n_a = max(1, sum(1 for s in hcp_seg if s == "A"))
        return raw / (n_a * self.min_visits + 1e-9)


@CONSTRAINT_REGISTRY.register("brand_a_soft.channel_exclusive_penalty")
class BrandASoftChannelExclusivePenalty(SoftConstraint):
    """
    品牌 A：remote_call 与 digital 同时出现时的软惩罚（互斥的软版本）。
    """
    description = "brand_a: remote_call 与 digital 尽量不同时使用"

    def __init__(self, exclusive_channels: Optional[List[str]] = None,
                 weight: float = 1.0):
        self.exclusive_channels = exclusive_channels or ["remote_call", "digital"]
        self.weight = weight

    def raw_penalty(self, ind: Individual, ctx: Context) -> float:
        idxs = [ctx.channels.index(c) for c in self.exclusive_channels if c in ctx.channels]
        if len(idxs) < 2:
            return 0.0
        subset = ind.genes[:, :, idxs].astype(float)    # (n_reps, n_hcps, k)
        both_nonzero = np.all(subset > 0, axis=2)        # (n_reps, n_hcps)
        overlap = subset.min(axis=2) * both_nonzero      # 重叠量
        return float(overlap.sum())

    def normalize(self, raw: float, ctx: Context) -> float:
        max_v = float(ctx.n_reps * ctx.n_hcps * ctx.hi_max_safe)
        return raw / (max_v + 1e-9)
