"""
optimizer/_utils.py — 算法公共工具函数（矩阵运算加速）

所有函数纯 numpy，无副作用，可被任意算法调用。

批量并行采样（v8 新增）：
  - oversample_batch()    一次性生成 N×M 个候选，并行 repair + check，取前 N 个通过的
  - batch_random_genes()  向量化批量随机生成
  - batch_satisfies_hard() 4D tensor 级别批量约束检查
  - batch_repair_genes()  对整个 batch 逐约束执行 repair

约束感知初始化（v17 新增）：
  - constraint_aware_random_genes()    在所有硬约束范围内随机分配基因
  - constraint_aware_batch_random()    批量版本
  - _fill_rep_aware()                 核心分配逻辑：先填正常 HCP，再填 spillover
"""
from __future__ import annotations
import logging
from typing import List, Optional, Tuple

import numpy as np

from ..core.base import HardConstraint, Context
from .types import Individual

logger = logging.getLogger(__name__)


# ═════════════════════════════════════════════════════════════════════════════
# 基础工具函数（保持向后兼容）
# ═════════════════════════════════════════════════════════════════════════════

def random_genes(ctx: Context, rng: np.random.Generator) -> np.ndarray:
    """在 bounds 内批量均匀随机生成整数基因 (n_reps, n_hcps, n_channels)"""
    lo, hi = ctx.lo, ctx.hi
    # 当 per-gene bounds 未设限（hi 很大）时，使用合理上限生成随机值
    # 避免 int32 溢出和生成不切实际的极大值
    if np.any(hi >= 2**31 - 1):
        # 优先从 HCP per-channel bounds 推断合理上限（更精确）
        hcp_ch = ctx.shared.get("hcp_channel_bounds")
        rep_ch = ctx.shared.get("rep_channel_bounds")
        effective_hi = 100  # 默认值

        if hcp_ch is not None and hcp_ch.ndim >= 3:
            # 使用 per-channel HCP hi 的最小值（避免生成远超 HCP 容量的随机值）
            effective_hi = min(int(hcp_ch[:, :, 1].min()), effective_hi)
        elif hcp_ch is None:
            hcp_hi = ctx.shared.get("hcp_total_bounds")
            if hcp_hi is not None and hcp_hi.ndim >= 2:
                effective_hi = min(int(hcp_hi[:, 1].max()), 1000)

        # 也考虑 rep per-channel bounds 作为参考
        if rep_ch is not None and rep_ch.ndim >= 3:
            rep_ch_hi = int(rep_ch[:, :, 1].min())
            # 每个 rep 分配到 n_hcps 个 HCP，每个基因不应超过 rep channel hi / n_hcps
            per_gene_from_rep = max(1, rep_ch_hi // ctx.n_hcps)
            effective_hi = min(effective_hi, per_gene_from_rep)

        effective_hi = max(effective_hi, 1)
        result = rng.integers(lo, effective_hi + 1, size=ctx.shape, dtype=np.int32)
        return np.clip(result, lo, hi).astype(np.int32)
    return rng.integers(lo, hi + 1, size=ctx.shape, dtype=np.int32)


def batch_random_genes(n: int, ctx: Context,
                        rng: np.random.Generator) -> np.ndarray:
    """一次生成 n 个个体，返回 (n, n_reps, n_hcps, n_channels)"""
    lo = ctx.lo[np.newaxis]  # broadcast
    hi = ctx.hi[np.newaxis]
    # 当 per-gene bounds 未设限时，使用合理上限生成随机值
    if np.any(hi >= 2**31 - 1):
        hcp_hi = ctx.shared.get("hcp_total_bounds")
        if hcp_hi is not None and hcp_hi.ndim >= 2:
            effective_hi = min(int(hcp_hi[:, 1].max()), 1000)
        else:
            effective_hi = 100
        effective_hi = max(effective_hi, 1)
        result = rng.integers(lo, effective_hi + 1, size=(n, *ctx.shape), dtype=np.int32)
        return np.clip(result, lo, hi).astype(np.int32)
    return rng.integers(lo, hi + 1, size=(n, *ctx.shape), dtype=np.int32)


# ═════════════════════════════════════════════════════════════════════════════
# 约束感知初始化（v17 — 先填正常 HCP，再填 spillover）
# ═════════════════════════════════════════════════════════════════════════════

def _get_spillover_mask(ctx: Context) -> Optional[np.ndarray]:
    """获取 spillover HCP mask：segment 为 'NA' 的 HCP。"""
    segments = ctx.shared.get("hcp_segment")
    if not segments:
        return None
    mask = np.array([s == "NA" for s in segments], dtype=bool)
    return mask if mask.any() else None


def _get_assignment_mask(ctx: Context) -> Optional[np.ndarray]:
    """获取 rep-hcp 配对表 (n_reps, n_hcps) bool。"""
    mask = ctx.shared.get("assignment_mask")
    if mask is None:
        return None
    mask = np.asarray(mask, dtype=bool)
    if mask.ndim == 3:
        return mask.any(axis=2)  # OR across channels
    return mask


def _fill_rep_aware(
    r: int,
    ctx: Context,
    rng: np.random.Generator,
    genes: np.ndarray,
    spillover_mask: Optional[np.ndarray],
    assignment_mask: Optional[np.ndarray],
    rep_target: Optional[int] = None,
) -> np.ndarray:
    """
    为单个 rep r 约束感知地分配基因。

    genes: (n_reps, n_hcps, n_ch) 完整基因矩阵（其他 rep 的已有分配作为 HCP 总量计算依据）
    返回: 该 rep 的基因切片 (n_hcps, n_ch)

    策略（v19 修正）：
      1. rep 工作量**必须**达到下限（强制填充直到 rep_lo 满足）
      2. 优先分配给正常 HCP（A/B/C/D），不超过 HCP 和 Rep 的约束
      3. 正常 HCP 有空间时，**持续填充**直到满或达到 rep 目标
      4. 只有当所有可访问的正常 HCP 均达上限时，才分配给 spillover HCP（NA）
      5. 如果连 NA 也全满仍达不到下界，则接受低于下界（松弛）
    """
    n_hcps = ctx.n_hcps
    n_ch = ctx.n_channels

    # ── 确定 rep 的工作量上下界 ──
    rep_ch = ctx.shared.get("rep_channel_bounds")  # (n_reps, n_ch, 2)
    if rep_ch is not None and rep_ch.ndim == 3:
        rep_lo = int(rep_ch[r, :, 0].sum())
        rep_hi = int(rep_ch[r, :, 1].sum())
    else:
        rep_bounds = ctx.shared.get("rep_total_bounds")  # (n_reps, 2)
        if rep_bounds is not None:
            rep_lo, rep_hi = int(rep_bounds[r, 0]), int(rep_bounds[r, 1])
        else:
            rep_lo, rep_hi = 1, 99999

    # v19: 目标必须至少为 rep_lo（强制达到下限）
    if rep_target is not None:
        target = min(max(rep_target, rep_lo), rep_hi)
    else:
        target = rng.integers(rep_lo, rep_hi + 1)

    # ── 确定 rep 可以访问的 HCP ──
    if assignment_mask is not None:
        accessible = assignment_mask[r]  # (n_hcps,) bool
    else:
        accessible = np.ones(n_hcps, dtype=bool)

    # ── 确定 HCP 的约束上限 ──
    hcp_ch = ctx.shared.get("hcp_channel_bounds")  # (n_hcps, n_ch, 2)
    hcp_total = ctx.shared.get("hcp_total_bounds")  # (n_hcps, 2)

    remaining = target

    # ── Phase 1: 持续填充正常 HCP 直到达到目标或全满 ──
    if spillover_mask is not None:
        normal_mask = ~spillover_mask & accessible
    else:
        normal_mask = accessible.copy()

    if normal_mask.any():
        normal_indices_all = np.where(normal_mask)[0]

        # 外层循环：持续多轮填充，直到 remaining=0 或一轮内完全无法填充
        max_rounds = 100  # 防止无限循环
        for _ in range(max_rounds):
            if remaining <= 0:
                break

            filled_this_round = 0
            # 每轮随机顺序
            normal_indices = normal_indices_all.copy()
            rng.shuffle(normal_indices)

            for h in normal_indices:
                if remaining <= 0:
                    break
                for ch in range(n_ch):
                    if remaining <= 0:
                        break
                    room = _compute_gene_room(
                        genes, r, h, ch, ctx, rep_ch, hcp_ch, hcp_total,
                    )
                    if room <= 0:
                        continue
                    # 尽可能多填（但留一点随机性）
                    fill = min(room, remaining)
                    if fill > 1 and rng.random() < 0.3:
                        fill = rng.integers(1, fill + 1)
                    genes[r, h, ch] += fill
                    remaining -= fill
                    filled_this_round += fill

            # 如果一整轮都没填进去，说明正常 HCP 全满了
            if filled_this_round == 0:
                break

    # ── Phase 2: 正常 HCP 全满后，用 NA 填充剩余 ──
    if spillover_mask is not None and remaining > 0:
        # 再次确认正常 HCP 确实全满
        normal_has_room = False
        if normal_mask.any():
            for h in np.where(normal_mask)[0]:
                for ch in range(n_ch):
                    if _compute_gene_room(genes, r, h, ch, ctx, rep_ch, hcp_ch, hcp_total) > 0:
                        normal_has_room = True
                        break
                if normal_has_room:
                    break

        if not normal_has_room:
            # 正常 HCP 全满，可以给 NA 分配
            sp_indices = np.where(spillover_mask & accessible)[0]
            rng.shuffle(sp_indices)
            for h in sp_indices:
                if remaining <= 0:
                    break
                for ch in range(n_ch):
                    if remaining <= 0:
                        break
                    room = _compute_gene_room(
                        genes, r, h, ch, ctx, rep_ch, hcp_ch, hcp_total,
                    )
                    if room <= 0:
                        continue
                    fill = min(room, remaining)
                    genes[r, h, ch] += fill
                    remaining -= fill

    # v20: 如果该 rep 有 NA 权限但还有剩余，说明 NA 也全满了，接受低于下界
    # 如果没有 NA 权限，正常 HCP 全满后也接受低于下界（这是预期行为）

    # ── 确保在基因边界内 ──
    genes[r] = np.clip(genes[r], ctx.lo[r], ctx.hi[r]).astype(np.int32)

    return genes[r]


def _compute_gene_room(
    genes: np.ndarray,
    r: int,
    h: int,
    ch: int,
    ctx: Context,
    rep_ch: Optional[np.ndarray] = None,
    hcp_ch: Optional[np.ndarray] = None,
    hcp_total: Optional[np.ndarray] = None,
) -> int:
    """
    计算 genes[r, h, ch] 可分配的最大空间，综合以下约束：
      1. per-gene 上限 (ctx.hi)
      2. rep 渠道上限 (rep_channel_bounds)
      3. HCP 渠道上限 (hcp_channel_bounds)
      4. HCP 总量上限 (hcp_total_bounds)
    """
    gene_hi = int(ctx.hi[r, h, ch])
    room = max(0, gene_hi - int(genes[r, h, ch]))

    # Rep 渠道上限
    if rep_ch is not None and rep_ch.ndim == 3:
        rep_ch_used = int(genes[r, :, ch].sum())
        rep_ch_hi = int(rep_ch[r, ch, 1])
        rep_ch_room = max(0, rep_ch_hi - rep_ch_used)
        room = min(room, rep_ch_room)

    # HCP 渠道上限
    if hcp_ch is not None and hcp_ch.ndim == 3:
        hcp_ch_hi = int(hcp_ch[h, ch, 1])
        hcp_ch_used = int(genes[:, h, ch].sum())
        hcp_ch_room = max(0, hcp_ch_hi - hcp_ch_used)
        room = min(room, hcp_ch_room)

    # HCP 总量上限
    if hcp_total is not None and hcp_total.ndim == 2:
        hcp_tot_hi = int(hcp_total[h, 1])
        hcp_tot_used = int(genes[:, h, :].sum())
        hcp_tot_room = max(0, hcp_tot_hi - hcp_tot_used)
        room = min(room, hcp_tot_room)

    return room


def constraint_aware_random_genes(
    ctx: Context,
    rng: np.random.Generator,
) -> np.ndarray:
    """
    约束感知随机生成：在所有硬约束范围内生成基因。

    策略：逐个 rep 分配（随机顺序），每次分配都考虑：
      1. 已分配的 rep 对 HCP 总量的占用
      2. 当前 rep 的 per-channel / overall bounds
      3. HCP 的 per-channel / total bounds
      4. 先填正常 HCP（A/B/C/D），后填 spillover HCP（NA）

    返回 (n_reps, n_hcps, n_channels) int32
    """
    spillover_mask = _get_spillover_mask(ctx)
    assignment_mask = _get_assignment_mask(ctx)
    result = np.zeros(ctx.shape, dtype=np.int32)

    # 随机顺序分配 rep（避免固定顺序带来的偏差）
    rep_order = rng.permutation(ctx.n_reps)
    for r in rep_order:
        _fill_rep_aware(
            r, ctx, rng, result, spillover_mask, assignment_mask
        )

    return result


def constraint_aware_batch_random(
    n: int,
    ctx: Context,
    rng: np.random.Generator,
) -> np.ndarray:
    """
    批量约束感知随机生成 n 个个体。
    返回 (n, n_reps, n_hcps, n_channels) int32
    """
    result = np.empty((n, *ctx.shape), dtype=np.int32)
    for i in range(n):
        result[i] = constraint_aware_random_genes(ctx, rng)
    return result


def constraint_aware_repair(
    genes: np.ndarray,
    ctx: Context,
    hard: List[HardConstraint],
    rng: np.random.Generator,
) -> np.ndarray:
    """
    约束感知修复：先用标准 repair 修复，如果仍不满足约束，
    则清零该 rep 的所有基因并用约束感知方式重新分配。

    相比普通 repair_genes 的优势：
      - 正常 HCP（A/B/C/D）在重新分配时优先被填满
      - NA 类 HCP 仅作为最后手段接收溢出
      - 避免了"先污染后治理"导致的 NA 过量分配

    参数：
        genes: (n_reps, n_hcps, n_channels) int32
        ctx: 优化上下文
        hard: 硬约束列表
        rng: 随机数生成器
    """
    spillover_mask = _get_spillover_mask(ctx)
    assignment_mask = _get_assignment_mask(ctx)

    if spillover_mask is None:
        # 没有 spillover HCP，退回普通 repair
        return repair_genes(genes, ctx, hard, rng)

    # Phase 1: 标准 repair
    genes = repair_genes(genes, ctx, hard, rng)
    ind = Individual(genes=genes)
    if satisfies_hard(ind, ctx, hard):
        return genes

    # Phase 2: 逐个 rep 检查并重新分配不满足约束的
    for r in range(ctx.n_reps):
        temp_genes = genes.copy()
        # 清零该 rep 的基因，用约束感知方式重新分配
        temp_genes[r] = 0
        _fill_rep_aware(r, ctx, rng, temp_genes, spillover_mask, assignment_mask)
        temp_ind = Individual(genes=temp_genes)
        if satisfies_hard(temp_ind, ctx, hard):
            genes = temp_genes
        else:
            # 重新分配后再标准 repair
            temp_genes2 = repair_genes(temp_genes, ctx, hard, rng)
            temp_ind2 = Individual(genes=temp_genes2)
            if satisfies_hard(temp_ind2, ctx, hard):
                genes = temp_genes2

    return genes


def satisfies_hard(ind: Individual, ctx: Context,
                   hard: List[HardConstraint]) -> bool:
    return all(c.check(ind, ctx) for c in hard)


def repair_genes(genes: np.ndarray, ctx: Context,
                  hard: List[HardConstraint],
                  rng: np.random.Generator,
                  max_rounds: int = 5) -> np.ndarray:
    """依次调用每个硬约束的 repair 钩子，迭代直到收敛。

    多轮迭代确保后面的约束不会 undo 前面约束的修复。
    例如：Rep bounds fill deficit → HCP bounds reduce → Rep bounds refill。
    """
    for _ in range(max_rounds):
        prev = genes.copy()
        for c in hard:
            genes = c.repair(genes, ctx, rng)
        # 如果没有变化则提前退出
        if np.array_equal(genes, prev):
            break
    return genes


def make_valid_individual(ctx: Context, hard: List[HardConstraint],
                           rng: np.random.Generator,
                           max_retries: int = 50) -> Individual:
    """修复 + 重试策略生成满足硬约束的个体"""
    # v17: 优先使用约束感知初始化
    if _get_spillover_mask(ctx) is not None:
        genes = constraint_aware_random_genes(ctx, rng)
    else:
        genes = random_genes(ctx, rng)
    genes = repair_genes(genes, ctx, hard, rng)
    ind = Individual(genes=genes)
    if satisfies_hard(ind, ctx, hard):
        return ind
    for _ in range(max_retries):
        if _get_spillover_mask(ctx) is not None:
            genes = constraint_aware_random_genes(ctx, rng)
        else:
            genes = random_genes(ctx, rng)
        genes = repair_genes(genes, ctx, hard, rng)
        ind = Individual(genes=genes)
        if satisfies_hard(ind, ctx, hard):
            return ind
    return ind  # 最佳努力


def clamp(genes: np.ndarray, ctx: Context) -> np.ndarray:
    return np.clip(genes, ctx.lo, ctx.hi).astype(np.int32)


def make_valid_batch(pop_size: int, ctx: Context,
                     hard: List[HardConstraint],
                     rng: np.random.Generator) -> np.ndarray:
    """
    批量生成 pop_size 个满足硬约束的基因矩阵。
    返回 (pop_size, n_reps, n_hcps, n_channels)
    """
    result = np.empty((pop_size, *ctx.shape), dtype=np.int32)
    for i in range(pop_size):
        ind = make_valid_individual(ctx, hard, rng)
        result[i] = ind.genes
    return result


# ═════════════════════════════════════════════════════════════════════════════
# 批量并行采样（v8 — 向量化加速）
# ═════════════════════════════════════════════════════════════════════════════

def batch_satisfies_hard(
    batch: np.ndarray,
    ctx: Context,
    hard: List[HardConstraint],
) -> np.ndarray:
    """
    对 4D tensor 批量 (P, n_reps, n_hcps, n_channels) 执行硬约束检查。
    返回 (P,) bool 数组，True = 该个体满足所有硬约束。

    快速路径：
      - bounds 约束：直接 numpy 广播比较，无需逐个构造 Individual
      - 其他约束：逐个 check（因 check 签名为单个 ind）
    """
    P = batch.shape[0]
    result = np.ones(P, dtype=bool)

    for c in hard:
        # 快速路径：bounds 约束可以直接用 numpy 广播
        cname = c.__class__.__name__
        if "Bounds" in cname:
            # bounds check: genes >= lo AND genes <= hi
            valid = np.all(batch >= ctx.lo[np.newaxis], axis=(1, 2, 3)) & \
                    np.all(batch <= ctx.hi[np.newaxis], axis=(1, 2, 3))
            result &= valid
            continue

        # 快速路径：一些简单约束可以用 numpy 向量化
        if hasattr(c, 'description'):
            desc = c.description

            # total_visits_range: 整体总和在 [lo, hi]
            if 'total_visits' in desc.lower() or 'total' in desc.lower():
                totals = batch.sum(axis=(1, 2, 3))  # (P,)
                b = ctx.shared.get("total_visits_bounds")
                lo_val = b[0] if b else getattr(c, 'lo_total', 0)
                hi_val = b[1] if b else getattr(c, 'hi_total', 999999)
                result &= (totals >= lo_val) & (totals <= hi_val)
                continue

            # rep_workload_range: 每个 rep 总和在 per-rep bounds 内
            if 'rep' in desc.lower() and 'workload' in desc.lower() and 'hcp' not in desc.lower():
                rep_totals = batch.sum(axis=(1, 2))  # (P, n_reps)  # wrong dims, fix below
                # Actually need sum over hcp and channels -> (P, n_reps)
                rep_totals = batch.sum(axis=(2, 3))  # (P, n_reps)
                bounds = ctx.shared.get("rep_workload_bounds")
                if bounds is not None:
                    lo_arr = bounds[:, 0]  # (n_reps,)
                    hi_arr = bounds[:, 1]
                else:
                    lo_arr = np.full(ctx.n_reps, getattr(c, 'lo_total', 1))
                    hi_arr = np.full(ctx.n_reps, getattr(c, 'hi_total', 10000))
                result &= np.all(
                    (rep_totals >= lo_arr[np.newaxis]) & (rep_totals <= hi_arr[np.newaxis]),
                    axis=1,
                )
                continue

            # hcp_workload_range: 每个 hcp 被所有 rep 拜访的总次数
            if 'hcp' in desc.lower() and 'workload' in desc.lower() and 'rep' not in desc.lower():
                hcp_totals = batch.sum(axis=(1, 3))  # (P, n_hcps) — sum over reps & channels
                bounds = ctx.shared.get("hcp_workload_bounds")
                if bounds is not None:
                    lo_arr = bounds[:, 0]
                    hi_arr = bounds[:, 1]
                else:
                    lo_arr = np.full(ctx.n_hcps, getattr(c, 'lo_total', 0))
                    hi_arr = np.full(ctx.n_hcps, getattr(c, 'hi_total', 99999))
                result &= np.all(
                    (hcp_totals >= lo_arr[np.newaxis]) & (hcp_totals <= hi_arr[np.newaxis]),
                    axis=1,
                )
                continue

        # 通用路径：逐个检查
        for i in range(P):
            if not result[i]:
                continue
            ind = Individual(genes=batch[i])
            if not c.check(ind, ctx):
                result[i] = False
    return result


def batch_repair_genes(
    batch: np.ndarray,
    ctx: Context,
    hard: List[HardConstraint],
    rng: np.random.Generator,
) -> np.ndarray:
    """
    对整个 4D batch 逐约束执行 repair。
    batch: (P, n_reps, n_hcps, n_channels)
    返回修复后的 batch（原地修改 + 返回）。

    快速路径：
      - bounds 约束：直接 numpy np.clip 广播
      - 其他约束：逐个调用 repair
    """
    for c in hard:
        cname = c.__class__.__name__
        # 快速路径：bounds repair = np.clip
        if "Bounds" in cname:
            np.clip(batch, ctx.lo[np.newaxis], ctx.hi[np.newaxis], out=batch)
            continue

        # 通用路径：逐个 repair
        for i in range(batch.shape[0]):
            batch[i] = c.repair(batch[i], ctx, rng)
    return batch


def oversample_batch(
    pop_size: int,
    ctx: Context,
    hard: List[HardConstraint],
    rng: np.random.Generator,
    oversample_ratio: int = 10,
    max_rounds: int = 20,
    enforce_bounds: bool = True,
) -> Tuple[np.ndarray, int]:
    """
    批量并行采样：一次性生成 N × M 个随机候选，批量 repair + check，
    取前 N 个通过的个体。如果不足，放大 M 重新采样。

    核心优势（相比串行 make_valid_individual）：
      - 向量化 4D tensor 生成（numpy rng.integers 一次分配大内存）
      - 批量 bounds repair（np.clip 广播）
      - 并行 check + 过滤，避免逐个重试
      - oversample_ratio 控制过采样倍率，通常 5×-10× 足够

    参数：
        pop_size        目标种群大小 N
        ctx             优化上下文
        hard            硬约束列表
        rng             随机数生成器
        oversample_ratio 过采样倍率 M（默认 10）
        max_rounds       最大采样轮次（默认 20）
        enforce_bounds   是否先执行 bounds clip（默认 True）

    返回：
        (batch, n_valid)
        batch: (pop_size, n_reps, n_hcps, n_channels) int32
               如果有效个体不足 pop_size，剩余位置保留最后一次修复后的候选
        n_valid: 实际通过所有约束的个体数
    """
    collected: List[np.ndarray] = []
    collected_count = 0
    total_sampled = 0

    for round_idx in range(max_rounds):
        needed = pop_size - collected_count
        if needed <= 0:
            break

        # 动态调整倍率
        current_ratio = oversample_ratio
        if round_idx > 0 and total_sampled > 0:
            pass_rate = collected_count / total_sampled
            if pass_rate < 0.1:
                current_ratio = min(oversample_ratio * 5, 100)
            elif pass_rate < 0.3:
                current_ratio = min(oversample_ratio * 3, 50)
            elif pass_rate > 0.8:
                # 高通过率：降低倍率，避免浪费
                current_ratio = max(2, oversample_ratio // 2)

        sample_n = max(needed * current_ratio, needed + 1)

        # 1. 向量化批量随机生成 (sample_n, n_reps, n_hcps, n_channels)
        # v17: 优先使用约束感知初始化（先填正常 HCP，再填 spillover）
        if _get_spillover_mask(ctx) is not None:
            candidates = constraint_aware_batch_random(sample_n, ctx, rng)
        else:
            candidates = batch_random_genes(sample_n, ctx, rng)
        total_sampled += sample_n

        # 2. 批量 bounds clip（向量化广播）
        if enforce_bounds:
            candidates = np.clip(
                candidates, ctx.lo[np.newaxis], ctx.hi[np.newaxis]
            ).astype(np.int32)

        # 3. 批量 repair（逐约束对整个 batch 操作）
        candidates = batch_repair_genes(candidates, ctx, hard, rng)

        # 4. 批量 check
        valid_mask = batch_satisfies_hard(candidates, ctx, hard)
        valid_genes = candidates[valid_mask]

        if len(valid_genes) > 0:
            take = min(len(valid_genes), needed)
            collected.append(valid_genes[:take])
            collected_count += take

        if collected_count >= pop_size:
            break

    # 组装结果
    result = np.empty((pop_size, *ctx.shape), dtype=np.int32)
    filled = 0
    for chunk in collected:
        n = min(len(chunk), pop_size - filled)
        if n <= 0:
            break
        result[filled:filled + n] = chunk[:n]
        filled += n

    # 如果有效个体不足，用最后一轮修复后的候选填充（最佳努力）
    if filled < pop_size:
        # 重新生成一批并修复，填充剩余位置
        shortfall = pop_size - filled
        if _get_spillover_mask(ctx) is not None:
            filler = constraint_aware_batch_random(shortfall, ctx, rng)
        else:
            filler = batch_random_genes(shortfall, ctx, rng)
        if enforce_bounds:
            filler = np.clip(
                filler, ctx.lo[np.newaxis], ctx.hi[np.newaxis]
            ).astype(np.int32)
        filler = batch_repair_genes(filler, ctx, hard, rng)
        result[filled:] = filler
        logger.debug(
            "[oversample_batch] %d/%d valid (filled shortfall with best-effort)",
            collected_count, pop_size,
        )

    return result, collected_count
