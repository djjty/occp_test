"""
optimizer/__init__.py
可独立打包为 whl 的优化器模块。
包含：数据结构 + 评估器 + 所有优化算法

说明：
  - Context 在 core/base.py
  - 数据结构（Individual, OptimizationResult）在 optimizer/types.py
  - 算法基类在 optimizer/algorithms/base.py
  - 算法实际定义在 optimizer/algorithms/ 子目录中
  - 约束基类、Pipeline、BaseBrand 在 core/base.py
"""
# 核心数据结构
from .types import Individual, OptimizationResult
from ..core.base import Context

# 算法基类
from .algorithms.base import BaseFitnessEvaluator, BaseOptimizer

# 约束基类 + Pipeline + BaseBrand（来自 core）
from ..core.base import (
    HardConstraint, SoftConstraint, BaseBrand,
    PipelineStep, Pipeline,
)

# 评估器
from .evaluators import (
    DummyEvaluator, SklearnEvaluator, TorchEvaluator,
    EnsembleEvaluator, COSSklearnEvaluator,
)

# 优化算法（从 algorithms/ 子目录导入 — 触发注册到 ALGORITHM_REGISTRY）
from .algorithms.ga.ga import GeneticAlgorithm
from .algorithms.pso.pso import ParticleSwarmOptimizer
from .algorithms.finite_diff.finite_diff import FiniteDiffOptimizer
from .algorithms.tensor_ga.tensor_ga import TensorGeneticAlgorithm
from .algorithms.nsga3.nsga3 import NSGA3Optimizer, TensorNSGA3Optimizer

__all__ = [
    # 核心结构
    "Individual", "Context", "OptimizationResult",
    "BaseFitnessEvaluator", "BaseOptimizer",
    "HardConstraint", "SoftConstraint", "BaseBrand",
    "PipelineStep", "Pipeline",
    # 评估器
    "DummyEvaluator", "SklearnEvaluator", "TorchEvaluator",
    "EnsembleEvaluator", "COSSklearnEvaluator",
    # 算法
    "GeneticAlgorithm", "ParticleSwarmOptimizer", "FiniteDiffOptimizer",
    "TensorGeneticAlgorithm", "NSGA3Optimizer", "TensorNSGA3Optimizer",
]
