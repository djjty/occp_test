"""
optimizer/types.py — 核心数据结构

所有优化流程共享同一套数据结构，算法可随时替换。
基因矩阵统一为 np.ndarray shape=(n_reps, n_hcps, n_channels)，int32。

Context 的实际定义在 core/base.py。
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np

from ..core.base import Context


@dataclass
class Individual:
    """
    优化个体。genes 统一形状 (n_reps, n_hcps, n_channels)，所有算法共用。
    多目标优化时，objectives 存储各目标值。
    """
    genes: np.ndarray               # int32, (n_reps, n_hcps, n_channels)
    fitness: float = -np.inf
    penalty: float = 0.0
    objectives: Optional[np.ndarray] = None   # NSGA-III 多目标 shape=(n_obj,)
    rank: int = 0                             # Pareto rank (NSGA-III)
    meta: Dict[str, Any] = field(default_factory=dict)

    def clone(self) -> "Individual":
        return Individual(
            self.genes.copy(), self.fitness, self.penalty,
            self.objectives.copy() if self.objectives is not None else None,
            self.rank, dict(self.meta),
        )


@dataclass
class OptimizationResult:
    """统一优化输出结构，所有算法返回此对象"""
    brand_id: str
    best_individual: Individual
    history: List[float]             # 每代最优 fitness
    iterations_run: int
    task_id: Optional[str] = None    # 任务 ID，由调度器注入
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_genes_array(self) -> np.ndarray:
        """返回最优基因矩阵 (n_reps, n_hcps, n_channels)"""
        return self.best_individual.genes
