"""
optimizer/algorithms/base.py — 算法抽象基类（实际定义）

包含：
  - BaseFitnessEvaluator — fitness 评估器基类
  - BaseOptimizer — 优化器基类

HardConstraint, SoftConstraint 的实际定义在 core/base.py。
"""
from __future__ import annotations

import logging
from abc import ABCMeta, abstractmethod
from typing import Any, Dict, List, Optional

import numpy as np

from ...core.base import HardConstraint, SoftConstraint, Context
from ..types import Individual, OptimizationResult

logger = logging.getLogger(__name__)


class BaseFitnessEvaluator(metaclass=ABCMeta):
    """
    fitness 评估器基类。

    子类必须实现 ``predict_sales(ind, ctx) -> float``。
    evaluate() 方法负责计算最终 fitness = sales - penalty_weight * total_penalty。
    """

    @abstractmethod
    def predict_sales(self, ind: Individual, ctx: Context) -> float:
        """返回模型的 sales 预测值"""
        ...

    def evaluate(
        self,
        ind: Individual,
        ctx: Context,
        soft: Optional[List[SoftConstraint]] = None,
        penalty_weight: float = 1.0,
    ) -> None:
        """
        计算 fitness 并写入 ind.fitness / ind.penalty。

        fitness = predict_sales - penalty_weight * sum(penalty_i)
        """
        sales = self.predict_sales(ind, ctx)
        total_penalty = 0.0
        if soft:
            total_penalty = sum(c.penalty(ind, ctx) for c in soft)
        ind.fitness = sales - penalty_weight * total_penalty
        ind.penalty = total_penalty


class BaseOptimizer(metaclass=ABCMeta):
    """
    优化器基类。

    子类必须实现 ``optimize(ctx, evaluator, hard, soft) -> OptimizationResult``。
    config 通过 __init__ 注入，DEFAULT_CONFIG 提供默认值。
    """

    DEFAULT_CONFIG: Dict[str, Any] = {}

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        merged = {**self.DEFAULT_CONFIG, **(config or {})}
        self.config = merged

    @abstractmethod
    def optimize(
        self,
        ctx: Context,
        evaluator: BaseFitnessEvaluator,
        hard: List[HardConstraint],
        soft: List[SoftConstraint],
    ) -> OptimizationResult:
        """执行优化，返回 OptimizationResult"""
        ...


__all__ = [
    "BaseFitnessEvaluator",
    "BaseOptimizer",
]
