"""
optimizer/algorithms/nsga3/nsga3.py — NSGA-III 多目标优化器（标准版 + Tensor版）

多目标定义：
  obj[0] = -predict_sales          (越大越好 → 取负变最小化)
  obj[1..n] = penalty_i            (各软约束惩罚，越小越好)

NSGA-III 核心步骤：
  1. 非支配排序 → Pareto 前沿分层
  2. 参考点辅助选择（均匀分布参考方向）
  3. 精英保留：前 k 层全保留，边界层按参考点关联密度选择
"""
from __future__ import annotations
import logging
import time
from typing import Any, Dict, List, Optional

import numpy as np

from ..base import BaseOptimizer, BaseFitnessEvaluator
from ....core.base import HardConstraint, SoftConstraint, Context
from ...types import Individual, OptimizationResult
from ....core.registry import ALGORITHM_REGISTRY
from ..._utils import make_valid_individual, make_valid_batch, repair_genes, random_genes, clamp, oversample_batch, constraint_aware_repair

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────────────────────────────────────

def _compute_objectives(ind: Individual, soft: List[SoftConstraint],
                        ctx: Any = None) -> np.ndarray:
    """
    计算 NSGA-III 多目标向量：[-fitness, raw_penalty_1, raw_penalty_2, ..., raw_penalty_n]
    所有目标均为最小化方向。
    使用 raw_penalty（未归一化），因为 NSGA-III 自身通过 Pareto 前沿处理尺度差异。
    """
    penalties = np.array([c.raw_penalty(ind, ctx) for c in soft], dtype=float) \
        if soft else np.array([])
    return np.concatenate([[-ind.fitness], penalties])


def _fast_non_dominated_sort(objs: np.ndarray) -> List[List[int]]:
    """
    快速非支配排序（向量化）。
    objs: (P, n_obj)，最小化问题。
    返回 fronts: List[List[int]]，fronts[0] 是 Pareto 最优前沿。
    """
    P = objs.shape[0]
    n_dom = np.zeros(P, dtype=int)        # 被多少个个体支配
    dominated: List[List[int]] = [[] for _ in range(P)]

    for i in range(P):
        for j in range(i + 1, P):
            # i 支配 j？
            if np.all(objs[i] <= objs[j]) and np.any(objs[i] < objs[j]):
                dominated[i].append(j)
                n_dom[j] += 1
            elif np.all(objs[j] <= objs[i]) and np.any(objs[j] < objs[i]):
                dominated[j].append(i)
                n_dom[i] += 1

    fronts: List[List[int]] = []
    current = np.where(n_dom == 0)[0].tolist()
    while current:
        fronts.append(current)
        next_front = []
        for i in current:
            for j in dominated[i]:
                n_dom[j] -= 1
                if n_dom[j] == 0:
                    next_front.append(j)
        current = next_front
    return fronts


def _generate_reference_points(n_obj: int, p: int) -> np.ndarray:
    """
    Das-Dennis 结构化参考点，在 n_obj 维单纯形上均匀分布。
    p: 每维分割数（总点数 ≈ C(n_obj+p-1, p)）
    """
    from itertools import combinations_with_replacement

    def _das_dennis(n: int, q: int):
        pts = []
        for combo in combinations_with_replacement(range(n), q):
            vec = np.zeros(n)
            for c in combo:
                vec[c] += 1
            pts.append(vec / q)
        return np.array(pts)

    return _das_dennis(n_obj, p)


def _associate_to_ref_points(objs: np.ndarray,
                              ref_points: np.ndarray) -> np.ndarray:
    """
    计算每个个体到最近参考点的 ASF 距离。
    返回 (P,) int：每个个体关联的参考点索引。
    """
    # 归一化目标值
    ideal = objs.min(axis=0)
    nadir = objs.max(axis=0)
    denom = nadir - ideal + 1e-9
    norm_objs = (objs - ideal) / denom               # (P, n_obj)

    # 对每个参考点，计算 ASF
    P = objs.shape[0]
    R = len(ref_points)
    dists = np.empty((P, R), dtype=float)
    for r, rp in enumerate(ref_points):
        # ASF = max(obj_i / rp_i)
        rp_safe = np.where(rp < 1e-9, 1e-9, rp)
        dists[:, r] = (norm_objs / rp_safe).max(axis=1)
    return dists.argmin(axis=1)


def _nsga3_select(population: List[Individual],
                  ref_points: np.ndarray,
                  target_size: int) -> List[Individual]:
    """
    NSGA-III 选择：非支配排序 + 参考点关联密度控制。
    """
    if len(population) <= target_size:
        return population

    objs = np.array([ind.objectives for ind in population], dtype=float)
    fronts = _fast_non_dominated_sort(objs)

    selected = []
    for front in fronts:
        if len(selected) + len(front) <= target_size:
            selected.extend(front)
        else:
            # 需从当前前沿选 k 个
            k = target_size - len(selected)
            if k == 0:
                break
            # 参考点关联
            all_idx = selected + front
            all_objs = objs[all_idx]
            assoc = _associate_to_ref_points(all_objs, ref_points)

            # 计数 selected 中每个参考点的关联数
            niche_count = np.zeros(len(ref_points), dtype=int)
            for i in range(len(selected)):
                niche_count[assoc[i]] += 1

            # 从 front 中选：选关联参考点密度最小的
            front_assoc = assoc[len(selected):]
            chosen = []
            front_remaining = list(range(len(front)))
            while len(chosen) < k and front_remaining:
                # 找关联参考点中密度最小的
                min_niche = niche_count[front_assoc[front_remaining]].min()
                candidates = [i for i in front_remaining
                              if niche_count[front_assoc[i]] == min_niche]
                pick = candidates[0]  # 确定性选择（排序后首个），避免全局随机
                chosen.append(front[pick])
                niche_count[front_assoc[pick]] += 1
                front_remaining.remove(pick)

            selected.extend(chosen)
            break

    # 设置 rank
    for r, front in enumerate(fronts):
        for i in front:
            population[i].rank = r
    return [population[i] for i in selected]


# ─────────────────────────────────────────────────────────────────────────────
# 普通 NSGA-III
# ─────────────────────────────────────────────────────────────────────────────

@ALGORITHM_REGISTRY.register("nsga3")
class NSGA3Optimizer(BaseOptimizer):
    """
    NSGA-III 多目标优化器。
    多目标 = [−fitness] + [soft_penalty_i for each soft constraint]
    最优解取 Pareto 前沿中 fitness 最高（obj[0] 最小）的个体。

    config 键：
        pop_size, n_generations, cx_prob, mut_prob,
        ref_points_p  (Das-Dennis 分割数，默认 4)
        penalty_weight, seed, log_every
    """
    DEFAULT_CONFIG: Dict[str, Any] = dict(
        pop_size=100, n_generations=100, cx_prob=0.8, mut_prob=0.02,
        ref_points_p=4, penalty_weight=1.0, max_retries=50,
        seed=None, log_every=10, oversample_ratio=10,
    )

    def optimize(self, ctx: Context, evaluator: BaseFitnessEvaluator,
                 hard: List[HardConstraint], soft: List[SoftConstraint]) -> OptimizationResult:
        cfg  = self.config
        rng  = np.random.default_rng(cfg["seed"])
        P    = cfg["pop_size"]
        G    = cfg["n_generations"]
        pw   = cfg["penalty_weight"]
        t0   = time.perf_counter()

        # 参考点（先用 dummy 个体确定目标数量）
        n_obj = len(soft) + 1
        ref_pts = _generate_reference_points(n_obj, cfg["ref_points_p"])
        logger.info("[NSGA3][%s] pop=%d gen=%d n_obj=%d ref_pts=%d",
                    ctx.brand_id, P, G, n_obj, len(ref_pts))

        # 初始化种群（批量并行采样）
        pop_tensor, n_valid = oversample_batch(
            P, ctx, hard, rng,
            oversample_ratio=cfg.get("oversample_ratio", 10),
        )
        logger.info("[NSGA3][%s] oversample: %d/%d valid", ctx.brand_id, n_valid, P)

        population = []
        for i in range(P):
            ind = Individual(genes=pop_tensor[i])
            evaluator.evaluate(ind, ctx, soft, pw)
            ind.objectives = _compute_objectives(ind, soft, ctx)
            population.append(ind)

        history: List[float] = []
        best = max(population, key=lambda x: x.fitness).clone()

        for gen in range(G):
            # ── 交叉 + 变异 ──────────────────────────────────────────────────
            genes_pop = np.stack([ind.genes for ind in population])  # (P, *shape)
            idx_a = rng.integers(0, P, P)
            idx_b = rng.integers(0, P, P)
            mask  = rng.random(size=(P, *ctx.shape)) < cfg["cx_prob"]
            offspring_genes = np.where(mask, genes_pop[idx_a], genes_pop[idx_b]).astype(np.int32)

            mut = rng.random(size=offspring_genes.shape) < cfg["mut_prob"]
            if np.any(ctx.hi >= 2**31 - 1):
                hcp_hi = ctx.shared.get("hcp_total_bounds")
                if hcp_hi is not None and hcp_hi.ndim >= 2:
                    effective_hi = min(int(hcp_hi[:, 1].max()), 1000)
                else:
                    effective_hi = 100
                effective_hi = max(effective_hi, 1)
                rand_g = rng.integers(ctx.lo[np.newaxis], effective_hi + 1,
                                       size=offspring_genes.shape, dtype=np.int32)
                rand_g = np.clip(rand_g, ctx.lo[np.newaxis], ctx.hi[np.newaxis])
            else:
                rand_g = rng.integers(ctx.lo[np.newaxis], ctx.hi[np.newaxis] + 1,
                                       size=offspring_genes.shape, dtype=np.int32)
            offspring_genes = np.where(mut, rand_g, offspring_genes).astype(np.int32)
            offspring_genes = np.clip(offspring_genes, ctx.lo, ctx.hi)

            # ── 构造后代 + 评估 ───────────────────────────────────────────────
            offspring = []
            for g in offspring_genes:
                g = constraint_aware_repair(g.copy(), ctx, hard, rng)
                ind = Individual(genes=g)
                evaluator.evaluate(ind, ctx, soft, pw)
                ind.objectives = _compute_objectives(ind, soft, ctx)
                offspring.append(ind)

            # ── NSGA-III 选择 ─────────────────────────────────────────────────
            combined = population + offspring
            population = _nsga3_select(combined, ref_pts, P)

            gen_best = max(population, key=lambda x: x.fitness)
            if gen_best.fitness > best.fitness:
                best = gen_best.clone()
            history.append(best.fitness)

            if (gen + 1) % cfg["log_every"] == 0:
                logger.info("[NSGA3][%s] gen=%d/%d fit=%.4f t=%.1fs",
                            ctx.brand_id, gen + 1, G, best.fitness,
                            time.perf_counter() - t0)

        elapsed = time.perf_counter() - t0
        logger.info("[NSGA3][%s] Done fit=%.4f t=%.1fs", ctx.brand_id, best.fitness, elapsed)
        return OptimizationResult(ctx.brand_id, best, history, G,
                                  extra={"elapsed_sec": elapsed, "n_obj": n_obj})


# ─────────────────────────────────────────────────────────────────────────────
# Tensor NSGA-III
# ─────────────────────────────────────────────────────────────────────────────

@ALGORITHM_REGISTRY.register("tensor_nsga3")
class TensorNSGA3Optimizer(BaseOptimizer):
    """
    张量 NSGA-III：种群用 4D tensor (P, n_reps, n_hcps, n_channels)。
    交叉/变异全向量化，选择阶段与标准 NSGA-III 相同。

    config 键同 NSGA3Optimizer。
    """
    DEFAULT_CONFIG: Dict[str, Any] = dict(
        pop_size=100, n_generations=100, cx_prob=0.8, mut_prob=0.02,
        ref_points_p=4, penalty_weight=1.0, max_retries=50,
        seed=None, log_every=10, oversample_ratio=10,
    )

    def optimize(self, ctx: Context, evaluator: BaseFitnessEvaluator,
                 hard: List[HardConstraint], soft: List[SoftConstraint]) -> OptimizationResult:
        cfg  = self.config
        rng  = np.random.default_rng(cfg["seed"])
        P    = cfg["pop_size"]
        G    = cfg["n_generations"]
        pw   = cfg["penalty_weight"]
        t0   = time.perf_counter()

        n_obj = len(soft) + 1
        ref_pts = _generate_reference_points(n_obj, cfg["ref_points_p"])
        logger.info("[TensorNSGA3][%s] pop=%d gen=%d n_obj=%d ref_pts=%d",
                    ctx.brand_id, P, G, n_obj, len(ref_pts))

        # 初始化种群张量 (P, *shape) — 批量并行采样
        pop_tensor, n_valid = oversample_batch(
            P, ctx, hard, rng,
            oversample_ratio=cfg.get("oversample_ratio", 10),
        )
        logger.info("[TensorNSGA3][%s] oversample: %d/%d valid",
                    ctx.brand_id, n_valid, P)

        def _eval_tensor(tensor: np.ndarray) -> List[Individual]:
            inds = []
            for i in range(len(tensor)):
                ind = Individual(genes=tensor[i].copy())
                evaluator.evaluate(ind, ctx, soft, pw)
                ind.objectives = _compute_objectives(ind, soft, ctx)
                inds.append(ind)
            return inds

        population = _eval_tensor(pop_tensor)
        history: List[float] = []
        best = max(population, key=lambda x: x.fitness).clone()

        for gen in range(G):
            # ── 全向量化交叉 + 变异 ──────────────────────────────────────────
            idx_a = rng.integers(0, P, P)
            idx_b = rng.integers(0, P, P)
            mask  = rng.random(size=(P, *ctx.shape)) < cfg["cx_prob"]

            # (P, *shape) tensor 交叉
            off_tensor = np.where(mask, pop_tensor[idx_a], pop_tensor[idx_b]).astype(np.int32)

            # 变异
            mut = rng.random(size=off_tensor.shape) < cfg["mut_prob"]
            if np.any(ctx.hi >= 2**31 - 1):
                hcp_hi = ctx.shared.get("hcp_total_bounds")
                if hcp_hi is not None and hcp_hi.ndim >= 2:
                    effective_hi = min(int(hcp_hi[:, 1].max()), 1000)
                else:
                    effective_hi = 100
                effective_hi = max(effective_hi, 1)
                rand_g = rng.integers(
                    ctx.lo[np.newaxis], effective_hi + 1,
                    size=off_tensor.shape, dtype=np.int32,
                )
                rand_g = np.clip(rand_g, ctx.lo[np.newaxis], ctx.hi[np.newaxis])
            else:
                rand_g = rng.integers(
                    ctx.lo[np.newaxis], ctx.hi[np.newaxis] + 1,
                    size=off_tensor.shape, dtype=np.int32,
                )
            off_tensor = np.where(mut, rand_g, off_tensor).astype(np.int32)
            off_tensor = np.clip(off_tensor, ctx.lo[np.newaxis], ctx.hi[np.newaxis])

            # 硬约束修复
            for i in range(len(off_tensor)):
                off_tensor[i] = constraint_aware_repair(off_tensor[i], ctx, hard, rng)

            offspring = _eval_tensor(off_tensor)

            # ── NSGA-III 选择 ─────────────────────────────────────────────────
            combined = population + offspring
            population = _nsga3_select(combined, ref_pts, P)

            # 更新种群张量
            pop_tensor = np.stack([ind.genes for ind in population])

            gen_best = max(population, key=lambda x: x.fitness)
            if gen_best.fitness > best.fitness:
                best = gen_best.clone()
            history.append(best.fitness)

            if (gen + 1) % cfg["log_every"] == 0:
                logger.info("[TensorNSGA3][%s] gen=%d/%d fit=%.4f t=%.1fs",
                            ctx.brand_id, gen + 1, G, best.fitness,
                            time.perf_counter() - t0)

        elapsed = time.perf_counter() - t0
        logger.info("[TensorNSGA3][%s] Done fit=%.4f t=%.1fs",
                    ctx.brand_id, best.fitness, elapsed)
        return OptimizationResult(ctx.brand_id, best, history, G,
                                  extra={"elapsed_sec": elapsed, "n_obj": n_obj})
