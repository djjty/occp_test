"""
optimizer/algorithms/finite_diff/finite_diff.py — 有限差分优化（FDO）

思路：
  1. 从一个初始点（随机或指定）出发
  2. 对每个基因位逐一进行 +1/-1 的有限差分扰动
  3. 若扰动后 fitness 提升则接受，否则恢复
  4. 迭代 n_iterations 轮，每轮遍历所有维度

特点：
  - 完全无随机性（确定性爬山）
  - 每轮时间复杂度 O(n_dims × eval_cost)，适合小规模问题
  - 矩阵化：一次性计算所有 +1 扰动的 fitness 候选

config 键：
    n_iterations   迭代轮数，默认 50
    step           扰动步长，默认 1（整数）
    penalty_weight 软约束惩罚系数，默认 1.0
    seed           随机初始化种子，默认 None
    log_every      日志间隔，默认 10
"""
from __future__ import annotations
import logging
import time
from typing import Any, Dict, List

import numpy as np

from ..base import BaseOptimizer, BaseFitnessEvaluator
from ....core.base import HardConstraint, SoftConstraint, Context
from ...types import Individual, OptimizationResult
from ....core.registry import ALGORITHM_REGISTRY
from ..._utils import make_valid_individual, satisfies_hard, clamp

logger = logging.getLogger(__name__)


@ALGORITHM_REGISTRY.register("finite_diff")
class FiniteDiffOptimizer(BaseOptimizer):
    """
    有限差分优化器：对每个基因维度逐一进行 ±step 扰动，贪心接受改进。
    """
    DEFAULT_CONFIG: Dict[str, Any] = dict(
        n_iterations=50, step=1, penalty_weight=1.0,
        seed=None, log_every=10,
    )

    def optimize(self, ctx: Context, evaluator: BaseFitnessEvaluator,
                 hard: List[HardConstraint], soft: List[SoftConstraint]) -> OptimizationResult:
        cfg   = self.config
        rng   = np.random.default_rng(cfg["seed"])
        pw    = cfg["penalty_weight"]
        step  = cfg["step"]
        iters = cfg["n_iterations"]
        t0    = time.perf_counter()

        # 初始解
        current = make_valid_individual(ctx, hard, rng)
        evaluator.evaluate(current, ctx, soft, pw)
        best = current.clone()
        history: List[float] = []

        dims = list(np.ndindex(*ctx.shape))  # 所有 (rep, hcp, ch) 索引

        for it in range(iters):
            improved = False
            # 随机打乱维度顺序，避免方向偏差
            rng.shuffle(dims)

            for idx in dims:
                orig_val = int(current.genes[idx])

                for delta in (step, -step):
                    new_val = orig_val + delta
                    lo_val  = int(ctx.lo[idx])
                    hi_val  = int(ctx.hi[idx])
                    if not (lo_val <= new_val <= hi_val):
                        continue

                    current.genes[idx] = new_val
                    if not satisfies_hard(current, ctx, hard):
                        current.genes[idx] = orig_val
                        continue

                    evaluator.evaluate(current, ctx, soft, pw)
                    if current.fitness > best.fitness:
                        best = current.clone()
                        improved = True
                        break          # 接受改进，继续下一个维度
                    else:
                        current.genes[idx] = orig_val
                        current.fitness = best.fitness
                        current.penalty = best.penalty

            history.append(best.fitness)
            if (it + 1) % cfg["log_every"] == 0:
                logger.info("[FD][%s] iter=%d/%d fit=%.4f improved=%s t=%.1fs",
                            ctx.brand_id, it + 1, iters, best.fitness,
                            improved, time.perf_counter() - t0)

            if not improved:
                logger.info("[FD][%s] Converged at iter %d", ctx.brand_id, it + 1)
                # 填充剩余 history
                history += [best.fitness] * (iters - len(history))
                break

        elapsed = time.perf_counter() - t0
        logger.info("[FD][%s] Done fit=%.4f t=%.1fs", ctx.brand_id, best.fitness, elapsed)
        return OptimizationResult(ctx.brand_id, best, history, iters,
                                  extra={"elapsed_sec": elapsed})
