"""
optimizer/algorithms/ga/ga.py — 遗传算法（矩阵运算加速版）

关键优化：
  - 交叉/变异使用向量化 np 操作，避免 Python 循环
  - 锦标赛选择批量采样
  - 硬约束采用修复式策略，极大减少无效采样
"""
from __future__ import annotations
import logging
import time
from typing import Any, Dict, List

import numpy as np

from ..base import BaseOptimizer, BaseFitnessEvaluator
from ....core.base import HardConstraint, SoftConstraint, Context
from ...types import Individual, OptimizationResult
from ....core.registry import ALGORITHM_REGISTRY
from ..._utils import (
    make_valid_individual, satisfies_hard, repair_genes,
    random_genes, clamp, oversample_batch, constraint_aware_repair,
)

logger = logging.getLogger(__name__)


def _tournament(fitnesses: np.ndarray, k: int, rng: np.random.Generator) -> np.ndarray:
    """批量锦标赛选择，返回选中个体的索引数组，shape=(pop_size,)"""
    pop = len(fitnesses)
    # 每次选 k 个候选，取 fitness 最大者
    candidates = rng.integers(0, pop, size=(pop, k))         # (pop, k)
    best_idx = candidates[np.arange(pop),
                          fitnesses[candidates].argmax(axis=1)]
    return best_idx


@ALGORITHM_REGISTRY.register("ga")
class GeneticAlgorithm(BaseOptimizer):
    """
    遗传算法。输入/输出统一 Individual (genes: n_reps×n_hcps×n_channels)。

    config 键（均有默认值）：
        pop_size, n_generations, cx_prob, mut_prob,
        tournament_k, elitism, penalty_weight, max_retries, seed, log_every
    """
    DEFAULT_CONFIG: Dict[str, Any] = dict(
        pop_size=100, n_generations=200, cx_prob=0.8, mut_prob=0.02,
        tournament_k=3, elitism=2, penalty_weight=1.0,
        max_retries=50, seed=None, log_every=10,
        oversample_ratio=10,
    )

    def optimize(self, ctx: Context, evaluator: BaseFitnessEvaluator,
                 hard: List[HardConstraint], soft: List[SoftConstraint]) -> OptimizationResult:
        cfg    = self.config
        rng    = np.random.default_rng(cfg["seed"])
        P      = cfg["pop_size"]
        G      = cfg["n_generations"]
        pw     = cfg["penalty_weight"]
        elite  = cfg["elitism"]
        t0     = time.perf_counter()

        logger.info("[GA][%s] pop=%d gen=%d", ctx.brand_id, P, G)

        # ── 初始化种群（批量并行采样，4D tensor）─────────────────────────────
        pop_tensor, n_valid = oversample_batch(
            P, ctx, hard, rng,
            oversample_ratio=cfg.get("oversample_ratio", 10),
        )
        logger.info("[GA][%s] oversample: %d/%d valid", ctx.brand_id, n_valid, P)

        population = [Individual(genes=pop_tensor[i]) for i in range(P)]
        for ind in population:
            evaluator.evaluate(ind, ctx, soft, pw)

        best = max(population, key=lambda x: x.fitness).clone()
        history: List[float] = []

        for gen in range(G):
            fitnesses = np.array([ind.fitness for ind in population])

            # ── 精英 + 锦标赛选择（矩阵操作）────────────────────────────────────
            elite_idx = np.argsort(fitnesses)[::-1][:elite]
            parent_idx = _tournament(fitnesses, cfg["tournament_k"], rng)

            # ── 批量均匀交叉 ─────────────────────────────────────────────────────
            genes_pop = np.stack([ind.genes for ind in population])  # (P, *shape)
            # 配对：每对相邻父本
            idx_a = parent_idx[::2];  idx_b = parent_idx[1::2]
            if len(idx_a) > len(idx_b):
                idx_b = np.append(idx_b, idx_b[-1])
            mask = rng.random(size=(len(idx_a), *ctx.shape)) < cfg["cx_prob"]
            c1 = np.where(mask, genes_pop[idx_a], genes_pop[idx_b]).astype(np.int32)
            c2 = np.where(mask, genes_pop[idx_b], genes_pop[idx_a]).astype(np.int32)
            offspring_genes = np.concatenate([c1, c2], axis=0)[:P - elite]

            # ── 批量变异 ─────────────────────────────────────────────────────────
            mut_mask = rng.random(size=offspring_genes.shape) < cfg["mut_prob"]
            rand_g   = np.stack([random_genes(ctx, rng) for _ in range(len(offspring_genes))])
            offspring_genes = np.where(mut_mask, rand_g, offspring_genes).astype(np.int32)
            offspring_genes = np.clip(offspring_genes, ctx.lo, ctx.hi).astype(np.int32)

            # ── 构建下一代 ───────────────────────────────────────────────────────
            next_pop = [population[i].clone() for i in elite_idx]
            for g in offspring_genes:
                ind = Individual(genes=g)
                if not satisfies_hard(ind, ctx, hard):
                    g = constraint_aware_repair(g.copy(), ctx, hard, rng)
                    ind = Individual(genes=g)
                evaluator.evaluate(ind, ctx, soft, pw)
                next_pop.append(ind)

            population = next_pop[:P]

            gen_best = max(population, key=lambda x: x.fitness)
            if gen_best.fitness > best.fitness:
                best = gen_best.clone()
            history.append(best.fitness)

            if (gen + 1) % cfg["log_every"] == 0:
                logger.info("[GA][%s] gen=%d/%d fit=%.4f pen=%.4f t=%.1fs",
                            ctx.brand_id, gen + 1, G, best.fitness,
                            best.penalty, time.perf_counter() - t0)

        elapsed = time.perf_counter() - t0
        logger.info("[GA][%s] Done fit=%.4f t=%.1fs", ctx.brand_id, best.fitness, elapsed)
        return OptimizationResult(ctx.brand_id, best, history, G,
                                  extra={"elapsed_sec": elapsed})
