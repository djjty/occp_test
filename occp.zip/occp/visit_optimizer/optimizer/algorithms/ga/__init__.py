"""optimizer/algorithms/ga/__init__.py"""
from .ga import GeneticAlgorithm

__all__ = ["GeneticAlgorithm"]
