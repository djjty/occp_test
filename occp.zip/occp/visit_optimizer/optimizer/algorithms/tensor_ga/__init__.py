"""optimizer/algorithms/tensor_ga/__init__.py"""
from .tensor_ga import TensorGeneticAlgorithm

__all__ = ["TensorGeneticAlgorithm"]
