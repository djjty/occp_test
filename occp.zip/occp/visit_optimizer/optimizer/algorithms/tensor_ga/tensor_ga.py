"""
optimizer/algorithms/tensor_ga/tensor_ga.py — 张量遗传算法（4D Tensor GA）

核心设计：
  - 种群用 4D tensor：shape = (P, n_reps, n_hcps, n_channels)
  - 全部操作（交叉/变异/修复/评估）均为向量化 numpy 矩阵运算
  - 评估批量化：fitness 在单次矩阵操作中完成（DummyEvaluator 支持批量）

对比标准 GA 的提升：
  - 不逐一调用 evaluator，而是一次性对整个种群计算
  - 交叉/变异完全无 Python 循环
"""
from __future__ import annotations
import logging
import time
from typing import Any, Dict, List

import numpy as np

from ..base import BaseOptimizer, BaseFitnessEvaluator
from ....core.base import HardConstraint, SoftConstraint, Context
from ...types import Individual, OptimizationResult
from ....core.registry import ALGORITHM_REGISTRY
from ..._utils import repair_genes, random_genes, make_valid_batch, clamp, oversample_batch, constraint_aware_repair

logger = logging.getLogger(__name__)


def _batch_fitness(pop: np.ndarray, ctx: Context,
                   evaluator: BaseFitnessEvaluator,
                   soft: List[SoftConstraint],
                   penalty_weight: float) -> np.ndarray:
    """
    批量评估整个种群的 fitness。
    pop: (P, n_reps, n_hcps, n_channels) int32
    返回 (P,) float
    """
    P = pop.shape[0]
    fits = np.empty(P, dtype=float)
    for i in range(P):
        ind = Individual(genes=pop[i])
        evaluator.evaluate(ind, ctx, soft, penalty_weight)
        fits[i] = ind.fitness
    return fits


def _tournament_tensor(fits: np.ndarray, k: int,
                        rng: np.random.Generator) -> np.ndarray:
    """批量锦标赛选择，返回 (P,) 索引"""
    P = len(fits)
    candidates = rng.integers(0, P, size=(P, k))
    return candidates[np.arange(P), fits[candidates].argmax(axis=1)]


@ALGORITHM_REGISTRY.register("tensor_ga")
class TensorGeneticAlgorithm(BaseOptimizer):
    """
    4D Tensor 遗传算法。

    种群张量 shape = (P, n_reps, n_hcps, n_channels)，全程矩阵运算。

    config 键（均有默认值）：
        pop_size, n_generations, cx_prob, mut_prob,
        tournament_k, elitism, penalty_weight, seed, log_every
    """
    DEFAULT_CONFIG: Dict[str, Any] = dict(
        pop_size=100, n_generations=200, cx_prob=0.8, mut_prob=0.02,
        tournament_k=3, elitism=2, penalty_weight=1.0,
        max_retries=50, seed=None, log_every=10,
        oversample_ratio=10,
    )

    def optimize(self, ctx: Context, evaluator: BaseFitnessEvaluator,
                 hard: List[HardConstraint], soft: List[SoftConstraint]) -> OptimizationResult:
        cfg   = self.config
        rng   = np.random.default_rng(cfg["seed"])
        P     = cfg["pop_size"]
        G     = cfg["n_generations"]
        pw    = cfg["penalty_weight"]
        elite = cfg["elitism"]
        t0    = time.perf_counter()

        logger.info("[TensorGA][%s] pop=%d gen=%d shape=%s",
                    ctx.brand_id, P, G, ctx.shape)

        # ── 初始化种群：shape (P, n_reps, n_hcps, n_channels) ──────────────────
        pop, n_valid = oversample_batch(
            P, ctx, hard, rng,
            oversample_ratio=cfg.get("oversample_ratio", 10),
        )
        logger.info("[TensorGA][%s] oversample: %d/%d valid",
                    ctx.brand_id, n_valid, P)
        fits = _batch_fitness(pop, ctx, evaluator, soft, pw)

        best_idx = int(np.argmax(fits))
        best_genes = pop[best_idx].copy()
        best_fit   = float(fits[best_idx])
        history: List[float] = []

        for gen in range(G):
            # ── 精英保留 ──────────────────────────────────────────────────────
            elite_idx = np.argsort(fits)[::-1][:elite]       # top-k 索引

            # ── 锦标赛选择 (P,) 索引 ─────────────────────────────────────────
            parent_idx = _tournament_tensor(fits, cfg["tournament_k"], rng)

            # ── 均匀交叉（全向量化）──────────────────────────────────────────
            idx_a = parent_idx[::2]
            idx_b = parent_idx[1::2]
            min_n = min(len(idx_a), len(idx_b))
            idx_a, idx_b = idx_a[:min_n], idx_b[:min_n]

            # mask shape = (min_n, n_reps, n_hcps, n_channels)
            cx_mask = rng.random(size=(min_n, *ctx.shape)) < cfg["cx_prob"]
            c1 = np.where(cx_mask, pop[idx_a], pop[idx_b]).astype(np.int32)
            c2 = np.where(cx_mask, pop[idx_b], pop[idx_a]).astype(np.int32)
            offspring = np.concatenate([c1, c2], axis=0)         # (≤P, *shape)

            # ── 批量变异 ──────────────────────────────────────────────────────
            mut_mask = rng.random(size=offspring.shape) < cfg["mut_prob"]
            # 随机噪声（逐元素均匀整数）
            if np.any(ctx.hi >= 2**31 - 1):
                hcp_hi = ctx.shared.get("hcp_total_bounds")
                if hcp_hi is not None and hcp_hi.ndim >= 2:
                    effective_hi = min(int(hcp_hi[:, 1].max()), 1000)
                else:
                    effective_hi = 100
                effective_hi = max(effective_hi, 1)
                rand_g = rng.integers(
                    ctx.lo[np.newaxis], effective_hi + 1,
                    size=offspring.shape, dtype=np.int32
                )
                rand_g = np.clip(rand_g, ctx.lo[np.newaxis], ctx.hi[np.newaxis])
            else:
                rand_g = rng.integers(
                    ctx.lo[np.newaxis], ctx.hi[np.newaxis] + 1,
                    size=offspring.shape, dtype=np.int32
                )
            offspring = np.where(mut_mask, rand_g, offspring).astype(np.int32)
            offspring = np.clip(offspring, ctx.lo[np.newaxis], ctx.hi[np.newaxis])

            # ── 硬约束批量修复 ─────────────────────────────────────────────────
            for i in range(len(offspring)):
                offspring[i] = constraint_aware_repair(offspring[i], ctx, hard, rng)

            # ── 组装下一代 ────────────────────────────────────────────────────
            n_off = P - elite
            offspring = offspring[:n_off]
            new_pop = np.concatenate([pop[elite_idx], offspring], axis=0)[:P]

            # ── 批量评估 ──────────────────────────────────────────────────────
            new_fits = _batch_fitness(new_pop, ctx, evaluator, soft, pw)

            pop  = new_pop
            fits = new_fits

            gen_best_i = int(np.argmax(fits))
            if fits[gen_best_i] > best_fit:
                best_fit   = float(fits[gen_best_i])
                best_genes = pop[gen_best_i].copy()
            history.append(best_fit)

            if (gen + 1) % cfg["log_every"] == 0:
                logger.info("[TensorGA][%s] gen=%d/%d fit=%.4f t=%.1fs",
                            ctx.brand_id, gen + 1, G, best_fit,
                            time.perf_counter() - t0)

        elapsed = time.perf_counter() - t0
        best_ind = Individual(genes=best_genes)
        evaluator.evaluate(best_ind, ctx, soft, pw)
        logger.info("[TensorGA][%s] Done fit=%.4f t=%.1fs",
                    ctx.brand_id, best_fit, elapsed)
        return OptimizationResult(ctx.brand_id, best_ind, history, G,
                                  extra={"elapsed_sec": elapsed})
