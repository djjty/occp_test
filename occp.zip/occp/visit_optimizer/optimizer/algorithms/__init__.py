"""
optimizer/algorithms/__init__.py — 算法包入口

每个算法在独立子目录中：
  ga/          — GeneticAlgorithm
  pso/         — ParticleSwarmOptimizer
  finite_diff/ — FiniteDiffOptimizer
  tensor_ga/   — TensorGeneticAlgorithm
  nsga3/       — NSGA3Optimizer, TensorNSGA3Optimizer
"""
from ..types import Individual, OptimizationResult
from ...core.base import Context
from .base import BaseFitnessEvaluator, BaseOptimizer
from .._utils import (
    random_genes, batch_random_genes, satisfies_hard,
    repair_genes, make_valid_individual, clamp, make_valid_batch,
)
from .ga import GeneticAlgorithm
from .pso import ParticleSwarmOptimizer
from .finite_diff import FiniteDiffOptimizer
from .tensor_ga import TensorGeneticAlgorithm
from .nsga3 import NSGA3Optimizer, TensorNSGA3Optimizer

__all__ = [
    "Individual", "Context", "OptimizationResult",
    "BaseFitnessEvaluator", "BaseOptimizer",
    "random_genes", "batch_random_genes", "satisfies_hard",
    "repair_genes", "make_valid_individual", "clamp", "make_valid_batch",
    "GeneticAlgorithm", "ParticleSwarmOptimizer", "FiniteDiffOptimizer",
    "TensorGeneticAlgorithm", "NSGA3Optimizer", "TensorNSGA3Optimizer",
]
