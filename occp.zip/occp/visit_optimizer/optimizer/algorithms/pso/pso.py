"""
optimizer/algorithms/pso/pso.py — 粒子群优化（矩阵运算版）

位置矩阵 shape=(n_particles, n_reps, n_hcps, n_channels)，全程向量化。
"""
from __future__ import annotations
import logging
import time
from typing import Any, Dict, List

import numpy as np

from ..base import BaseOptimizer, BaseFitnessEvaluator
from ....core.base import HardConstraint, SoftConstraint, Context
from ...types import Individual, OptimizationResult
from ....core.registry import ALGORITHM_REGISTRY
from ..._utils import satisfies_hard, repair_genes, clamp

logger = logging.getLogger(__name__)


@ALGORITHM_REGISTRY.register("pso")
class ParticleSwarmOptimizer(BaseOptimizer):
    """
    离散 PSO（全矩阵运算）。
    位置更新后四舍五入取整，再 clamp + repair。
    """
    DEFAULT_CONFIG: Dict[str, Any] = dict(
        n_particles=80, n_iterations=150, w=0.7, c1=1.5, c2=1.5,
        v_max=4.0, penalty_weight=1.0, max_retries=50,
        seed=None, log_every=20,
    )

    def optimize(self, ctx: Context, evaluator: BaseFitnessEvaluator,
                 hard: List[HardConstraint], soft: List[SoftConstraint]) -> OptimizationResult:
        cfg  = self.config
        rng  = np.random.default_rng(cfg["seed"])
        N    = cfg["n_particles"]
        iters = cfg["n_iterations"]
        w, c1, c2, vmax = cfg["w"], cfg["c1"], cfg["c2"], cfg["v_max"]
        pw   = cfg["penalty_weight"]
        t0   = time.perf_counter()

        lo = ctx.lo.astype(float)
        hi = ctx.hi.astype(float)

        # 初始化位置 (N, *shape)
        pos = (rng.random(size=(N, *ctx.shape)) * (hi - lo) + lo)
        pos = np.clip(np.round(pos), lo, hi).astype(np.int32).astype(float)
        vel = rng.uniform(-vmax, vmax, size=(N, *ctx.shape))

        # 评估初始适应度
        fits = np.empty(N)
        for i in range(N):
            ind = Individual(genes=pos[i].astype(np.int32))
            evaluator.evaluate(ind, ctx, soft, pw)
            fits[i] = ind.fitness

        pbest_pos = pos.copy()
        pbest_fit = fits.copy()
        gbest_i   = int(np.argmax(fits))
        gbest_pos = pos[gbest_i].copy()
        gbest_fit = float(fits[gbest_i])
        history: List[float] = []

        for it in range(iters):
            r1 = rng.random(size=(N, *ctx.shape))
            r2 = rng.random(size=(N, *ctx.shape))
            vel = (w * vel
                   + c1 * r1 * (pbest_pos - pos)
                   + c2 * r2 * (gbest_pos - pos))
            vel  = np.clip(vel, -vmax, vmax)
            pos  = np.clip(np.round(pos + vel), lo, hi).astype(np.int32).astype(float)

            for i in range(N):
                g = pos[i].astype(np.int32)
                ind = Individual(genes=g.copy())
                if not satisfies_hard(ind, ctx, hard):
                    g = repair_genes(g.copy(), ctx, hard, rng)
                    ind = Individual(genes=g)
                    pos[i] = g.astype(float)
                evaluator.evaluate(ind, ctx, soft, pw)

                if ind.fitness > pbest_fit[i]:
                    pbest_fit[i] = ind.fitness
                    pbest_pos[i] = pos[i].copy()
                if ind.fitness > gbest_fit:
                    gbest_fit = ind.fitness
                    gbest_pos = pos[i].copy()

            history.append(gbest_fit)
            if (it + 1) % cfg["log_every"] == 0:
                logger.info("[PSO][%s] iter=%d/%d fit=%.4f t=%.1fs",
                            ctx.brand_id, it + 1, iters,
                            gbest_fit, time.perf_counter() - t0)

        best_ind = Individual(genes=gbest_pos.astype(np.int32))
        evaluator.evaluate(best_ind, ctx, soft, pw)
        elapsed = time.perf_counter() - t0
        return OptimizationResult(ctx.brand_id, best_ind, history, iters,
                                  extra={"elapsed_sec": elapsed})
