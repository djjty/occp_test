"""
optimizer/evaluators.py — Fitness 评估器

包含：DummyEvaluator, SklearnEvaluator, TorchEvaluator, EnsembleEvaluator, COSSklearnEvaluator
"""
from __future__ import annotations
import logging
import os
from pathlib import Path
from typing import Any, Callable, List, Optional
import numpy as np

from .algorithms.base import BaseFitnessEvaluator
from .types import Individual
from ..core.base import Context
from ..core.registry import EVALUATOR_REGISTRY

logger = logging.getLogger(__name__)


@EVALUATOR_REGISTRY.register("dummy")
class DummyEvaluator(BaseFitnessEvaluator):
    """测试用：sales = Σ(genes * coeff)，coeff 默认全 1"""
    def __init__(self, coeff_matrix: Optional[np.ndarray] = None):
        self.coeff = coeff_matrix

    def predict_sales(self, ind: Individual, ctx: Context) -> float:
        c = self.coeff if self.coeff is not None else np.ones(ctx.shape, dtype=float)
        return float(np.sum(ind.genes * c))


@EVALUATOR_REGISTRY.register("sklearn")
class SklearnEvaluator(BaseFitnessEvaluator):
    """
    封装 sklearn/XGBoost/LightGBM .predict(X) 接口。
    feature_fn: (genes, ctx) -> 1D float array，默认 genes.flatten()
    """
    def __init__(self, model: Any, feature_fn: Optional[Callable] = None):
        self.model = model
        self.feature_fn = feature_fn or (lambda g, ctx: g.flatten().astype(float))

    def predict_sales(self, ind: Individual, ctx: Context) -> float:
        X = self.feature_fn(ind.genes, ctx).reshape(1, -1)
        return float(self.model.predict(X)[0])


@EVALUATOR_REGISTRY.register("torch")
class TorchEvaluator(BaseFitnessEvaluator):
    """封装 PyTorch nn.Module（可选依赖）"""
    def __init__(self, model: Any, feature_fn: Optional[Callable] = None,
                 device: str = "cpu"):
        try:
            import torch; self._torch = torch
        except ImportError as e:
            raise ImportError("pip install torch") from e
        self.model = model.to(device).eval()
        self.device = device
        self.feature_fn = feature_fn or (lambda g, ctx: g.flatten().astype(float))

    def predict_sales(self, ind: Individual, ctx: Context) -> float:
        f = self.feature_fn(ind.genes, ctx).astype(np.float32)
        t = self._torch.tensor(f, device=self.device).unsqueeze(0)
        with self._torch.no_grad():
            return float(self.model(t).squeeze().cpu().numpy())


@EVALUATOR_REGISTRY.register("ensemble")
class EnsembleEvaluator(BaseFitnessEvaluator):
    """多评估器加权集成"""
    def __init__(self, evaluators: List[BaseFitnessEvaluator],
                 weights: Optional[List[float]] = None):
        self.evaluators = evaluators
        n = len(evaluators)
        total = sum(weights) if weights else n
        self.weights = [w / total for w in (weights or [1.0] * n)]

    def predict_sales(self, ind: Individual, ctx: Context) -> float:
        return sum(w * e.predict_sales(ind, ctx)
                   for w, e in zip(self.weights, self.evaluators))


@EVALUATOR_REGISTRY.register("cos_sklearn")
class COSSklearnEvaluator(BaseFitnessEvaluator):
    """
    通过腾讯云 COS 下载 sklearn 模型文件，再用 joblib 加载。
    需要 pip install cos-python-sdk-v5 joblib

    YAML 配置示例（品牌 YAML 的 model 节点）：
        model:
          type: cos_sklearn
          bucket: my-bucket-1234567890
          region: ap-guangzhou
          object_key: models/brand_a_sales.pkl
          local_cache: /tmp/brand_a_sales.pkl   # 可选，有则跳过下载
          secret_id: xxx                         # 优先读环境变量 COS_SECRET_ID
          secret_key: xxx
    """

    def __init__(self, bucket: str, region: str, object_key: str,
                 local_cache: Optional[str] = None,
                 secret_id: Optional[str] = None,
                 secret_key: Optional[str] = None,
                 feature_fn: Optional[Callable] = None):
        self.bucket = bucket
        self.region = region
        self.object_key = object_key
        self.local_cache = local_cache or f"/tmp/{Path(object_key).name}"
        self.secret_id = secret_id or os.environ.get("COS_SECRET_ID", "")
        self.secret_key = secret_key or os.environ.get("COS_SECRET_KEY", "")
        self.feature_fn = feature_fn or (lambda g, ctx: g.flatten().astype(float))
        self.model = self._load_model()

    def _download_from_cos(self) -> str:
        """使用腾讯云 COS SDK 下载模型文件到本地"""
        try:
            from qcloud_cos import CosConfig, CosS3Client
        except ImportError as e:
            raise ImportError("pip install cos-python-sdk-v5") from e

        config = CosConfig(
            Region=self.region,
            SecretId=self.secret_id,
            SecretKey=self.secret_key,
        )
        client = CosS3Client(config)
        os.makedirs(os.path.dirname(os.path.abspath(self.local_cache)), exist_ok=True)
        response = client.get_object(Bucket=self.bucket, Key=self.object_key)
        response["Body"].get_stream_to_file(self.local_cache)
        logger.info("[COSSklearnEvaluator] Downloaded %s -> %s", self.object_key, self.local_cache)
        return self.local_cache

    def _load_model(self) -> Any:
        try:
            import joblib
        except ImportError as e:
            raise ImportError("pip install joblib") from e
        if not os.path.exists(self.local_cache):
            self._download_from_cos()
        model = joblib.load(self.local_cache)
        logger.info("[COSSklearnEvaluator] Model loaded from %s", self.local_cache)
        return model

    def predict_sales(self, ind: Individual, ctx: Context) -> float:
        X = self.feature_fn(ind.genes, ctx).reshape(1, -1)
        return float(self.model.predict(X)[0])
