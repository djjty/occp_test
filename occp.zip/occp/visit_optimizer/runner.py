"""
runner.py — 优化任务调度器

支持：
  1. 单品牌运行（直接传 raw dict）
  2. YAML 配置驱动运行（自动读数据库）
  3. 多品牌批量/并发运行
"""
from __future__ import annotations
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, Optional

from .core.registry import ALGORITHM_REGISTRY, BRAND_REGISTRY
from .optimizer.types import OptimizationResult

logger = logging.getLogger(__name__)


def run_brand(brand_id: str, raw: Dict[str, Any],
              algo_override: Optional[Dict[str, Any]] = None) -> OptimizationResult:
    """
    运行单个品牌优化。
    brand_id : 注册键
    raw      : 传给 brand.build_context() 的原始数据字典
    """
    brand     = BRAND_REGISTRY.build(brand_id)
    ctx       = brand.build_context(raw)
    hard      = brand.get_hard_constraints()
    soft      = brand.get_soft_constraints(ctx)
    evaluator = brand.get_fitness_evaluator()

    algo_cfg  = {**brand.get_algorithm_config(), **(algo_override or {})}
    optimizer = ALGORITHM_REGISTRY.build(brand.get_algorithm_key(), config=algo_cfg)

    logger.info("[Runner] %s algo=%s hard=%d soft=%d",
                brand_id, brand.get_algorithm_key(), len(hard), len(soft))
    return optimizer.optimize(ctx, evaluator, hard, soft)


def run_brand_from_config(config_path: str | Path,
                           algo_override: Optional[Dict[str, Any]] = None) -> OptimizationResult:
    """YAML 配置驱动：自动读数据库 → 构建 raw → 运行优化"""
    from .io.db import BrandDataLoader
    loader    = BrandDataLoader(config_path)
    raw       = loader.load()
    brand_id  = loader.brand_id

    # 将 YAML 中的 algorithm_config 合并
    import yaml
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    algo_cfg_yaml = cfg.get("algorithm_config", {})
    merged_override = {**algo_cfg_yaml, **(algo_override or {})}

    return run_brand(brand_id, raw, merged_override)


def run_all_brands(brand_raw_map: Dict[str, Dict[str, Any]],
                   parallel: bool = False,
                   max_workers: int = 4) -> Dict[str, OptimizationResult]:
    """批量运行多品牌"""
    results: Dict[str, OptimizationResult] = {}
    if not parallel:
        for bid, raw in brand_raw_map.items():
            results[bid] = run_brand(bid, raw)
        return results

    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(run_brand, bid, raw): bid
                   for bid, raw in brand_raw_map.items()}
        for f in as_completed(futures):
            bid = futures[f]
            try:
                results[bid] = f.result()
            except Exception as e:
                logger.error("[Runner] %s failed: %s", bid, e, exc_info=True)
    return results
