"""
io/db.py — 数据库读写层（YAML 配置驱动）

使用 polars 加速数据读取与处理。
支持：sqlite, duckdb, postgresql（通过 polars connectorx）。

每个品牌有独立的 YAML 配置文件，互不干扰。
"""
from __future__ import annotations
import logging
from pathlib import Path
from typing import Any, Dict, Optional
import numpy as np

logger = logging.getLogger(__name__)

try:
    import polars as pl
    _HAS_POLARS = True
except ImportError:
    _HAS_POLARS = False
    logger.warning("polars not installed; falling back to mock DataFrames")


def _load_yaml(path: str | Path) -> Dict[str, Any]:
    try:
        import yaml
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except ImportError as e:
        raise ImportError("pip install pyyaml") from e


class BrandDataLoader:
    """
    根据 YAML 配置从指定数据库/表读取品牌数据，
    返回可传入 brand.build_context() 的 raw 字典。
    """

    def __init__(self, config_path: str | Path):
        self.cfg = _load_yaml(config_path)
        self.brand_id: str = self.cfg["brand_id"]

    def _conn_string(self, db_cfg: Dict[str, Any]) -> str:
        db_type = db_cfg["db_type"].lower()
        conn    = db_cfg["connection"]
        if db_type == "sqlite":
            return f"sqlite://{conn}"
        if db_type == "duckdb":
            return f"duckdb:///{conn}"
        # postgresql / mysql: pass-through
        return conn

    def _read_table(self, conn_str: str, table: str) -> "pl.DataFrame":
        """用 polars connectorx 读取表，或 mock 空表"""
        if not _HAS_POLARS:
            return None  # type: ignore
        try:
            return pl.read_database_uri(f"SELECT * FROM {table}", conn_str)
        except Exception as e:
            logger.warning("Failed to read %s from %s: %s", table, conn_str, e)
            return pl.DataFrame()

    def load(self) -> Dict[str, Any]:
        """读取数据并返回 raw dict，供 brand.build_context() 使用"""
        in_cfg   = self.cfg.get("input", {})
        conn_str = self._conn_string(in_cfg)

        hcp_df  = self._read_table(conn_str, in_cfg.get("hcp_table", "hcp_info"))
        rep_df  = self._read_table(conn_str, in_cfg.get("rep_table", "rep_info"))

        # 从 polars DataFrame 提取基础维度
        n_reps = (int(len(rep_df)) if (rep_df is not None and len(rep_df) > 0)
                  else self.cfg.get("n_reps", 5))
        n_hcps = (int(len(hcp_df)) if (hcp_df is not None and len(hcp_df) > 0)
                  else self.cfg.get("n_hcps", 20))

        # 从 hcp_df 提取 seg / listing（若列存在）
        hcp_seg: list = []
        hcp_listing: list = []
        if _HAS_POLARS and hcp_df is not None and len(hcp_df) > 0:
            if "seg" in hcp_df.columns:
                hcp_seg = hcp_df["seg"].to_list()
            if "listing" in hcp_df.columns:
                hcp_listing = hcp_df["listing"].to_list()

        # fallback defaults
        if not hcp_seg:
            hcp_seg = ["A"] * (n_hcps // 4) + ["B"] * (n_hcps // 4) + \
                      ["C"] * (n_hcps - n_hcps // 2)
        if not hcp_listing:
            hcp_listing = [True] * (n_hcps // 2) + [False] * (n_hcps - n_hcps // 2)

        raw: Dict[str, Any] = {
            "n_reps":               n_reps,
            "n_hcps":               n_hcps,
            "hcp_df":               hcp_df,
            "rep_df":               rep_df,
            "hcp_seg":              hcp_seg,
            "hcp_listing":          hcp_listing,
            "total_visits_bounds":  self.cfg.get("total_visits_bounds"),
            "extra": {
                "seg_call_guidance": self.cfg.get("seg_call_guidance", {}),
            },
        }
        logger.info("[DataLoader][%s] n_reps=%d n_hcps=%d", self.brand_id, n_reps, n_hcps)
        return raw


class BrandResultWriter:
    """将优化结果写回数据库"""

    def __init__(self, config_path: str | Path):
        self.cfg = _load_yaml(config_path)

    def write(self, result_df: "pl.DataFrame") -> None:
        """将 polars DataFrame 写入配置指定的输出数据库表"""
        if not _HAS_POLARS:
            logger.warning("polars not available; skipping write")
            return

        out_cfg  = self.cfg.get("output", {})
        conn_str = self._conn_string(out_cfg)
        table    = out_cfg.get("result_table", "optimization_result")

        try:
            result_df.write_database(table, conn_str, if_table_exists="replace")
            logger.info("[ResultWriter] Written %d rows to %s.%s",
                        len(result_df), conn_str, table)
        except Exception as e:
            logger.error("[ResultWriter] Failed: %s", e)

    def _conn_string(self, db_cfg: Dict[str, Any]) -> str:
        db_type = db_cfg.get("db_type", "sqlite").lower()
        conn    = db_cfg.get("connection", "result.db")
        if db_type == "sqlite":
            return f"sqlite://{conn}"
        if db_type == "duckdb":
            return f"duckdb:///{conn}"
        return conn


def result_to_polars(result_genes: np.ndarray, channels: list,
                     brand_id: str) -> "pl.DataFrame":
    """
    将优化结果基因矩阵 (n_reps, n_hcps, n_channels) 转为 polars 长表。
    列：brand_id, rep_idx, hcp_idx, channel, visits
    """
    if not _HAS_POLARS:
        logger.warning("polars not available; returning None")
        return None  # type: ignore

    n_reps, n_hcps, n_ch = result_genes.shape
    rows = []
    for r in range(n_reps):
        for h in range(n_hcps):
            for c, ch in enumerate(channels):
                rows.append({
                    "brand_id": brand_id,
                    "rep_idx":  r,
                    "hcp_idx":  h,
                    "channel":  ch,
                    "visits":   int(result_genes[r, h, c]),
                })
    return pl.DataFrame(rows)
