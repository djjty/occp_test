"""
io/async_db.py — 异步数据库读写层（asyncio + polars）

设计：
  - 读写均为 async 函数，通过 asyncio.to_thread 将 polars / sqlite IO 异步化
  - BrandAsyncDataLoader.load()  → async，返回 raw dict（含 polars DataFrame）
  - BrandAsyncResultWriter.write() → async，将结果写回数据库
  - 支持：sqlite, duckdb, postgresql（通过 polars connectorx）

polars 读写 DB：
  - read:  pl.read_database_uri(query, conn_str)
  - write: df.write_database(table, conn_str, if_table_exists="replace"/"append")
"""
from __future__ import annotations
import asyncio
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

logger = logging.getLogger(__name__)

try:
    import polars as pl
    _HAS_POLARS = True
except ImportError:
    _HAS_POLARS = False
    logger.warning("polars not installed; async IO uses mock DataFrames")

try:
    import yaml as _yaml
except ImportError:
    _yaml = None  # type: ignore


# ─────────────────────────────────────────────────────────────────────────────
# 工具
# ─────────────────────────────────────────────────────────────────────────────

def _load_yaml(path: str | Path) -> Dict[str, Any]:
    if _yaml is None:
        raise ImportError("pip install pyyaml")
    with open(path, "r", encoding="utf-8") as f:
        return _yaml.safe_load(f)


def _conn_string(db_cfg: Dict[str, Any]) -> str:
    db_type = db_cfg.get("db_type", "sqlite").lower()
    conn    = db_cfg.get("connection", ":memory:")
    if db_type == "sqlite":
        return f"sqlite://{conn}"
    if db_type == "duckdb":
        return f"duckdb:///{conn}"
    return conn  # postgresql / mysql 直接透传


async def _async_read_table(conn_str: str, table: str) -> Optional["pl.DataFrame"]:
    """异步读取数据库表（asyncio.to_thread 包裹同步 polars IO）"""
    if not _HAS_POLARS:
        return None

    def _sync():
        try:
            return pl.read_database_uri(f"SELECT * FROM {table}", conn_str)
        except Exception as e:
            logger.warning("Failed to read %s from %s: %s", table, conn_str, e)
            return pl.DataFrame()

    return await asyncio.to_thread(_sync)


async def _async_write_table(df: "pl.DataFrame", conn_str: str,
                              table: str, if_exists: str = "replace") -> None:
    """异步写入数据库（asyncio.to_thread 包裹）"""
    if not _HAS_POLARS:
        logger.warning("polars not available; skipping async write")
        return

    def _sync():
        df.write_database(table, conn_str, if_table_exists=if_exists)

    await asyncio.to_thread(_sync)


# ─────────────────────────────────────────────────────────────────────────────
# 异步任务表写入（SQLite，无 polars 依赖）
# ─────────────────────────────────────────────────────────────────────────────

_CREATE_TASK_TABLE = """
CREATE TABLE IF NOT EXISTS optimization_tasks (
    task_id      TEXT PRIMARY KEY,
    brand_id     TEXT NOT NULL,
    algo         TEXT,
    status       TEXT DEFAULT 'running',
    best_fitness REAL,
    n_iters      INTEGER,
    elapsed_sec  REAL,
    created_at   TEXT DEFAULT (datetime('now')),
    updated_at   TEXT DEFAULT (datetime('now'))
);
"""


async def async_upsert_task(
    db_path: str,
    task_id: str,
    brand_id: str,
    algo: str = "",
    status: str = "running",
    best_fitness: float = float("nan"),
    n_iters: int = 0,
    elapsed_sec: float = 0.0,
) -> None:
    """异步 upsert 优化任务记录到 SQLite"""
    sql = """
    INSERT INTO optimization_tasks
        (task_id, brand_id, algo, status, best_fitness, n_iters, elapsed_sec, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(task_id) DO UPDATE SET
        status=excluded.status,
        best_fitness=excluded.best_fitness,
        n_iters=excluded.n_iters,
        elapsed_sec=excluded.elapsed_sec,
        updated_at=datetime('now')
    """

    def _sync():
        with sqlite3.connect(db_path) as conn:
            conn.execute(_CREATE_TASK_TABLE)
            conn.execute(sql, (task_id, brand_id, algo, status,
                               best_fitness, n_iters, elapsed_sec))

    await asyncio.to_thread(_sync)


# ─────────────────────────────────────────────────────────────────────────────
# 异步数据加载器
# ─────────────────────────────────────────────────────────────────────────────

class BrandAsyncDataLoader:
    """
    根据 YAML 配置异步从数据库读取品牌数据。
    返回可传入 brand.build_context() 的 raw 字典。
    """

    def __init__(self, config_path: str | Path):
        self.cfg      = _load_yaml(config_path)
        self.brand_id: str = self.cfg["brand_id"]

    async def load(self) -> Dict[str, Any]:
        in_cfg   = self.cfg.get("input", {})
        conn_str = _conn_string(in_cfg)

        # 并发读取 hcp 和 rep 表
        hcp_df, rep_df = await asyncio.gather(
            _async_read_table(conn_str, in_cfg.get("hcp_table", "hcp_info")),
            _async_read_table(conn_str, in_cfg.get("rep_table", "rep_info")),
        )

        n_reps = (int(len(rep_df)) if (rep_df is not None and len(rep_df) > 0)
                  else self.cfg.get("n_reps", 5))
        n_hcps = (int(len(hcp_df)) if (hcp_df is not None and len(hcp_df) > 0)
                  else self.cfg.get("n_hcps", 20))

        hcp_seg: list = []
        hcp_listing: list = []
        if _HAS_POLARS and hcp_df is not None and len(hcp_df) > 0:
            if "seg" in hcp_df.columns:
                hcp_seg = hcp_df["seg"].to_list()
            if "listing" in hcp_df.columns:
                hcp_listing = hcp_df["listing"].to_list()

        # fallback defaults
        if not hcp_seg:
            hcp_seg = (["A"] * (n_hcps // 4) + ["B"] * (n_hcps // 4) +
                       ["C"] * (n_hcps - n_hcps // 2))
        if not hcp_listing:
            hcp_listing = [True] * (n_hcps // 2) + [False] * (n_hcps - n_hcps // 2)

        raw: Dict[str, Any] = {
            "n_reps": n_reps, "n_hcps": n_hcps,
            "hcp_df": hcp_df, "rep_df": rep_df,
            "hcp_seg": hcp_seg, "hcp_listing": hcp_listing,
            "total_visits_bounds": self.cfg.get("total_visits_bounds"),
            "extra": {"seg_call_guidance": self.cfg.get("seg_call_guidance", {})},
        }
        logger.info("[AsyncLoader][%s] n_reps=%d n_hcps=%d", self.brand_id, n_reps, n_hcps)
        return raw


# ─────────────────────────────────────────────────────────────────────────────
# 异步结果写入器
# ─────────────────────────────────────────────────────────────────────────────

class BrandAsyncResultWriter:
    """将优化结果异步写回数据库（polars 长表格式）"""

    def __init__(self, config_path: str | Path):
        self.cfg = _load_yaml(config_path)

    async def write(self, result: Any) -> None:
        """
        将 OptimizationResult 写入配置指定的输出库。
        同时异步更新任务表状态。
        """
        if not _HAS_POLARS:
            logger.warning("polars not available; skipping async write")
            return

        out_cfg  = self.cfg.get("output", {})
        conn_str = _conn_string(out_cfg)
        table    = out_cfg.get("result_table", "optimization_result")

        df = _result_to_polars(result)
        await _async_write_table(df, conn_str, table, if_exists="append")
        logger.info("[AsyncWriter][%s] Written %d rows to %s.%s",
                    result.brand_id, len(df), conn_str, table)

        # 同步更新任务表
        task_db = self.cfg.get("task_db", "tasks.db")
        if result.task_id:
            await async_upsert_task(
                task_db, result.task_id, result.brand_id,
                algo=result.extra.get("algo", ""),
                status="completed",
                best_fitness=result.best_individual.fitness,
                n_iters=result.iterations_run,
                elapsed_sec=result.extra.get("elapsed_sec", 0.0),
            )


def _result_to_polars(result: Any) -> "pl.DataFrame":
    """
    将 OptimizationResult 的基因矩阵转为 polars 长表。
    列：task_id, brand_id, rep_idx, hcp_idx, channel, visits
    """
    genes    = result.best_individual.genes   # (n_reps, n_hcps, n_channels)
    channels = result.extra.get("channels", list(range(genes.shape[2])))
    n_reps, n_hcps, n_ch = genes.shape

    # 利用 numpy 广播构建列
    rep_idx  = np.repeat(np.arange(n_reps), n_hcps * n_ch)
    hcp_idx  = np.tile(np.repeat(np.arange(n_hcps), n_ch), n_reps)
    ch_idx   = np.tile(np.arange(n_ch), n_reps * n_hcps)
    ch_names = [channels[i] for i in ch_idx]
    visits   = genes.flatten()

    return pl.DataFrame({
        "task_id":  [result.task_id or ""] * len(visits),
        "brand_id": [result.brand_id] * len(visits),
        "rep_idx":  rep_idx.tolist(),
        "hcp_idx":  hcp_idx.tolist(),
        "channel":  ch_names,
        "visits":   visits.tolist(),
    })
