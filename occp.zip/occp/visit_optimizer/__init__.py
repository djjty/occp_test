"""
visit_optimizer/__init__.py

最新架构：
  1. optimizer（数据结构 + 算法基类 + 评估器 + 所有优化算法）
  2. core（注册表 + 调度器 + tracking + Context + 约束基类 + Pipeline + BaseBrand）
  3. constraints（通用约束注册 + 品牌自动扫描注册）
"""
# optimizer 先导入（触发算法+评估器注册）
from . import optimizer  # noqa

# core 重新导出
from .core.registry import (  # noqa
    ALGORITHM_REGISTRY, CONSTRAINT_REGISTRY,
    EVALUATOR_REGISTRY, BRAND_REGISTRY,
    PIPELINE_STEP_REGISTRY,
)
from .core.scheduler import BrandProblem, MultiBrandScheduler  # noqa
from .core.tracking import OptimizationTracker, TaskStore  # noqa

# 公开类型
from .core.base import Context  # noqa
from .optimizer.types import Individual, OptimizationResult  # noqa
from .optimizer.algorithms.base import BaseFitnessEvaluator, BaseOptimizer  # noqa
from .core.base import HardConstraint, SoftConstraint, BaseBrand, PipelineStep, Pipeline  # noqa

# 常用约束类快捷导出
from .constraints.common import (  # noqa
    CommonHardBounds,
    CommonHardRepWorkloadRange,
    CommonHardHcpChannelBounds,
    CommonHardRepChannelBounds,
    CommonSoftRepWorkloadBalance,
    CommonSoftHcpSegScore,
)

# constraints（触发品牌注册）
from . import constraints  # noqa

# runner
from .runner import run_brand, run_brand_from_config, run_all_brands  # noqa
