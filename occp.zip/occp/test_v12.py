"""Test v12: assignment mask + lower-bound relaxation"""
import sys, logging, numpy as np
logging.disable(logging.CRITICAL)
sys.path.insert(0, '.')

from visit_optimizer.constraints.brands.brand_vx_rsv.brand import BrandVxRsv
from visit_optimizer.optimizer._utils import make_valid_individual, satisfies_hard

HCP_SEGMENTS = ["A", "A", "B", "B", "B", "C", "C", "D", "D", "NA"]

# Normal scenario from example.py
HCP_TOTAL_BOUNDS = np.array([
    [0,18],[0,18],[0,12],[0,12],[0,12],[0,5],[0,5],[0,5],[0,5],[0,1000]
], dtype='int32')
REP_TOTAL_BOUNDS = np.array([[60,100],[70,110],[50,90],[40,80]], dtype='int32')
ASSIGNMENT_MASK = np.array([
    [True]*10,
    [True]*10,
    [True]*10,
    [True]*9 + [False],  # Rep 3 no NA
], dtype=bool)

raw = dict(n_reps=4, n_hcps=10,
    hcp_segment=HCP_SEGMENTS,
    hcp_listing=[True,True,True,True,True,False,True,True,False,False],
    hcp_total_bounds=HCP_TOTAL_BOUNDS, rep_total_bounds=REP_TOTAL_BOUNDS,
    assignment_mask=ASSIGNMENT_MASK,
    extra=dict(seg_call_guidance={'A':12,'B':8,'C':3,'D':3,'NA':0},
               seg_min={'A':10,'B':6,'C':2,'D':2,'NA':0}))

brand = BrandVxRsv()
ctx = brand.build_context(raw)
hard = brand.get_hard_constraints()

print("=" * 60)
print("TEST 1: Normal scenario (50 trials)")
print("=" * 60)

rng = np.random.default_rng(42)
all_pass = True
fail_count = 0
for trial in range(50):
    ind = make_valid_individual(ctx, hard, rng)
    sat = satisfies_hard(ind, ctx, hard)
    if not sat:
        all_pass = False
        fail_count += 1
        rep_t = ind.genes.sum(axis=(1, 2)).tolist()
        hcp_t = ind.genes.sum(axis=(0, 2)).tolist()
        for c in hard:
            if not c.check(ind, ctx):
                cname = type(c).__name__
                print(f"  trial={trial}: FAIL {cname}")
                for h in range(10):
                    if hcp_t[h] > HCP_TOTAL_BOUNDS[h, 1]:
                        seg = HCP_SEGMENTS[h]
                        print(f"    HCP {h} ({seg}): {hcp_t[h]} > {HCP_TOTAL_BOUNDS[h, 1]}")
                break

if all_pass:
    print("  All 50 trials: PASS")
    ind = make_valid_individual(ctx, hard, rng)
    print(f"  Sample rep_totals: {[int(x) for x in ind.genes.sum(axis=(1,2))]}")
    print(f"  Sample hcp_totals: {[int(x) for x in ind.genes.sum(axis=(0,2))]}")
else:
    print(f"  FAILED: {fail_count}/50 trials")

# Verify assignment mask
ind = make_valid_individual(ctx, hard, rng)
violations = int((ind.genes[~ASSIGNMENT_MASK] > 0).sum())
print(f"  Assignment mask violations: {violations}")

print()
print("=" * 60)
print("TEST 2: Extreme scenario - Rep 3 lo=120, capacity=92")
print("=" * 60)

REP_TOTAL_BOUNDS_EXTREME = np.array([[60,100],[70,110],[50,90],[120,150]], dtype='int32')
raw2 = dict(raw, rep_total_bounds=REP_TOTAL_BOUNDS_EXTREME)
ctx2 = brand.build_context(raw2)
hard2 = brand.get_hard_constraints()

rng2 = np.random.default_rng(42)
all_pass2 = True
rep3_vals = []
for trial in range(50):
    ind = make_valid_individual(ctx2, hard2, rng2)
    sat = satisfies_hard(ind, ctx2, hard2)
    rep_t = ind.genes.sum(axis=(1, 2)).tolist()
    hcp_t = ind.genes.sum(axis=(0, 2)).tolist()
    rep3_vals.append(rep_t[3])
    if not sat:
        all_pass2 = False
        if trial < 3:
            for c in hard2:
                if not c.check(ind, ctx2):
                    print(f"  trial={trial}: FAIL {type(c).__name__}  rep3={rep_t[3]}")

if all_pass2:
    print(f"  All 50 trials: PASS")
else:
    print(f"  Some trials FAILED")

print(f"  Rep 3 workloads (lo=120): min={min(rep3_vals)}, max={max(rep3_vals)}")
print(f"  Rep 3 below lo: {sum(1 for v in rep3_vals if v < 120)}/50 (relaxed)")
violations2 = int((ind.genes[~ASSIGNMENT_MASK] > 0).sum())
print(f"  Assignment mask violations: {violations2}")

print()
print("=" * 60)
print("TEST 3: All reps have NA access (50 trials)")
print("=" * 60)

ASSIGNMENT_MASK_ALL = np.array([[True]*10]*4, dtype=bool)
raw3 = dict(raw, assignment_mask=ASSIGNMENT_MASK_ALL)
ctx3 = brand.build_context(raw3)
hard3 = brand.get_hard_constraints()

rng3 = np.random.default_rng(42)
all_pass3 = True
for trial in range(50):
    ind = make_valid_individual(ctx3, hard3, rng3)
    if not satisfies_hard(ind, ctx3, hard3):
        all_pass3 = False
        if trial < 3:
            rep_t = ind.genes.sum(axis=(1, 2)).tolist()
            hcp_t = ind.genes.sum(axis=(0, 2)).tolist()
            for c in hard3:
                if not c.check(ind, ctx3):
                    print(f"  trial={trial}: FAIL {type(c).__name__}  rep={rep_t}  hcp={hcp_t}")
                    break

print(f"  All 50 trials: {'PASS' if all_pass3 else 'FAIL'}")
if all_pass3:
    ind = make_valid_individual(ctx3, hard3, rng3)
    print(f"  Sample rep_totals: {[int(x) for x in ind.genes.sum(axis=(1,2))]}")
    print(f"  Sample hcp_totals: {[int(x) for x in ind.genes.sum(axis=(0,2))]}")
