# MEMORY.md — visit_optimizer 项目长期记忆

## 项目概述
Rep-HCP 渠道拜访次数优化系统，位于 `c:\Users\DYQ\WorkBuddy\Claw\visit_optimizer\`。
使用 GA/PSO/有限差分/TensorGA/NSGA-III/TensorNSGA-III 算法，fitness 由预训练模型预测。

## v17 变化（2026-04-06）— 约束感知初始化 + NA 识别修正
- **_get_spillover_hcps 修正**：用 segment 类别 `"NA"` 识别 spillover HCP，而非 `guidance == 0`
- **约束感知初始化**（optimizer/_utils.py）：
  - `constraint_aware_random_genes(ctx, rng)` — 在所有硬约束范围内生成基因
  - `_fill_rep_aware(r, ctx, rng, genes, ...)` — 核心：接收全局 genes 矩阵，逐个 rep 分配
  - 策略：先填正常 HCP（A/B/C/D），再填 spillover（NA）；考虑 HCP 渠道/总量上限、Rep 渠道上限
  - rep 随机顺序分配避免固定顺序偏差
- **约束感知修复**（optimizer/_utils.py）：
  - `constraint_aware_repair(genes, ctx, hard, rng)` — 对不满足约束的 rep 清零重新分配
- **算法集成**：GA/TensorGA/NSGA-III/TensorNSGA-III 均使用约束感知初始化和修复
- **效果**：NA 访问量平均减少 ~40%（从 260 降到 155），116/116 测试通过

## v16 变化（2026-04-06）— NA 分配策略 + per-channel xlsx
- **NA 类识别**：_get_spillover_hcps 用 guidance=0 识别（v17 已改为 segment=="NA"）
- **_fill_deficit_prefer_spillover 贪心修复**：Phase 1 逐个 HCP 贪心填满，Phase 2 spillover
- **ASSIGNMENT_MASK C-order reshape 修复**：layout 改为 [h0_f2f, h0_online, h1_f2f, ...]
- **Rep 3 下界松弛**：_rep_can_reach_lo=False 时仍计算 max_fill 分配正常 HCP
- **Per-channel xlsx 导出**：export_per_channel_xlsx()，每个渠道一个 xlsx，每个 rep 一个 sheet

## 目录结构
```
visit_optimizer/
├── core/              # registry, scheduler, tracking, base(Context/HardConstraint/Pipeline)
├── optimizer/
│   ├── types.py, evaluators.py, _utils.py
│   └── algorithms/    # ga, pso, finite_diff, tensor_ga, nsga3
├── constraints/
│   ├── common/        # common_hard.*, common_soft.*, common_input.py, common_output.py
│   └── brands/        # brand_a, brand_b, brand_vx_rsv
├── io/, config/, runner.py
tests/test_all.py ~ test_v6.py  # 116 tests, all pass
```

## 关键设计
- **Constraint-aware init**: _fill_rep_aware 逐 rep 随机序分配，先正常 HCP 后 spillover
- **TensorGA**: 种群 4D tensor (P,rep,hcp,ch)，全矩阵交叉变异
- **NSGA-III**: 多目标 = [-fitness] + [soft_penalties]
- **声明式 Pipeline**: brand.input_pipeline_steps / output_pipeline_steps
- **BrandProblem**: 封装 data+constraints+fitness+optimizer，自动运行 Pipeline

## 测试状态
- 116/116 PASS（test_all ~ test_v6）
