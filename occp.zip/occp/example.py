# -*- coding: utf-8 -*-
"""
example.py -- VX_RSV brand visit optimization example
======================================================

Business model
--------------
  genes[rep, hcp, channel]  = number of times rep visits hcp via channel

  N_REPS = 4,  N_HCPS = 10,  CHANNELS = ["f2f", "online_event"]

  REP_TOTAL_BOUNDS[r] = [lo, hi]
    Total visits rep r makes across all HCPs and all channels per period.
    Lo is a *soft* target: if the rep has no NA-class HCP assigned AND
    all assigned HCPs are saturated, the rep workload may fall below lo.

  HCP_TOTAL_BOUNDS[h] = [lo, hi]
    Total visits HCP h receives from ALL reps across ALL channels per period.

  SEG_CALL_GUIDANCE = per-segment *total* visit target (all reps combined).
    Loaded from vx_rsv.yaml config file.

  ASSIGNMENT_MASK[r, h] = True/False
    Rep-HCP pairing table.  True = rep r has chosen hcp h.
    genes[r, h, :] must be 0 wherever the mask is False.

Feasibility & constraint design:
  - A/B/C/D have hard upper bounds (derived from target with headroom).
  - NA has hi=1000 to absorb any rep workload surplus.
  - Rep-hcp pairing table restricts which HCPs each rep can visit.
  - If a rep has no spillover HCP assigned and all assigned HCPs are full,
    the rep workload may fall below its lower bound (lower-bound relaxation).
  - No per-gene (rep, hcp, channel) upper bound: gene values are controlled
    by higher-level HCP/Rep total bounds constraints.

Fitness design  (Gaussian bell-curve + NA linear penalty)
----------------------------------------------------------
For each HCP h, compute total visits across all reps and channels:

    visits_h = sum_r sum_c  genes[r, h, c]

For HCPs with SEG_CALL_GUIDANCE[seg] > 0  (A, B, C, D):

    reward_h = seg_weight[seg] * exp(-0.5 * ((visits_h - target_h) / sigma)^2)
    -> Bell-curve peaked at SEG_CALL_GUIDANCE target; over/under visiting penalised.

For HCPs with SEG_CALL_GUIDANCE[seg] == 0  (NA):

    reward_h = -na_penalty_per_visit * visits_h
    -> Linear penalty; optimizer minimises NA visits when possible.

Total fitness = sum_h reward_h  +  f2f_bonus

Key design properties:
  - A/B/C/D converge toward SEG_CALL_GUIDANCE targets via bell-curve reward.
  - A/B/C/D have hard HCP upper bounds (e.g. A=18, B=12, C=5, D=5).
  - NA absorbs excess rep workload (hi=1000) with small linear penalty.
  - Rep-hcp assignment mask restricts pairings; unassigned entries forced to 0.
  - If a rep has no spillover access and all assigned HCPs are full,
    the rep workload may fall below lo (lower-bound relaxation).
  - sigma=2.5: tight enough to penalise over-visiting, loose enough to converge.
"""
from __future__ import annotations
import sys
import os
import logging
import yaml
import numpy as np
import matplotlib
matplotlib.use("Agg")          # non-interactive (safe on Windows GBK terminals)
import matplotlib.pyplot as plt
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter


from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import visit_optimizer as vo
from visit_optimizer.constraints.brands.brand_vx_rsv.brand import BrandVxRsv
from visit_optimizer.optimizer.algorithms.finite_diff.finite_diff import FiniteDiffOptimizer
from visit_optimizer.optimizer.algorithms.base import BaseFitnessEvaluator
from visit_optimizer.optimizer.types import Individual
from visit_optimizer.core.base import Context

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

# ─── Config path ──────────────────────────────────────────────────────────────
_CONFIG_DIR = os.path.join(os.path.dirname(__file__), "visit_optimizer", "config")

def _load_yaml_config(brand_id: str = "vx_rsv") -> dict:
    """从品牌对应的 YAML 配置文件加载 seg_call_guidance 等配置。"""
    config_path = os.path.join(_CONFIG_DIR, f"{brand_id}.yaml")
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


# ─── Simulation data ─────────────────────────────────────────────────────────
N_REPS    = 4
N_HCPS    = 10
CHANNELS  = ["f2f", "online_event"]
N_CH      = len(CHANNELS)

HCP_SEGMENTS = ["A", "A", "B", "B", "B", "C", "C", "D", "D", "NA"]
HCP_LISTING  = [True, True, True, True, True, False, True, True, False, False]

# Per-segment recommended *total* HCP visits (sum of all reps, all channels).
# Loaded from vx_rsv.yaml config file; override with YAML values.
_yaml_cfg = _load_yaml_config("vx_rsv")
SEG_CALL_GUIDANCE = _yaml_cfg.get("seg_call_guidance", {"A": 6, "B": 3, "C": 1, "D": 1, "NA": 0})
# Minimum total visit target per segment (soft-constraint floor)
SEG_MIN      = {"A": 10, "B":  6, "C": 2, "D": 2, "NA": 0}

# ─── Per-channel HCP bounds (n_hcps, n_channels, 2) ─────────────────────────
# Each HCP has independent [lo, hi] bounds per channel.
# A/B/C/D: hard caps to prevent over-visiting in each channel.
# NA: hi=1000 per channel (uncapped for rep surplus).
HCP_CHANNEL_BOUNDS = np.array([
    # f2f [lo, hi]     online_event [lo, hi]
    [[  0, 18], [  0, 18]],  # HCP 0: A, Rep 0 + Rep 3
    [[  0, 18], [  0, 18]],  # HCP 1: A, Rep 1 + Rep 3
    [[  0, 13], [  0, 13]],  # HCP 2: B, Rep 0 + Rep 3
    [[  0, 13], [  0, 13]],  # HCP 3: B, Rep 1 + Rep 3
    [[  0, 13], [  0, 13]],  # HCP 4: B, Rep 0
    [[  0,  8], [  0,  8]],  # HCP 5: C, Rep 1
    [[  0, 10], [  0, 10]],  # HCP 6: C, Rep 2
    [[  0, 10], [  0, 10]],  # HCP 7: D, Rep 2
    [[  0, 10], [  0, 10]],  # HCP 8: D, Rep 2
    [[  0,   0],[  0,   0]],  # HCP 9: NA, all reps (hard cap = 0, only used in post-processing)
], dtype=np.int32)

# ─── Overall (all-channel) HCP bounds (n_hcps, 2) ──────────────────────────
# Total visits HCP h receives from ALL reps across ALL channels.
# v20: 根据 rep 分配调整容量，确保能支撑 rep 下界
HCP_TOTAL_BOUNDS = np.array([
    [  0, 35],   # HCP 0: A, Rep 0 + Rep 3 共享
    [  0, 35],   # HCP 1: A, Rep 1 + Rep 3 共享
    [  0, 25],   # HCP 2: B, Rep 0 + Rep 3 共享
    [  0, 25],   # HCP 3: B, Rep 1 + Rep 3 共享
    [  0, 25],   # HCP 4: B, Rep 0 独占
    [  0, 15],   # HCP 5: C, Rep 1 独占
    [  0, 20],   # HCP 6: C, Rep 2 独占
    [  0, 20],   # HCP 7: D, Rep 2 独占
    [  0, 20],   # HCP 8: D, Rep 2 独占
    [  0,   0],  # HCP 9: NA, 所有 rep 共享 (hard cap = 0, only used in post-processing)
], dtype=np.int32)

# ─── Per-channel Rep bounds (n_reps, n_channels, 2) ─────────────────────────
# Each rep has independent [lo, hi] workload bounds per channel.
REP_CHANNEL_BOUNDS = np.array([
    # f2f [lo, hi]     online_event [lo, hi]
    [[ 30,  60], [ 30,  60]],  # Rep 0
    [[ 35,  65], [ 35,  65]],  # Rep 1
    [[ 25,  50], [ 25,  50]],  # Rep 2
    [[ 20,  45], [ 20,  45]],  # Rep 3
], dtype=np.int32)

# ─── Overall (all-channel) Rep bounds (n_reps, 2) ──────────────────────────
# Total workload rep r makes across all HCPs and all channels per period.
REP_TOTAL_BOUNDS = np.array([
    [ 60, 100],  # Rep 0
    [ 70, 110],  # Rep 1
    [ 50,  90],  # Rep 2
    [ 40,  80],  # Rep 3
], dtype=np.int32)

# ─── Per-channel Rep-HCP assignment mask (n_reps, n_hcps, n_channels) ──────
# True  = rep r can visit hcp h via channel c.
# False = rep r cannot visit hcp h via channel c (genes[r, h, c] must be 0).
#
# Layout: numpy C-order reshape(4, 10, 2) — last dim (channel) varies fastest.
#   Row per rep: [h0_f2f, h0_online, h1_f2f, h1_online, ..., h9_f2f, h9_online]
#
# v20 稀疏设计原则：
#   - 每个 HCP 最多被 2 个 rep 访问
#   - 各 rep 的 HCP 尽量不重叠（主要 HCP 不重叠，NA 共享）
#   - 每个 rep 都有 NA(9) 权限，确保多余工作量有地方去
#
# HCP 分配（按 rep 下界 60/70/50/40 设计）：
#   - Rep 0 (lo=60): HCP 0(A), 2(B), 4(B) + NA
#   - Rep 1 (lo=70): HCP 1(A), 3(B), 5(C) + NA
#   - Rep 2 (lo=50): HCP 6(C), 7(D), 8(D) + NA
#   - Rep 3 (lo=40): HCP 0,1(A), 2,3(B) + NA (辅助 rep，分担 A/B)
#
# 这样 Rep 0/1/2 的主要 HCP 不重叠，Rep 3 作为共享辅助
ASSIGNMENT_MASK = np.array([
    # h0(f2f,onl) h1(f2f,onl) h2(f2f,onl) h3(f2f,onl) h4(f2f,onl) h5(f2f,onl) h6(f2f,onl) h7(f2f,onl) h8(f2f,onl) h9(f2f,onl)
    [1,1, 0,0, 1,1, 0,0, 1,1, 0,0, 0,0, 0,0, 0,0, 0,0],  # Rep 0: HCP 0,2,4
    [0,0, 1,1, 0,0, 1,1, 0,0, 1,1, 0,0, 0,0, 0,0, 1,1],  # Rep 1: HCP 1,3,5 + NA
    [0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 1,1, 1,1, 1,1, 1,1],  # Rep 2: HCP 6,7,8 + NA
    [1,1, 1,1, 1,1, 1,1, 0,0, 0,0, 0,0, 0,0, 0,0, 0,1],  # Rep 3: HCP 0,1,2,3 + NA
], dtype=bool).reshape(N_REPS, N_HCPS, N_CH)


# ─── Custom evaluator: Gaussian bell-curve fitness ───────────────────────────

class GaussianTargetEvaluator(BaseFitnessEvaluator):
    """
    Fitness design:

    For HCPs with target > 0  (A, B, C, D):
        reward_h = seg_weight[seg] * exp(-0.5 * ((visits_h - target_h) / sigma)^2)
        → bell-curve peaked at target; over-visiting penalised symmetrically.

    For HCPs with target == 0  (NA):
        reward_h = -na_penalty_per_visit * visits_h
        → linear penalty; each extra NA visit reduces fitness.
        → optimizer dumps excess rep workload here only when forced to.

    Total fitness = sum_h reward_h  +  f2f_bonus

    This design ensures the optimizer:
      1. Drives A/B/C/D HCPs toward their SEG_GUIDANCE targets.
      2. Minimises NA visits as much as rep workload constraints allow.
      3. Any unavoidable rep surplus spills into NA (hi=1000) with small penalty.
    """
    SEG_WEIGHT          = {"A": 6.0, "B": 3.0, "C": 1.5, "D": 1.0}
    NA_PENALTY_PER_VISIT = 0.10   # v20: 增加 NA 惩罚，防止过早填充 NA

    def __init__(
        self,
        hcp_segments: list,
        channels: list,
        seg_guidance: dict,
        sigma: float = 2.5,
        f2f_bonus_weight: float = 1.0,
        seg_weight: Optional[dict] = None,
        na_penalty_per_visit: float = 0.02,
    ):
        self._segments   = hcp_segments
        self._channels   = channels
        self._targets    = np.array(
            [seg_guidance.get(s, 0) for s in hcp_segments], dtype=float
        )
        sw = seg_weight or self.SEG_WEIGHT
        self._weights    = np.array([sw.get(s, 0.0) for s in hcp_segments], dtype=float)
        self._is_na      = np.array([seg_guidance.get(s, 0) == 0 for s in hcp_segments])
        self._sigma      = sigma
        self._f2f_weight = f2f_bonus_weight
        self._na_penalty = na_penalty_per_visit
        self._f2f_idx    = channels.index("f2f") if "f2f" in channels else None

    def predict_sales(self, ind: Individual, ctx: Context) -> float:
        genes = ind.genes
        # Total visits per HCP (sum over all reps and channels): shape (n_hcps,)
        visits_h = genes.sum(axis=(0, 2)).astype(float)

        # --- Bell-curve reward for target > 0 HCPs (A, B, C, D) ---
        z         = (visits_h - self._targets) / (self._sigma + 1e-9)
        reward_h  = self._weights * np.exp(-0.5 * z * z)
        reward_h  = np.where(self._is_na, 0.0, reward_h)

        # --- Under-fill penalty: penalize normal HCPs that are below target ---
        under_fill = np.maximum(0, self._targets - visits_h)
        under_fill_penalty = np.where(
            self._is_na, 0.0, 2.0 * under_fill * self._weights
        )

        fitness = float((reward_h - under_fill_penalty).sum())

        # F2f channel bonus (reward f2f >= 50% of total)
        if self._f2f_idx is not None:
            f2f_total = float(genes[:, :, self._f2f_idx].sum())
            all_total = float(genes.sum())
            if all_total > 0:
                f2f_ratio = f2f_total / all_total
                fitness  += self._f2f_weight * min(f2f_ratio / 0.5, 1.0)

        return fitness


# ─── Build Context ─────────────────────────────────────────────────────────

def build_context():
    brand = BrandVxRsv()
    raw = {
        "n_reps":              N_REPS,
        "n_hcps":              N_HCPS,
        "bounds_lo":            0,             # v23: optimizer 搜索空间下界 = 0
        "hcp_segment":          HCP_SEGMENTS,
        "hcp_listing":         HCP_LISTING,
        "hcp_channel_bounds":  HCP_CHANNEL_BOUNDS,   # v23: optimizer 搜索空间上界从此读取，NA=0
        "hcp_total_bounds":    HCP_TOTAL_BOUNDS,
        "rep_channel_bounds":  REP_CHANNEL_BOUNDS,
        "rep_total_bounds":    REP_TOTAL_BOUNDS,
        "assignment_mask":     ASSIGNMENT_MASK,
        "extra": {
            "seg_call_guidance": SEG_CALL_GUIDANCE,
            "seg_min":           SEG_MIN,
        },
    }
    ctx = brand.build_context(raw)
    return ctx, brand


# ─── Feasibility check ────────────────────────────────────────────────────

def check_feasibility():
    hcp_hi_sum = int(HCP_TOTAL_BOUNDS[:, 1].sum())
    hcp_lo_sum = int(HCP_TOTAL_BOUNDS[:, 0].sum())
    rep_lo_sum = int(REP_TOTAL_BOUNDS[:, 0].sum())
    rep_hi_sum = int(REP_TOTAL_BOUNDS[:, 1].sum())
    ok1 = hcp_hi_sum >= rep_lo_sum
    ok2 = hcp_lo_sum <= rep_hi_sum
    # Check per-rep capacity considering assignment mask (sum across all channels)
    ok3 = True
    for r in range(N_REPS):
        # For each channel, sum assigned HCP channel hi
        cap = 0
        for ch in range(N_CH):
            for h in range(N_HCPS):
                if ASSIGNMENT_MASK[r, h, ch]:
                    cap += int(HCP_CHANNEL_BOUNDS[h, ch, 1])
        if cap < int(REP_CHANNEL_BOUNDS[r, :, 0].sum()):
            ok3 = False
    print("[CHECK] Feasibility:")
    print(f"  sum(HCP_hi)={hcp_hi_sum} >= sum(Rep_lo)={rep_lo_sum}"
          f"  -> {'OK' if ok1 else 'FAIL'}")
    print(f"  sum(HCP_lo)={hcp_lo_sum} <= sum(Rep_hi)={rep_hi_sum}"
          f"  -> {'OK' if ok2 else 'FAIL'}")
    print(f"  per-rep per-channel assigned_hcp_hi >= rep_ch_lo"
          f"  -> {'OK' if ok3 else 'WARN (lower-bound relaxation will apply)'}")
    if not (ok1 and ok2):
        print("  [WARN] Constraints are infeasible -- optimizer may not converge!")
    if not ok3:
        print("  [INFO] Some reps lack sufficient assigned HCP capacity;")
        print("         their workload may fall below lo (lower-bound relaxation).")
    return ok1 and ok2


def _allocate_remaining_to_na(genes: np.ndarray) -> np.ndarray:
    genes = np.maximum(genes, 0).copy()
    na_indices = [h for h in range(N_HCPS) if HCP_SEGMENTS[h] == 'NA']
    for r in range(N_REPS):
        rep_lo = int(REP_TOTAL_BOUNDS[r, 0])
        rep_hi = int(REP_TOTAL_BOUNDS[r, 1])
        accessible_normals = [h for h in range(N_HCPS) 
                             if HCP_SEGMENTS[h] != 'NA' and ASSIGNMENT_MASK[r, h].any()]
        current = int(genes[r].sum())
        if current > rep_hi:
            excess = current - rep_hi
            for nah in na_indices:
                if excess <= 0: break
                nv = int(genes[r, nah, :].sum())
                if nv > 0:
                    r2 = min(nv, excess)
                    genes[r, nah, :] -= r2
                    excess -= r2
            if excess > 0:
                for h in accessible_normals:
                    if excess <= 0: break
                    hv = int(genes[r, h, :].sum())
                    r2 = min(hv, excess)
                    genes[r, h, :] -= r2
                    excess -= r2
        elif current < rep_lo:
            deficit = rep_lo - current
            for h in accessible_normals:
                if deficit <= 0: break
                hh = int(HCP_TOTAL_BOUNDS[h, 1])
                hu = int(genes[:, h, :].sum())
                room = max(0, hh - hu)
                fill = min(room, deficit)
                if fill > 0:
                    genes[r, h, :] += fill
                    deficit -= fill
            # 只有当正常 HCP 全部达到上限后仍有缺口，才分配给 NA
            if deficit > 0:
                all_normals_full = True
                for h in accessible_normals:
                    hh = int(HCP_TOTAL_BOUNDS[h, 1])
                    hu = int(genes[:, h, :].sum())
                    if hu < hh:
                        all_normals_full = False
                        break
                if all_normals_full:
                    ca = int(genes[r].sum())
                    rth = rep_hi - ca
                    fn = min(deficit, max(0, rth))
                    if fn > 0:
                        for nah in na_indices:
                            if ASSIGNMENT_MASK[r, nah].any():
                                genes[r, nah, :] += fn
                                break
    return genes


# ─── Run optimisation ────────────────────────────────────────────────────

def run_optimization(ctx: Context, brand: BrandVxRsv):
    hard_constraints = brand.get_hard_constraints()
    soft_constraints = brand.get_soft_constraints(ctx)

    evaluator = GaussianTargetEvaluator(
        hcp_segments=HCP_SEGMENTS,
        channels=CHANNELS,
        seg_guidance=SEG_CALL_GUIDANCE,
        sigma=2.5,               # visit tolerance: ±2.5 around target
        f2f_bonus_weight=1.0,
        na_penalty_per_visit=0.02,
    )

    optimizer = FiniteDiffOptimizer(config={
        "n_iterations":   5000,
        "step":           1,
        "penalty_weight": 1.0,
        "seed":           42,
        "log_every":      100,
    })

    result = optimizer.optimize(ctx, evaluator, hard_constraints, soft_constraints)
    return result


# ─── Extract per-HCP visit counts ────────────────────────────────────────

def extract_hcp_visits(genes: np.ndarray) -> np.ndarray:
    """genes: (n_reps, n_hcps, n_channels)  ->  (n_hcps,) across all reps & channels"""
    return genes.sum(axis=(0, 2))


# ─── Plotting ────────────────────────────────────────────────────────────

SEG_COLORS = {
    "A":  "#e74c3c",
    "B":  "#e67e22",
    "C":  "#3498db",
    "D":  "#9b59b6",
    "NA": "#95a5a6",
}
SEG_ORDER = ["A", "B", "C", "D", "NA"]


def _plot_seg_histogram(ax, visits_by_seg, title):
    """
    在 ax 上绘制按 A/B/C/D/NA 分类的拜访次数直方图。
    visits_by_seg: dict[str, list[int]] — 每个分级的 HCP 拜访次数列表
    横轴：拜访次数，纵轴：对应拜访次数的 HCP 数量
    """
    segs_present = [s for s in SEG_ORDER if s in visits_by_seg and len(visits_by_seg[s]) > 0]
    if not segs_present:
        ax.set_title(title + "  [no data]")
        return

    all_visits = [v for s in segs_present for v in visits_by_seg[s]]
    if not all_visits:
        ax.set_title(title + "  [no data]")
        return

    max_v = max(all_visits) + 3
    bins = np.arange(-0.5, max_v + 1.5, 1.0)
    n_segs = len(segs_present)
    bar_width = 0.8 / n_segs

    for i, seg in enumerate(segs_present):
        visits = visits_by_seg[seg]
        if not visits:
            continue
        color = SEG_COLORS[seg]
        n_hcps = len(visits)
        # 用偏移的 bins 实现分组条形图
        offset = (i - n_segs / 2 + 0.5) * bar_width
        shifted_bins = np.array(bins) + offset
        ax.hist(visits, bins=shifted_bins, color=color, edgecolor="white",
                alpha=0.8, label=f"{seg} (n={n_hcps})", density=False,
                rwidth=1.0)

    ax.set_title(title, fontsize=10, fontweight="bold", pad=6)
    ax.set_xlabel("Visits per HCP", fontsize=9)
    ax.set_ylabel("HCP count", fontsize=9)
    ax.legend(fontsize=7, loc="upper right", framealpha=0.85)
    ax.grid(axis="x", alpha=0.25, linestyle="--")
    ax.set_xlim(-0.5, max_v)


def plot_results(genes: np.ndarray, history: list = None,
                 save_path: str = "visit_histogram.png"):
    """
    布局：
      行 = 渠道（f2f, online_event），每行 3 列：总体、listing、non_listing
      每个格子内按 A/B/C/D/NA 分类的直方图
      如果有 history，底部加一行 fitness 收敛图
    """
    n_ch = genes.shape[2]

    has_history = history is not None and len(history) > 1
    n_rows = n_ch + (1 if has_history else 0)
    fig, axes = plt.subplots(n_rows, 3, figsize=(20, 6 * n_rows))
    if n_rows == 1:
        axes = axes[None, :]  # 保持 2D

    fig.suptitle(
        "VX_RSV  --  Per-Channel HCP Visit Distribution by Segment\n"
        f"SEG_CALL_GUIDANCE = {SEG_CALL_GUIDANCE}",
        fontsize=13, fontweight="bold",
    )

    for ci, ch in enumerate(CHANNELS):
        # 该渠道每个 HCP 的总拜访次数 (sum over reps)
        ch_visits = genes[:, :, ci].sum(axis=0)  # (n_hcps,)

        # 分类
        listing_mask = np.array(HCP_LISTING, dtype=bool)
        non_listing_mask = ~listing_mask

        groups = [
            ("Overall", np.ones(N_HCPS, dtype=bool)),
            ("Listing", listing_mask),
            ("Non-listing", non_listing_mask),
        ]

        for col, (group_name, mask) in enumerate(groups):
            ax = axes[ci][col]
            segs_in_group = {}
            for h in np.where(mask)[0]:
                seg = HCP_SEGMENTS[h]
                if seg not in segs_in_group:
                    segs_in_group[seg] = []
                segs_in_group[seg].append(int(ch_visits[h]))
            _plot_seg_histogram(ax, segs_in_group, f"{ch} - {group_name}")

    if has_history:
        ax_h = axes[-1, :]
        ax_h = fig.add_subplot(n_rows, 1, n_rows)
        axes[-1, 0].remove()
        axes[-1, 1].remove()
        axes[-1, 2].remove()
        ax_h.plot(range(len(history)), history, color="#2980b9", linewidth=1.8)
        ax_h.set_title("Fitness convergence history", fontsize=11, fontweight="bold")
        ax_h.set_xlabel("Iteration", fontsize=9)
        ax_h.set_ylabel("Fitness", fontsize=9)
        ax_h.grid(alpha=0.3, linestyle="--")
        ax_h.annotate(
            f"Final = {history[-1]:.3f}",
            xy=(len(history) - 1, history[-1]),
            xytext=(-40, 8), textcoords="offset points",
            fontsize=9, color="#2980b9",
            arrowprops=dict(arrowstyle="->", color="#2980b9", lw=1.2),
        )

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    print(f"\n[SAVE] Histogram saved => {save_path}")


# ─── Summary ─────────────────────────────────────────────────────────────

import sys

def print_summary(result, genes: np.ndarray):
    # v21: 调试 - 直接显示传入的 genes 内容
    hcp_visits = extract_hcp_visits(genes)


    print("\n" + "=" * 78)
    print("  VX_RSV Optimization Summary")
    print("=" * 78)
    print(f"  Best fitness     : {result.best_individual.fitness:.4f}")
    print(f"  Best penalty     : {result.best_individual.penalty:.4f}")
    print(f"  Iterations run   : {len(result.history)}")
    print(f"  Fitness history  : "
          f"[{result.history[0]:.2f}  ...  {result.history[-1]:.2f}]")
    print()

    # Per-HCP overall summary
    print(f"  {'HCP':>4}  {'Seg':>4}  {'Listed':>7}  {'Visits':>8}  "
          f"{'Target':>8}  {'Diff':>6}  {'TotalBounds':>12}")
    print("  " + "-" * 68)
    for i in range(N_HCPS):
        seg    = HCP_SEGMENTS[i]
        target = SEG_CALL_GUIDANCE.get(seg, 0)
        listed = "Y" if HCP_LISTING[i] else "N"
        v      = int(hcp_visits[i])
        diff   = v - target
        lo, hi = HCP_TOTAL_BOUNDS[i]
        ok     = "OK" if lo <= v <= hi else "!!"
        print(f"  {i:>4}  {seg:>4}  {listed:>7}  {v:>8}  "
              f"{target:>8}  {diff:>+6}  [{lo:>3},{hi:>3}] {ok}")

    # Per-channel HCP breakdown
    print()
    for ci, ch in enumerate(CHANNELS):
        ch_hcp = genes[:, :, ci].sum(axis=0)
        print(f"  --- Channel: {ch} ---")
        print(f"  {'HCP':>4}  {'Seg':>4}  {'Visits':>8}  {'ChBounds':>12}  {'NA_check':>30}")
        for h in range(N_HCPS):
            seg = HCP_SEGMENTS[h]
            v = int(ch_hcp[h])
            lo, hi = HCP_CHANNEL_BOUNDS[h, ci]
            ok = "OK" if lo <= v <= hi else "!!"
            # For NA: check if A/B/C/D are at channel hi
            na_info = ""
            if seg == "NA":
                abcd_total = sum(int(ch_hcp[j]) for j in range(N_HCPS) if HCP_SEGMENTS[j] != "NA")
                abcd_hi_sum = sum(int(HCP_CHANNEL_BOUNDS[j, ci, 1]) for j in range(N_HCPS) if HCP_SEGMENTS[j] != "NA")
                na_info = f"A/B/C/D={abcd_total}/{abcd_hi_sum}"
            print(f"  {h:>4}  {seg:>4}  {v:>8}  [{lo:>3},{hi:>3}] {ok:2s}  {na_info}")

    print()
    ch_totals = genes.sum(axis=(0, 1))
    print("  Channel totals (all reps + all HCPs):")
    for ci, ch in enumerate(CHANNELS):
        lo = int(REP_CHANNEL_BOUNDS[:, ci, 0].sum())
        hi = int(REP_CHANNEL_BOUNDS[:, ci, 1].sum())
        print(f"    {ch:>14}  total = {int(ch_totals[ci])}  "
              f"[sum Rep lo={lo}, hi={hi}]")
    all_total = int(ch_totals.sum())
    f2f_ratio = int(ch_totals[0]) / all_total if all_total > 0 else 0.0
    print(f"  f2f ratio : {f2f_ratio:.1%}  (target >= 50%)")

    print()
    rep_totals = genes.sum(axis=(1, 2))
    print("  Per-Rep total workload:")
    for r in range(N_REPS):
        lo, hi = REP_TOTAL_BOUNDS[r]
        v  = int(rep_totals[r])
        has_na = any(HCP_SEGMENTS[h] == "NA" and ASSIGNMENT_MASK[r, h, :].any() for h in range(N_HCPS))
        if v < lo:
            if v < lo and v > hi:
                ok = "!! (below lo and above hi)"
            elif v > hi:
                ok = "!! (above hi)"
            elif has_na:
                ok = "!! (below lo)"
            else:
                ok = "RELAXED (no NA, HCPs full)"
        elif v > hi:
            ok = "!! (above hi)"
        else:
            ok = "OK"
        # Per-channel breakdown
        ch_detail = []
        for ci, ch in enumerate(CHANNELS):
            ch_v = int(genes[r, :, ci].sum())
            ch_lo, ch_hi = REP_CHANNEL_BOUNDS[r, ci]
            ch_ok = "OK" if ch_lo <= ch_v <= ch_hi else "!!"
            ch_detail.append(f"{ch}={ch_v}[{ch_lo},{ch_hi}]{ch_ok}")
        print(f"    Rep {r}: total={v:>4}  [{lo}-{hi}] {ok}")
        print(f"           per-ch: {' | '.join(ch_detail)}")

    print()
    print("  Per-segment HCP visit summary:")
    for seg, mu in sorted(SEG_CALL_GUIDANCE.items(), key=lambda kv: -kv[1]):
        idxs = [i for i, s in enumerate(HCP_SEGMENTS) if s == seg]
        if not idxs:
            continue
        vs = hcp_visits[idxs]
        print(f"    Seg {seg}  target={mu:>3}  visits={vs.tolist()}  "
              f"mean={vs.mean():.1f}")
    print("=" * 78)


# ─── Excel export ──────────────────────────────────────────────────────

# Excel 样式
_FONT_BOLD    = Font(bold=True, size=11, color="FFFFFF")
_FONT_HEADER  = Font(bold=True, size=10)
_FONT_NORMAL  = Font(size=10)
_FILL_HEADER  = PatternFill("solid", fgColor="4472C4")  # 蓝色表头
_FILL_NORMAL  = PatternFill("solid", fgColor="D9E2F3")   # 浅蓝交替行
_FILL_WHITE   = PatternFill("solid", fgColor="FFFFFF")
_FILL_OK      = PatternFill("solid", fgColor="E2EFDA")   # 绿色 - 在范围内
_FILL_WARN    = PatternFill("solid", fgColor="FCE4D6")   # 橙色 - 超范围
_ALIGN_CENTER = Alignment(horizontal="center", vertical="center")
_ALIGN_LEFT   = Alignment(horizontal="left", vertical="center")
_BORDER_THIN  = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)


def export_per_channel_xlsx(genes: np.ndarray, output_dir: str = "."):
    """
    将优化结果按渠道导出为独立的 xlsx 文件。

    每个渠道一个 xlsx 文件，文件名：visits_{channel}.xlsx
    每个 rep 一个 sheet，sheet 名：Rep_{r}
    sheet 内容：
      - HCP 名称列：显示 "HCP_{h} ({seg}) [lo, hi]" 格式，包含该 HCP 在该渠道的上下限
      - 访问数量列：该 rep 对该 HCP 的访问次数
      - 总计行和范围检查
    """
    os.makedirs(output_dir, exist_ok=True)

    for ci, ch in enumerate(CHANNELS):
        wb = openpyxl.Workbook()

        for r in range(N_REPS):
            if r == 0:
                ws = wb.active
                ws.title = f"Rep_{r}"
            else:
                ws = wb.create_sheet(title=f"Rep_{r}")

            # ── 标题行（合并单元格） ──
            ws.merge_cells("A1:C1")
            title_cell = ws["A1"]
            title_cell.value = f"Rep {r} — Channel: {ch}"
            title_cell.font = _FONT_BOLD
            title_cell.fill = _FILL_HEADER
            title_cell.alignment = _ALIGN_CENTER
            for col_letter in ["B", "C"]:
                ws[f"{col_letter}1"].fill = _FILL_HEADER

            # ── Rep 工作量汇总行 ──
            rep_ch_total = int(genes[r, :, ci].sum())
            rep_ch_lo, rep_ch_hi = int(REP_CHANNEL_BOUNDS[r, ci, 0]), int(REP_CHANNEL_BOUNDS[r, ci, 1])
            rep_status = "OK" if rep_ch_lo <= rep_ch_total <= rep_ch_hi else "!!"
            ws.merge_cells("A2:C2")
            summary_cell = ws["A2"]
            summary_cell.value = f"Workload: {rep_ch_total}  [Bounds: {rep_ch_lo} - {rep_ch_hi}]  {rep_status}"
            summary_cell.font = Font(size=10, italic=True,
                                     color="006100" if rep_status == "OK" else "C00000")
            summary_cell.alignment = _ALIGN_LEFT
            for col_letter in ["B", "C"]:
                ws[f"{col_letter}2"].fill = _FILL_WHITE

            # ── 表头行 ──
            headers = ["HCP", "Segment", f"Visits ({ch})"]
            for j, hdr in enumerate(headers, start=1):
                cell = ws.cell(row=3, column=j, value=hdr)
                cell.font = _FONT_HEADER
                cell.fill = _FILL_HEADER
                cell.font = _FONT_BOLD
                cell.alignment = _ALIGN_CENTER
                cell.border = _BORDER_THIN

            # ── 数据行 ──
            row_idx = 4
            for h in range(N_HCPS):
                seg = HCP_SEGMENTS[h]
                lo, hi = int(HCP_CHANNEL_BOUNDS[h, ci, 0]), int(HCP_CHANNEL_BOUNDS[h, ci, 1])
                visits = int(genes[r, h, ci])
                assigned = bool(ASSIGNMENT_MASK[r, h, ci])

                hcp_name = f"HCP_{h} ({seg}) [{lo}, {hi}]"
                if not assigned:
                    hcp_name += "  ✗"

                in_range = lo <= visits <= hi
                fill = _FILL_NORMAL if (row_idx % 2 == 0) else _FILL_WHITE

                cell_hcp = ws.cell(row=row_idx, column=1, value=hcp_name)
                cell_hcp.font = _FONT_NORMAL
                cell_hcp.alignment = _ALIGN_LEFT
                cell_hcp.border = _BORDER_THIN
                cell_hcp.fill = fill
                if not assigned:
                    cell_hcp.font = Font(size=10, color="A0A0A0")

                cell_seg = ws.cell(row=row_idx, column=2, value=seg)
                cell_seg.font = _FONT_NORMAL
                cell_seg.alignment = _ALIGN_CENTER
                cell_seg.border = _BORDER_THIN
                cell_seg.fill = fill
                if not assigned:
                    cell_seg.font = Font(size=10, color="A0A0A0")

                cell_visits = ws.cell(row=row_idx, column=3, value=visits)
                cell_visits.font = Font(size=10, bold=True)
                cell_visits.alignment = _ALIGN_CENTER
                cell_visits.border = _BORDER_THIN
                if assigned and not in_range:
                    cell_visits.fill = _FILL_WARN
                    cell_visits.font = Font(size=10, bold=True, color="C00000")
                elif assigned:
                    cell_visits.fill = fill
                else:
                    cell_visits.fill = fill
                    cell_visits.font = Font(size=10, color="A0A0A0")

                row_idx += 1

            # ── 总计行 ──
            row_idx += 1
            cell_total_label = ws.cell(row=row_idx, column=1, value="TOTAL")
            cell_total_label.font = _FONT_BOLD
            cell_total_label.alignment = _ALIGN_CENTER
            cell_total_label.border = _BORDER_THIN
            cell_total_label.fill = _FILL_HEADER

            cell_total_seg = ws.cell(row=row_idx, column=2, value="")
            cell_total_seg.fill = _FILL_HEADER
            cell_total_seg.border = _BORDER_THIN

            cell_total_val = ws.cell(row=row_idx, column=3, value=rep_ch_total)
            cell_total_val.font = Font(bold=True, size=11, color="FFFFFF")
            cell_total_val.alignment = _ALIGN_CENTER
            cell_total_val.border = _BORDER_THIN
            cell_total_val.fill = _FILL_HEADER

            # ── Segment 汇总 ──
            row_idx += 2
            cell_seg_title = ws.cell(row=row_idx, column=1, value="Segment Summary")
            cell_seg_title.font = _FONT_BOLD
            cell_seg_title.fill = _FILL_HEADER
            cell_seg_title.font = _FONT_BOLD

            row_idx += 1
            for j, hdr in enumerate(["Segment", "Visits", "HCP Count"], start=1):
                cell = ws.cell(row=row_idx, column=j, value=hdr)
                cell.font = _FONT_HEADER
                cell.fill = _FILL_HEADER
                cell.font = _FONT_BOLD
                cell.alignment = _ALIGN_CENTER
                cell.border = _BORDER_THIN

            row_idx += 1
            for seg in SEG_ORDER:
                idxs = [h for h in range(N_HCPS) if HCP_SEGMENTS[h] == seg]
                seg_visits = sum(int(genes[r, h, ci]) for h in idxs if ASSIGNMENT_MASK[r, h, ci])
                seg_count = sum(1 for h in idxs if ASSIGNMENT_MASK[r, h, ci])

                fill_s = _FILL_NORMAL if (row_idx % 2 == 0) else _FILL_WHITE

                cell_s = ws.cell(row=row_idx, column=1, value=seg)
                cell_s.font = _FONT_NORMAL
                cell_s.alignment = _ALIGN_CENTER
                cell_s.border = _BORDER_THIN
                cell_s.fill = fill_s

                cell_v = ws.cell(row=row_idx, column=2, value=seg_visits)
                cell_v.font = Font(size=10, bold=True)
                cell_v.alignment = _ALIGN_CENTER
                cell_v.border = _BORDER_THIN
                cell_v.fill = fill_s

                cell_c = ws.cell(row=row_idx, column=3, value=seg_count)
                cell_c.font = _FONT_NORMAL
                cell_c.alignment = _ALIGN_CENTER
                cell_c.border = _BORDER_THIN
                cell_c.fill = fill_s

                row_idx += 1

            # ── 调整列宽 ──
            ws.column_dimensions["A"].width = 32
            ws.column_dimensions["B"].width = 12
            ws.column_dimensions["C"].width = 14

        filepath = os.path.join(output_dir, f"visits_{ch}.xlsx")
        wb.save(filepath)
        print(f"  [SAVE] {filepath}")


def export_all_channel_xlsx(genes: np.ndarray, output_dir: str = "."):
    """
    将优化结果导出为全渠道汇总 xlsx 文件。

    一个 xlsx 文件：visits_all_channels.xlsx
    每个 rep 一个 sheet，sheet 名：Rep_{r}
    每个 sheet 内容：
      - 标题行：Rep {r} — All Channels
      - Rep 全渠道工作量汇总行（total / bounds / status）
      - 表头行：HCP | Segment | f2f | online_event | Total | TotalBounds | NA_check
      - 数据行：每个 HCP 一行，显示各渠道拜访次数和总量
      - 总计行
      - Segment 汇总区
    """
    os.makedirs(output_dir, exist_ok=True)
    wb = openpyxl.Workbook()

    n_cols = len(CHANNELS) + 4  # HCP + Segment + channels... + Total + TotalBounds + NA_check
    col_headers = ["HCP", "Segment"] + CHANNELS + ["Total", "TotalBounds"]

    for r in range(N_REPS):
        if r == 0:
            ws = wb.active
            ws.title = f"Rep_{r}"
        else:
            ws = wb.create_sheet(title=f"Rep_{r}")

        # ── 标题行（合并单元格） ──
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n_cols)
        title_cell = ws["A1"]
        title_cell.value = f"Rep {r} — All Channels Summary"
        title_cell.font = _FONT_BOLD
        title_cell.fill = _FILL_HEADER
        title_cell.alignment = _ALIGN_CENTER
        for c_idx in range(2, n_cols + 1):
            ws.cell(row=1, column=c_idx).fill = _FILL_HEADER

        # ── Rep 全渠道工作量汇总行 ──
        rep_total = int(genes[r].sum())
        rep_lo, rep_hi = int(REP_TOTAL_BOUNDS[r, 0]), int(REP_TOTAL_BOUNDS[r, 1])
        rep_status = "OK" if rep_lo <= rep_total <= rep_hi else "!!"
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=n_cols)
        summary_cell = ws["A2"]
        summary_cell.value = (
            f"Workload: {rep_total}  [Bounds: {rep_lo} - {rep_hi}]  {rep_status}"
        )
        summary_cell.font = Font(
            size=10, italic=True,
            color="006100" if rep_status == "OK" else "C00000",
        )
        summary_cell.alignment = _ALIGN_LEFT
        for c_idx in range(2, n_cols + 1):
            ws.cell(row=2, column=c_idx).fill = _FILL_WHITE

        # ── 表头行 ──
        for j, hdr in enumerate(col_headers, start=1):
            cell = ws.cell(row=3, column=j, value=hdr)
            cell.font = _FONT_BOLD
            cell.fill = _FILL_HEADER
            cell.alignment = _ALIGN_CENTER
            cell.border = _BORDER_THIN

        # ── 数据行 ──
        row_idx = 4
        for h in range(N_HCPS):
            seg = HCP_SEGMENTS[h]
            hcp_total_lo, hcp_total_hi = int(HCP_TOTAL_BOUNDS[h, 0]), int(HCP_TOTAL_BOUNDS[h, 1])
            hcp_total_visits = int(genes[r, h, :].sum())

            # 检查是否被分配（任一渠道）
            assigned = bool(ASSIGNMENT_MASK[r, h, :].any())

            hcp_name = f"HCP_{h} ({seg})"
            if not assigned:
                hcp_name += "  ✗"

            in_range = hcp_total_lo <= hcp_total_visits <= hcp_total_hi
            fill = _FILL_NORMAL if (row_idx % 2 == 0) else _FILL_WHITE

            # HCP 名称
            cell_hcp = ws.cell(row=row_idx, column=1, value=hcp_name)
            cell_hcp.font = _FONT_NORMAL
            cell_hcp.alignment = _ALIGN_LEFT
            cell_hcp.border = _BORDER_THIN
            cell_hcp.fill = fill
            if not assigned:
                cell_hcp.font = Font(size=10, color="A0A0A0")

            # Segment
            cell_seg = ws.cell(row=row_idx, column=2, value=seg)
            cell_seg.font = _FONT_NORMAL
            cell_seg.alignment = _ALIGN_CENTER
            cell_seg.border = _BORDER_THIN
            cell_seg.fill = fill
            if not assigned:
                cell_seg.font = Font(size=10, color="A0A0A0")

            # 各渠道拜访次数
            for ci, ch in enumerate(CHANNELS):
                visits = int(genes[r, h, ci])
                ch_lo, ch_hi = int(HCP_CHANNEL_BOUNDS[h, ci, 0]), int(HCP_CHANNEL_BOUNDS[h, ci, 1])

                cell_v = ws.cell(row=row_idx, column=3 + ci, value=visits)
                cell_v.alignment = _ALIGN_CENTER
                cell_v.border = _BORDER_THIN
                if assigned:
                    ch_ok = ch_lo <= visits <= ch_hi
                    if not ch_ok:
                        cell_v.fill = _FILL_WARN
                        cell_v.font = Font(size=10, color="C00000")
                    else:
                        cell_v.fill = fill
                        cell_v.font = _FONT_NORMAL
                else:
                    cell_v.fill = fill
                    cell_v.font = Font(size=10, color="A0A0A0")

            # Total 列
            total_col = 3 + len(CHANNELS)
            cell_total = ws.cell(row=row_idx, column=total_col, value=hcp_total_visits)
            cell_total.font = Font(size=10, bold=True)
            cell_total.alignment = _ALIGN_CENTER
            cell_total.border = _BORDER_THIN
            if assigned and not in_range:
                cell_total.fill = _FILL_WARN
                cell_total.font = Font(size=10, bold=True, color="C00000")
            elif assigned:
                cell_total.fill = fill
            else:
                cell_total.fill = fill
                cell_total.font = Font(size=10, color="A0A0A0")

            # TotalBounds 列
            bounds_col = total_col + 1
            cell_bounds = ws.cell(
                row=row_idx, column=bounds_col,
                value=f"[{hcp_total_lo}, {hcp_total_hi}]",
            )
            cell_bounds.font = _FONT_NORMAL
            cell_bounds.alignment = _ALIGN_CENTER
            cell_bounds.border = _BORDER_THIN
            cell_bounds.fill = fill

            row_idx += 1

        # ── 总计行 ──
        row_idx += 1
        cell_t_label = ws.cell(row=row_idx, column=1, value="TOTAL")
        cell_t_label.font = _FONT_BOLD
        cell_t_label.alignment = _ALIGN_CENTER
        cell_t_label.border = _BORDER_THIN
        cell_t_label.fill = _FILL_HEADER

        cell_t_seg = ws.cell(row=row_idx, column=2, value="")
        cell_t_seg.fill = _FILL_HEADER
        cell_t_seg.border = _BORDER_THIN

        # 各渠道总计
        for ci, ch in enumerate(CHANNELS):
            ch_total = int(genes[r, :, ci].sum())
            cell = ws.cell(row=row_idx, column=3 + ci, value=ch_total)
            cell.font = Font(bold=True, size=10, color="FFFFFF")
            cell.alignment = _ALIGN_CENTER
            cell.border = _BORDER_THIN
            cell.fill = _FILL_HEADER

        # 总总计
        total_col = 3 + len(CHANNELS)
        cell_grand = ws.cell(row=row_idx, column=total_col, value=rep_total)
        cell_grand.font = Font(bold=True, size=11, color="FFFFFF")
        cell_grand.alignment = _ALIGN_CENTER
        cell_grand.border = _BORDER_THIN
        cell_grand.fill = _FILL_HEADER

        # Bounds 占位
        bounds_col = total_col + 1
        cell_b = ws.cell(row=row_idx, column=bounds_col, value=f"[{rep_lo}, {rep_hi}]")
        cell_b.font = Font(bold=True, size=10, color="FFFFFF")
        cell_b.alignment = _ALIGN_CENTER
        cell_b.border = _BORDER_THIN
        cell_b.fill = _FILL_HEADER

        # ── Segment 汇总区 ──
        row_idx += 2
        seg_summary_cols = ["Segment", "f2f", "online_event", "Total", "HCP Count"]
        cell_st = ws.cell(row=row_idx, column=1, value="Segment Summary")
        cell_st.font = _FONT_BOLD
        cell_st.fill = _FILL_HEADER

        row_idx += 1
        for j, hdr in enumerate(seg_summary_cols, start=1):
            cell = ws.cell(row=row_idx, column=j, value=hdr)
            cell.font = _FONT_BOLD
            cell.fill = _FILL_HEADER
            cell.alignment = _ALIGN_CENTER
            cell.border = _BORDER_THIN

        row_idx += 1
        for seg in SEG_ORDER:
            idxs = [h for h in range(N_HCPS) if HCP_SEGMENTS[h] == seg]
            seg_assigned = [h for h in idxs if ASSIGNMENT_MASK[r, h, :].any()]
            seg_ch_visits = {}
            for ci, ch in enumerate(CHANNELS):
                seg_ch_visits[ch] = sum(int(genes[r, h, ci]) for h in seg_assigned)
            seg_total = sum(seg_ch_visits.values())
            seg_count = len(seg_assigned)

            fill_s = _FILL_NORMAL if (row_idx % 2 == 0) else _FILL_WHITE

            cell_s = ws.cell(row=row_idx, column=1, value=seg)
            cell_s.font = _FONT_NORMAL
            cell_s.alignment = _ALIGN_CENTER
            cell_s.border = _BORDER_THIN
            cell_s.fill = fill_s

            for ci, ch in enumerate(CHANNELS):
                cell_v = ws.cell(row=row_idx, column=2 + ci, value=seg_ch_visits[ch])
                cell_v.font = _FONT_NORMAL
                cell_v.alignment = _ALIGN_CENTER
                cell_v.border = _BORDER_THIN
                cell_v.fill = fill_s

            cell_t = ws.cell(row=row_idx, column=2 + len(CHANNELS), value=seg_total)
            cell_t.font = Font(size=10, bold=True)
            cell_t.alignment = _ALIGN_CENTER
            cell_t.border = _BORDER_THIN
            cell_t.fill = fill_s

            cell_c = ws.cell(row=row_idx, column=3 + len(CHANNELS), value=seg_count)
            cell_c.font = _FONT_NORMAL
            cell_c.alignment = _ALIGN_CENTER
            cell_c.border = _BORDER_THIN
            cell_c.fill = fill_s

            row_idx += 1

        # ── 调整列宽 ──
        ws.column_dimensions["A"].width = 22
        ws.column_dimensions["B"].width = 12
        for ci in range(len(CHANNELS)):
            ws.column_dimensions[get_column_letter(3 + ci)].width = 14
        ws.column_dimensions[get_column_letter(3 + len(CHANNELS))].width = 10
        ws.column_dimensions[get_column_letter(4 + len(CHANNELS))].width = 14

    filepath = os.path.join(output_dir, "visits_all_channels.xlsx")
    wb.save(filepath)
    print(f"  [SAVE] {filepath}")


# ─── Main ─────────────────────────────────────────────────────────────────

def main():
    print("[INFO] Building Context ...")
    ctx, brand = build_context()
    print(f"  shape  : {ctx.shape}")
    print(f"  channels: {ctx.channels}")

    check_feasibility()

    print("\n[INFO] Running finite_diff optimization ...")
    result = run_optimization(ctx, brand)

    genes = result.best_individual.genes  # (n_reps, n_hcps, n_channels)

    
    # v21: 后处理 - 先深拷贝，避免修改原始 result
    genes = genes.copy()


    # v21: 后处理 - 把 NA 工作量转移到正常 HCP（如果还有空间）
    genes = _allocate_remaining_to_na(genes)
    

    print_summary(result, genes)

    print("\n[INFO] Plotting visit histograms ...")
    plot_results(genes, history=result.history, save_path="visit_histogram.png")

    print("\n[INFO] Exporting per-channel xlsx ...")
    export_per_channel_xlsx(genes, output_dir=".")

    print("\n[INFO] Exporting all-channel xlsx ...")
    export_all_channel_xlsx(genes, output_dir=".")
    print("[DONE]")


if __name__ == "__main__":
    main()
