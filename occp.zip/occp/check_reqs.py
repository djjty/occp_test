import sys
sys.path.insert(0, ".")
import visit_optimizer as vo

PASS = "[PASS]"
FAIL = "[FAIL]"
def chk(label, cond):
    print(f"  {PASS if cond else FAIL} {label}")
    return cond

print()
print("=" * 60)
print("8 Req Final Check")
print("=" * 60)

ok_all = True

# Req1: PIPELINE_STEP_REGISTRY in core/registry.py
print("\n[Req1] Pipeline registration in core/registry.py")
from visit_optimizer.core.registry import PIPELINE_STEP_REGISTRY
ok = chk("PIPELINE_STEP_REGISTRY in core/registry.py", PIPELINE_STEP_REGISTRY._name == "pipeline_step")
ok &= chk("fill_default_bounds registered", "fill_default_bounds" in PIPELINE_STEP_REGISTRY)
ok &= chk("brand_a_digital_channel_cap registered", "brand_a_digital_channel_cap" in PIPELINE_STEP_REGISTRY)
ok_all &= ok

# Req2: pipeline_input/output in constraints/common/
print("\n[Req2] pipeline_input/output moved to constraints/common/")
import os
ok = chk("pipeline_input.py in constraints/common/", os.path.exists("visit_optimizer/constraints/common/pipeline_input.py"))
ok &= chk("pipeline_output.py in constraints/common/", os.path.exists("visit_optimizer/constraints/common/pipeline_output.py"))
from visit_optimizer.constraints.common import FillDefaultBounds, GenesTo3DArray
ok &= chk("FillDefaultBounds importable from constraints.common", True)
ok_all &= ok

# Req3: Global PipelineContext from core/base.py
print("\n[Req3] Global PipelineContext from core/base.py")
from visit_optimizer.core.base import PipelineContext, Pipeline
ok = chk("PipelineContext defined in core/base", "visit_optimizer.core.base" in PipelineContext.__module__)
ok &= chk("Pipeline defined in core/base", "visit_optimizer.core.base" in Pipeline.__module__)
ok &= chk("vo.PipelineContext accessible", hasattr(vo, "PipelineContext"))
ok_all &= ok

# Req4: pipeline/ folder deprecated (forwarding only)
print("\n[Req4] pipeline/ folder deprecated (forwarding module)")
from visit_optimizer.pipeline import PipelineContext as PC2
ok = chk("pipeline/ still importable (forwarding)", PC2 is PipelineContext)
# Verify no independent implementation
from visit_optimizer.pipeline import base as pb
ok &= chk("pipeline/base.py no longer standalone", not hasattr(pb, "_STANDALONE"))
ok_all &= ok

# Req5: brand-specific steps in brand dir, imported in brand.py
print("\n[Req5] Brand-specific steps in brand dir, registered via import")
ok = chk("brand_a_input.py in brand_a dir", os.path.exists("visit_optimizer/constraints/brands/brand_a/brand_a_input.py"))
ok &= chk("brand_a_output.py in brand_a dir", os.path.exists("visit_optimizer/constraints/brands/brand_a/brand_a_output.py"))
ok &= chk("brand_a_digital_channel_cap registered", "brand_a_digital_channel_cap" in PIPELINE_STEP_REGISTRY)
ok &= chk("brand_a_enrich_output registered", "brand_a_enrich_output" in PIPELINE_STEP_REGISTRY)
ok_all &= ok

# Req6: BaseBrand in core/base.py
print("\n[Req6] BaseBrand defined in core/base.py")
from visit_optimizer.core.base import BaseBrand
ok = chk("BaseBrand from core/base.py", "visit_optimizer.core.base" in BaseBrand.__module__)
from visit_optimizer.optimizer.base import BaseBrand as BB2
ok &= chk("optimizer/base.py forwards BaseBrand", BB2 is BaseBrand)
ok_all &= ok

# Req7: algorithms in optimizer/algorithms/ subdirs
print("\n[Req7] Algorithms in optimizer/algorithms/ subdirs")
ok = chk("ga/ subdir exists", os.path.exists("visit_optimizer/optimizer/algorithms/ga/ga.py"))
ok &= chk("pso/ subdir exists", os.path.exists("visit_optimizer/optimizer/algorithms/pso/pso.py"))
ok &= chk("finite_diff/ subdir exists", os.path.exists("visit_optimizer/optimizer/algorithms/finite_diff/finite_diff.py"))
ok &= chk("tensor_ga/ subdir exists", os.path.exists("visit_optimizer/optimizer/algorithms/tensor_ga/tensor_ga.py"))
ok &= chk("nsga3/ subdir exists", os.path.exists("visit_optimizer/optimizer/algorithms/nsga3/nsga3.py"))
ok &= chk("types.py in algorithms/", os.path.exists("visit_optimizer/optimizer/algorithms/types.py"))
ok &= chk("base.py in algorithms/", os.path.exists("visit_optimizer/optimizer/algorithms/base.py"))
ok &= chk("_utils.py in algorithms/", os.path.exists("visit_optimizer/optimizer/algorithms/_utils.py"))
ok &= chk("all 6 algorithms registered", set(vo.ALGORITHM_REGISTRY.keys()) == {"ga","pso","finite_diff","tensor_ga","nsga3","tensor_nsga3"})
ok_all &= ok

# Req8: GA population generation analysis md
print("\n[Req8] GA population generation analysis md file")
ok = chk("analysis file exists", os.path.exists("ga_population_generation_analysis.md"))
with open("ga_population_generation_analysis.md", encoding="utf-8") as f:
    content = f.read()
ok &= chk("contains topological sort approach", "repair_priority" in content or "拓扑排序" in content)
ok &= chk("contains multiple schemes", "方案 1" in content and "方案 2" in content)
ok &= chk("contains recommendation", "推荐" in content)
ok_all &= ok

print()
print("=" * 60)
if ok_all:
    print(f"{PASS} All 8 requirements satisfied!")
else:
    print(f"{FAIL} Some requirements not met.")
