# GA 种群生成方案分析

> 适用范围：`visit_optimizer` 项目中所有遗传算法变体（GA、TensorGA、NSGA-III 等）
> 撰写日期：2026-04-05

---

## 1. 问题场景

在 `make_valid_individual()` 函数中，当前采用"随机生成 + repair + 重试"策略：

```python
def make_valid_individual(ctx, hard, rng, max_retries=50):
    genes = random_genes(ctx, rng)
    genes = repair_genes(genes, ctx, hard, rng)
    ind = Individual(genes=genes)
    if satisfies_hard(ind, ctx, hard):
        return ind
    for _ in range(max_retries):          # 最多重试 max_retries 次
        genes = random_genes(ctx, rng)
        genes = repair_genes(genes, ctx, hard, rng)
        ind = Individual(genes=genes)
        if satisfies_hard(ind, ctx, hard):
            return ind
    return ind  # 最佳努力——可能不满足硬约束！
```

**症状**：当硬约束之间存在强耦合（或可行域极小）时，`max_retries` 次内无法生成满足所有约束的个体，导致：
- 种群中存在大量"不合法"个体
- 早代 fitness 被严重惩罚，优化效率低
- 极端情况下整个种群都是无效解

---

## 2. 根本原因分析

| 原因 | 说明 |
|------|------|
| **约束耦合** | 约束 A 满足后，再执行约束 B 的 repair 可能破坏 A。例如先修复 `total_visits_range`（调整总和），再修复 `channel_exclusive`（置零某渠道），导致总和又变了 |
| **可行域稀疏** | 若约束极为严格（如 listing + workload + channel_exclusive 同时作用），可行解在搜索空间中占比可能 < 1% |
| **repair 是线性的** | 当前 `repair_genes()` 按约束列表顺序逐一 repair，不感知约束间的依赖关系 |
| **随机初始化无偏见** | 完全随机的 `random_genes` 不利用约束结构，对可行域没有倾向性 |

---

## 3. 解决方案

### 方案 1：约束拓扑排序修复（推荐，优先级最高）

**核心思想**：分析约束之间的前后依赖关系，构建有向无环图（DAG），按 DAG 拓扑顺序执行 repair，使后执行的 repair 不破坏先执行的 repair 结果。

**约束依赖层次示例**（本系统）：

```
Layer 0 (最基础):  CommonHardBounds              # 纯边界 clamp，不影响其他
Layer 1 (依赖边界): CommonHardRepWorkloadRange     # 依赖单个 rep 总量
                   CommonHardHcpWorkloadRange     # 依赖单个 hcp 总量  
Layer 2 (依赖总量): CommonHardTotalVisitsRange     # 依赖全局总量
Layer 3 (依赖通道): CommonHardChannelExclusive     # 置零相互排斥渠道
Layer 4 (品牌专属): BrandAHardListingWorkload      # 依赖 listing 状态+边界
```

**实现接口**：

```python
class HardConstraint:
    repair_priority: int = 0   # 数值越小越先执行（新增属性）
    
    def repair(self, genes, ctx, rng):
        return genes  # 默认不修复（现有接口不变）
```

在 `repair_genes()` 中按优先级排序后再执行：

```python
def repair_genes_ordered(genes, ctx, hard, rng):
    """按 repair_priority 排序后执行 repair，减少约束冲突"""
    sorted_constraints = sorted(hard, key=lambda c: getattr(c, 'repair_priority', 0))
    for c in sorted_constraints:
        genes = c.repair(genes, ctx, rng)
    return genes
```

**优势**：
- **改动极小**：只需为 `HardConstraint` 添加 `repair_priority` 属性，不改变接口
- **效果显著**：大多数场景下 `max_retries=1` 即可生成有效个体
- **零额外开销**：排序在初始化时进行一次，运行时无额外开销

**劣势**：需要领域专家为每个约束指定正确的 priority。

---

### 方案 2：约束感知的定向采样

**核心思想**：不随机生成基因，而是根据约束结构直接构造一个"大概率可行"的初始解。

**示例（针对本系统）**：

```python
def directed_sample(ctx, hard, rng):
    """利用约束知识定向采样"""
    genes = np.zeros(ctx.shape, dtype=np.int32)
    
    # Step 1: 按 listing 状态设置上界约束（BrandAHardListingWorkload）
    listing_bounds = ctx.shared.get("listing_bounds")
    if listing_bounds is not None:
        hi_per_hcp = listing_bounds[:, 1]  # (n_hcps,)
        # 在 listing 约束范围内均匀采样
        for h in range(ctx.shape[1]):
            genes[:, h, :] = rng.integers(0, hi_per_hcp[h] + 1,
                                           size=(ctx.shape[0], ctx.shape[2]))
    
    # Step 2: 应用 channel_exclusive（置零互斥渠道对中的其中一个）
    # ...按约束逻辑构建
    
    return genes
```

**优势**：直接生成高质量初始种群，可行率接近 100%。

**劣势**：需要为每个品牌实现专属的定向采样逻辑，通用性差，维护成本高。

---

### 方案 3：种子种群 + 变异扩展

**核心思想**：预先手工或启发式构造少量"种子个体"（保证满足所有约束），然后通过小幅扰动生成其余种群成员。

```python
def seed_and_expand_population(seeds, pop_size, ctx, hard, rng, max_mut_prob=0.05):
    """
    seeds: List[np.ndarray] - 预构造的合法基因矩阵（至少1个）
    """
    population = list(seeds)
    attempts = 0
    while len(population) < pop_size and attempts < pop_size * 10:
        seed = seeds[rng.integers(0, len(seeds))]
        candidate = seed.copy()
        # 小幅变异（低概率）
        mut_mask = rng.random(candidate.shape) < max_mut_prob
        noise = rng.integers(-2, 3, candidate.shape)
        candidate[mut_mask] = np.clip(
            candidate[mut_mask] + noise[mut_mask],
            ctx.lo[mut_mask], ctx.hi[mut_mask]
        )
        candidate = repair_genes(candidate, ctx, hard, rng)
        ind = Individual(genes=candidate)
        if satisfies_hard(ind, ctx, hard):
            population.append(ind)
        attempts += 1
    return population
```

**优势**：实现简单，可行率高，种子可复用。

**劣势**：需要手工提供种子（或引入构造启发式），对初始多样性有影响。

---

### 方案 4：惩罚式初始化（热身期）

**核心思想**：在前 k 代（"热身期"）放宽硬约束为软约束（大权重惩罚），让种群"热启动"后再切换为严格硬约束。

```python
def warmup_optimize(ctx, evaluator, hard, soft, rng, warmup_gens=10):
    """前 warmup_gens 代使用惩罚式软化硬约束"""
    # 将硬约束转为大权重软约束
    soft_warmup = soft + [HardAsSoft(c, weight=100.0) for c in hard]
    hard_warmup = []  # 热身期无硬约束
    
    # 前 k 代优化
    for gen in range(warmup_gens):
        # ...正常 GA 步骤，但 hard=[] soft=soft_warmup
        pass
    
    # 切换回正式约束
    for gen in range(n_generations - warmup_gens):
        # ...正常 GA 步骤，hard=hard soft=soft
        pass
```

**优势**：种群始终完整（无"最佳努力"个体），可以从任意初始点收敛。

**劣势**：热身期会探索不可行区域，浪费计算资源；需要调节热身代数和权重。

---

### 方案 5：批量并行采样（工程加速）

**核心思想**：不依赖串行重试，而是一次性生成 `N × M` 个随机候选（N 为目标种群大小，M 为过采样倍率），然后并行 repair + check，取前 N 个通过的。

```python
def batch_sample_population(pop_size, ctx, hard, rng, oversample=5):
    """批量生成并筛选，避免串行重试"""
    batch = batch_random_genes(pop_size * oversample, ctx, rng)  # (N*M, *shape)
    
    # 批量 repair
    for i in range(len(batch)):
        batch[i] = repair_genes(batch[i], ctx, hard, rng)
    
    # 批量 check，筛选有效个体
    valid = []
    for i in range(len(batch)):
        ind = Individual(genes=batch[i])
        if satisfies_hard(ind, ctx, hard):
            valid.append(ind)
        if len(valid) >= pop_size:
            break
    
    # 若仍不足，回退到"最佳努力"
    while len(valid) < pop_size:
        valid.append(Individual(genes=batch[rng.integers(0, len(batch))]))
    
    return valid[:pop_size]
```

**优势**：利用 numpy 向量化，总体速度远快于串行重试；可行率取决于 oversample 倍率，通常 5×-10× 足够。

**劣势**：内存开销较大（`pop_size * oversample` 份基因矩阵）。

---

## 4. 综合推荐与实施路线图

| 优先级 | 方案 | 实施难度 | 预期效果 | 适用场景 |
|--------|------|----------|----------|----------|
| **P0** | 方案 1（拓扑排序修复） | ⭐ 低 | ★★★★ 高 | 通用，建议作为基础改进 |
| **P1** | 方案 5（批量并行采样） | ⭐⭐ 中 | ★★★ 中高 | 大规模种群，硬件资源充裕 |
| **P2** | 方案 3（种子 + 扩展） | ⭐⭐ 中 | ★★★★ 高 | 有领域专家可提供种子 |
| **P3** | 方案 4（热身期） | ⭐⭐⭐ 高 | ★★★ 中 | 约束极度复杂、可行域极稀疏 |
| **辅助** | 方案 2（定向采样） | ⭐⭐⭐ 高 | ★★★★★ 极高 | 品牌专属优化，有明确约束结构 |

### 推荐实施顺序

1. **立即实施：方案 1**  
   为所有 `HardConstraint` 添加 `repair_priority: int = 0` 属性，更新各约束类的优先级设置，修改 `repair_genes()` 使用排序版本。预计代码改动 < 50 行，风险极低。

2. **中期优化：方案 5**  
   在 `make_valid_batch()` 中引入过采样策略，用 numpy 批量生成 + 筛选替代串行重试。

3. **长期扩展（按需）：方案 3**  
   为品牌 A/B 等分别提供构造种子的启发式函数，置于各品牌的 `constraints/brands/brand_x/` 目录下。

---

## 5. 现有架构的接入点

```
visit_optimizer/
├── optimizer/
│   ├── _utils.py                 ← 修改 repair_genes() / make_valid_individual() / make_valid_batch()
│   └── algorithms/
│       └── {ga,tensor_ga,...}/   ← 算法调用方无需改动（接口不变）
└── constraints/
    ├── common/
    │   └── common_hard.py        ← 为每个通用硬约束添加 repair_priority 属性
    └── brands/
        └── brand_a/
            └── brand_a_hard.py   ← 为品牌专属约束添加 repair_priority 属性
```

接口变更（向后兼容）：
- `HardConstraint.repair_priority: int = 0`（新属性，有默认值，已有子类无需修改）
- `repair_genes(genes, ctx, hard, rng)` → 内部自动按优先级排序（签名不变）
