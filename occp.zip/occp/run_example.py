# -*- coding: utf-8 -*-
import matplotlib
matplotlib.use("Agg")  # non-interactive backend
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

# patch plt.show to no-op
import matplotlib.pyplot as _plt
_plt.show = lambda: None

import example
example.main()
