"""
tests/test_v6.py — VX_RSV 品牌测试

需求：
  1. 品牌 vx_rsv 已注册到 BRAND_REGISTRY
  2. 品牌 vx_rsv 使用 finite_diff 优化算法
  3. 品牌 vx_rsv 渠道为 f2f, online_event（2个渠道）
  4. 品牌 vx_rsv 包含 4 个硬约束（bounds + rep工作量 + HCP全渠道 + Rep全渠道）
  5. 品牌 vx_rsv 包含 4 个软约束（rep均衡 + segment紧急度 + f2f优先 + HCP分级评分）
  6. 品牌 vx_rsv 专属软约束 SegmentUrgency 正确计算惩罚
  7. 品牌 vx_rsv 专属软约束 F2fPriority 正确计算惩罚
  8. 品牌 vx_rsv 可通过模拟数据运行 finite_diff 优化并得到结果
  9. HCP 全渠道约束在优化中生效（通过 ctx.shared 传入 bounds）
  10. Rep 全渠道约束在优化中生效（通过 ctx.shared 传入 bounds）
  11. 回归测试：现有品牌和算法不受影响
  12. CommonSoftHcpSegScore 正态分布打分软约束正确计算惩罚

运行：python tests/test_v6.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import logging
import numpy as np
import visit_optimizer as vo

logging.basicConfig(level=logging.WARNING,
                    format="%(asctime)s [%(levelname)s] %(message)s",
                    datefmt="%H:%M:%S")

PASS = "[PASS]"
FAIL = "[FAIL]"

# ── VX_RSV 模拟数据 ────────────────────────────────────────────────────────
N_REPS = 4
N_HCPS = 10
HCP_SEGMENTS = ["p1", "p1", "p2", "p2", "p2", "p3", "p3", "p3", "p3", "p3"]
HCP_LISTING = [True, True, True, True, True, False, True, True, False, True]

VX_RSV_RAW = dict(
    n_reps=N_REPS,
    n_hcps=N_HCPS,
    hcp_segment=HCP_SEGMENTS,
    hcp_listing=HCP_LISTING,
    extra={"seg_call_guidance": {"p1": 6, "p2": 3, "p3": 1}},
)

# HCP 全渠道 bounds：(n_hcps=10, 2) — 每个 HCP 的总拜访上下限
HCP_TOTAL_BOUNDS = np.array([
    [5, 20],   # hcp0 (p1)
    [5, 20],   # hcp1 (p1)
    [2, 15],   # hcp2 (p2)
    [2, 15],   # hcp3 (p2)
    [2, 15],   # hcp4 (p2)
    [0, 8],    # hcp5 (p3)
    [0, 8],    # hcp6 (p3)
    [0, 8],    # hcp7 (p3)
    [0, 8],    # hcp8 (p3)
    [0, 8],    # hcp9 (p3)
], dtype=np.int32)

# Rep 全渠道 bounds：(n_reps=4, 2) — 每个 Rep 的总工作量上下限
REP_TOTAL_BOUNDS = np.array([
    [60, 100],  # rep0
    [70, 110],  # rep1
    [50, 90],   # rep2
    [40, 80],   # rep3
], dtype=np.int32)


def check(label: str, cond: bool) -> bool:
    icon = PASS if cond else FAIL
    print(f"  {icon} {label}")
    return cond


# ─────────────────────────────────────────────────────────────────────────────
# 需求 1：品牌注册
# ─────────────────────────────────────────────────────────────────────────────
def test_req1_registry():
    """验证 vx_rsv 品牌已注册"""
    print("\n[req1] 品牌 vx_rsv 注册")
    ok = True

    ok &= check("vx_rsv 在 BRAND_REGISTRY 中", "vx_rsv" in vo.BRAND_REGISTRY)

    brand = vo.BRAND_REGISTRY.build("vx_rsv")
    ok &= check(f"构建品牌实例: {brand.__class__.__name__}",
                brand.__class__.__name__ == "BrandVxRsv")
    ok &= check(f"brand_id = {brand.brand_id!r}", brand.brand_id == "vx_rsv")

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 2：使用 finite_diff 算法
# ─────────────────────────────────────────────────────────────────────────────
def test_req2_algorithm():
    """验证 vx_rsv 使用 finite_diff 算法"""
    print("\n[req2] finite_diff 算法配置")
    ok = True

    brand = vo.BRAND_REGISTRY.build("vx_rsv")
    ok &= check(f"algorithm_key = {brand.get_algorithm_key()!r}",
                brand.get_algorithm_key() == "finite_diff")

    cfg = brand.get_algorithm_config()
    ok &= check(f"n_iterations = {cfg['n_iterations']}", cfg["n_iterations"] == 30)
    ok &= check(f"step = {cfg['step']}", cfg["step"] == 1)
    ok &= check(f"seed = {cfg['seed']}", cfg["seed"] == 42)

    # 验证可通过注册表构建 finite_diff 优化器
    opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config=cfg)
    ok &= check(f"构建优化器: {opt.__class__.__name__}",
                opt.__class__.__name__ == "FiniteDiffOptimizer")

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 3：渠道为 face_to_face, remote_call
# ─────────────────────────────────────────────────────────────────────────────
def test_req3_channels():
    """验证 vx_rsv 渠道配置"""
    print("\n[req3] 渠道配置")
    ok = True

    brand = vo.BRAND_REGISTRY.build("vx_rsv")
    ok &= check(f"CHANNELS = {brand.CHANNELS}",
                brand.CHANNELS == ["f2f", "online_event"])
    ok &= check(f"渠道数量 = {len(brand.CHANNELS)}", len(brand.CHANNELS) == 2)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 4：4 个硬约束
# ─────────────────────────────────────────────────────────────────────────────
def test_req4_hard_constraints():
    """验证 vx_rsv 包含 4 个硬约束"""
    print("\n[req4] 硬约束（4个）")
    ok = True

    brand = vo.BRAND_REGISTRY.build("vx_rsv")
    hard = brand.get_hard_constraints()

    ok &= check(f"硬约束数量 = {len(hard)}", len(hard) == 4)

    names = [c.__class__.__name__ for c in hard]
    ok &= check(f"包含 CommonHardBounds",
                "CommonHardBounds" in names)
    ok &= check(f"包含 CommonHardRepWorkloadRange",
                "CommonHardRepWorkloadRange" in names)
    ok &= check(f"包含 CommonHardHcpChannelBounds",
                "CommonHardHcpChannelBounds" in names)
    ok &= check(f"包含 CommonHardRepChannelBounds",
                "CommonHardRepChannelBounds" in names)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 5：3 个软约束
# ─────────────────────────────────────────────────────────────────────────────
def test_req5_soft_constraints():
    """验证 vx_rsv 包含 4 个软约束"""
    print("\n[req5] 软约束（4个）")
    ok = True

    brand = vo.BRAND_REGISTRY.build("vx_rsv")
    raw = dict(VX_RSV_RAW)
    raw["hcp_total_bounds"] = HCP_TOTAL_BOUNDS
    raw["rep_total_bounds"] = REP_TOTAL_BOUNDS
    ctx = brand.build_context(raw)
    soft = brand.get_soft_constraints(ctx)

    ok &= check(f"软约束数量 = {len(soft)}", len(soft) == 4)

    names = [c.__class__.__name__ for c in soft]
    ok &= check(f"包含 CommonSoftRepWorkloadBalance",
                "CommonSoftRepWorkloadBalance" in names)
    ok &= check(f"包含 BrandVxRsvSoftSegmentUrgency",
                "BrandVxRsvSoftSegmentUrgency" in names)
    ok &= check(f"包含 BrandVxRsvSoftF2fPriority",
                "BrandVxRsvSoftF2fPriority" in names)
    ok &= check(f"包含 CommonSoftHcpSegScore",
                "CommonSoftHcpSegScore" in names)

    # 验证 CommonSoftHcpSegScore 的参数
    seg_score = [c for c in soft if isinstance(c, vo.CommonSoftHcpSegScore)][0]
    ok &= check(f"CommonSoftHcpSegScore.weight = {seg_score.weight}",
                seg_score.weight == 1.5)
    ok &= check(f"CommonSoftHcpSegScore.sigma = {seg_score.sigma}",
                seg_score.sigma == 1.0)
    ok &= check(f"CommonSoftHcpSegScore.guidance 包含 p1={seg_score.seg_call_guidance.get('p1')}",
                seg_score.seg_call_guidance.get("p1") == 6)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 6：SegmentUrgency 软约束计算
# ─────────────────────────────────────────────────────────────────────────────
def test_req6_segment_urgency():
    """验证 SegmentUrgency 软约束正确计算惩罚"""
    print("\n[req6] SegmentUrgency 软约束计算")
    ok = True

    from visit_optimizer.constraints.brands.brand_vx_rsv.brand_vx_rsv_soft import (
        BrandVxRsvSoftSegmentUrgency,
    )
    from visit_optimizer.optimizer.types import Individual

    # 构造 Context
    lo = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    hi = np.full((N_REPS, N_HCPS, 2), 8, dtype=np.int32)
    ctx = vo.Context(
        brand_id="vx_rsv",
        channels=["f2f", "online_event"],
        bounds=np.stack([lo, hi], axis=-1),
        shared={"hcp_segment": HCP_SEGMENTS},
    )

    constraint = BrandVxRsvSoftSegmentUrgency(p1_min=6, p2_min=3, weight=2.0)

    # 6.1 所有拜访=0 → 所有 p1/p2 都不足
    genes_zero = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    ind_zero = Individual(genes=genes_zero)
    pen_zero = constraint.raw_penalty(ind_zero, ctx)
    ok &= check(f"全零拜访 → raw_penalty = {pen_zero:.1f} > 0", pen_zero > 0)

    # p1 有 2 个（hcp0, hcp1），p2 有 3 个（hcp2, hcp3, hcp4）
    # 惩罚 = 2 * (6-0)^2 + 3 * (3-0) = 72 + 9 = 81
    expected = 2 * 36 + 3 * 3  # 72 + 9 = 81
    ok &= check(f"raw_penalty = {pen_zero:.1f} == {expected}",
                abs(pen_zero - expected) < 0.01)

    # 6.2 给 p1 HCP 足够拜访 → p1 惩罚为 0
    genes_ok = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    # hcp0: sum over reps & channels >= 6
    genes_ok[0, 0, 0] = 6
    # hcp1: sum >= 6
    genes_ok[0, 1, 0] = 6
    ind_ok = Individual(genes=genes_ok)
    pen_ok = constraint.raw_penalty(ind_ok, ctx)
    # 只有 p2 惩罚 = 3 * (3-0) = 9
    ok &= check(f"p1 满足后 raw_penalty = {pen_ok:.1f} == 9.0",
                abs(pen_ok - 9.0) < 0.01)

    # 6.3 指定渠道
    constraint_ch = BrandVxRsvSoftSegmentUrgency(
        p1_min=6, p2_min=3, channels=["f2f"], weight=1.0,
    )
    genes_ch = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    genes_ch[0, 0, 0] = 6  # hcp0 f2f=6 ≥ p1_min=6
    genes_ch[0, 1, 0] = 6  # hcp1 f2f=6 ≥ p1_min=6
    ind_ch = Individual(genes=genes_ch)
    pen_ch = constraint_ch.raw_penalty(ind_ch, ctx)
    ok &= check(f"仅 f2f 渠道：p1 满足, raw_penalty = {pen_ch:.1f} == 9.0",
                abs(pen_ch - 9.0) < 0.01)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 7：F2fPriority 软约束计算
# ─────────────────────────────────────────────────────────────────────────────
def test_req7_f2f_priority():
    """验证 F2fPriority 软约束正确计算惩罚"""
    print("\n[req7] F2fPriority 软约束计算")
    ok = True

    from visit_optimizer.constraints.brands.brand_vx_rsv.brand_vx_rsv_soft import (
        BrandVxRsvSoftF2fPriority,
    )
    from visit_optimizer.optimizer.types import Individual

    lo = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    hi = np.full((N_REPS, N_HCPS, 2), 10, dtype=np.int32)
    ctx = vo.Context(
        brand_id="vx_rsv",
        channels=["f2f", "online_event"],
        bounds=np.stack([lo, hi], axis=-1),
    )

    constraint = BrandVxRsvSoftF2fPriority(target_ratio=0.5, weight=1.0, f2f_channel="f2f")

    # 7.1 f2f 占比 100% → 无惩罚
    genes_f2f = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    genes_f2f[:, :, 0] = 5  # 全 f2f
    ind_f2f = Individual(genes=genes_f2f)
    pen_f2f = constraint.raw_penalty(ind_f2f, ctx)
    ok &= check(f"f2f=100% → penalty = {pen_f2f:.2f} == 0.0",
                abs(pen_f2f) < 0.01)

    # 7.2 f2f 占比 0% → 惩罚最大
    genes_remote = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    genes_remote[:, :, 1] = 5  # 全 remote
    ind_remote = Individual(genes=genes_remote)
    pen_remote = constraint.raw_penalty(ind_remote, ctx)
    total = float(genes_remote.sum())
    # shortfall = 0.5 - 0.0 = 0.5, penalty = 0.5 * total
    expected_pen = 0.5 * total
    ok &= check(f"f2f=0% → penalty = {pen_remote:.2f} == {expected_pen:.2f}",
                abs(pen_remote - expected_pen) < 0.01)

    # 7.3 f2f 占比 50% → 刚好无惩罚
    genes_half = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    genes_half[:, :, 0] = 5  # f2f
    genes_half[:, :, 1] = 5  # remote
    ind_half = Individual(genes=genes_half)
    pen_half = constraint.raw_penalty(ind_half, ctx)
    ok &= check(f"f2f=50% → penalty = {pen_half:.2f} == 0.0",
                abs(pen_half) < 0.01)

    # 7.4 normalize 返回 [0, 1]
    norm = constraint.normalize(pen_remote, ctx)
    ok &= check(f"normalize(remote) = {norm:.4f} ∈ [0, 1]", 0.0 <= norm <= 1.0)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 8：通过模拟数据运行 finite_diff 优化
# ─────────────────────────────────────────────────────────────────────────────
def test_req8_finite_diff_optimization():
    """验证 vx_rsv 可通过模拟数据运行 finite_diff 优化"""
    print("\n[req8] finite_diff 优化运行")
    ok = True

    brand = vo.BRAND_REGISTRY.build("vx_rsv")

    raw = dict(VX_RSV_RAW)
    raw["hcp_total_bounds"] = HCP_TOTAL_BOUNDS
    raw["rep_total_bounds"] = REP_TOTAL_BOUNDS

    ctx = brand.build_context(raw)
    ok &= check(f"Context shape = {ctx.shape}", ctx.shape == (N_REPS, N_HCPS, 2))
    ok &= check(f"Context channels = {ctx.channels}",
                ctx.channels == ["f2f", "online_event"])

    hard = brand.get_hard_constraints()
    soft = brand.get_soft_constraints(ctx)
    evaluator = brand.get_fitness_evaluator()

    algo_cfg = brand.get_algorithm_config()
    algo_cfg["n_iterations"] = 10  # 减少迭代加速测试
    algo_cfg["log_every"] = 999

    opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config=algo_cfg)
    result = opt.optimize(ctx, evaluator, hard, soft)

    ok &= check(f"优化完成，brand_id = {result.brand_id}",
                result.brand_id == "vx_rsv")
    ok &= check(f"fitness = {result.best_individual.fitness:.2f} 有限",
                np.isfinite(result.best_individual.fitness))
    ok &= check(f"genes.shape = {result.best_individual.genes.shape}",
                result.best_individual.genes.shape == (N_REPS, N_HCPS, 2))

    # 验证 bounds 约束
    genes = result.best_individual.genes
    ok &= check(f"所有 genes >= lo=0", bool(np.all(genes >= 0)))
    ok &= check(f"所有 genes <= hi=8", bool(np.all(genes <= 8)))
    ok &= check(f"genes 全为整数", bool(np.all(genes == genes.astype(int))))

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 9：HCP 全渠道约束在优化中生效
# ─────────────────────────────────────────────────────────────────────────────
def test_req9_hcp_total_bounds():
    """验证 HCP 全渠道约束通过 ctx.shared 传入并在优化中生效"""
    print("\n[req9] HCP 全渠道约束在优化中生效")
    ok = True

    from visit_optimizer.constraints.common import CommonHardHcpChannelBounds
    from visit_optimizer.optimizer.types import Individual

    # 构造严格的 HCP 全渠道 bounds
    n_reps, n_hcps = 2, 3
    channels = ["f2f", "online_event"]

    lo = np.zeros((n_reps, n_hcps, 2), dtype=np.int32)
    hi = np.full((n_reps, n_hcps, 2), 8, dtype=np.int32)

    hcp_total_bounds = np.array([
        [2, 5],   # hcp0: 总拜访 [2, 5]
        [1, 4],   # hcp1: 总拜访 [1, 4]
        [0, 3],   # hcp2: 总拜访 [0, 3]
    ], dtype=np.int32)

    ctx = vo.Context(
        brand_id="vx_rsv_test",
        channels=channels,
        bounds=np.stack([lo, hi], axis=-1),
        shared={"hcp_total_bounds": hcp_total_bounds},
    )

    constraint = CommonHardHcpChannelBounds(channels=None)

    # 构造超限个体
    genes_bad = np.full((n_reps, n_hcps, 2), 5, dtype=np.int32)
    # hcp0 total = 2*5*2 = 20 > hi=5
    ind_bad = Individual(genes=genes_bad)
    ok &= check("超限个体不通过 check", not constraint.check(ind_bad, ctx))

    # 运行有限差分优化
    hard = [
        vo.CONSTRAINT_REGISTRY.build("common_hard.bounds"),
        constraint,
    ]
    soft = []
    evaluator = vo.EVALUATOR_REGISTRY.build("dummy")

    opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
        "n_iterations": 10, "step": 1, "seed": 0, "log_every": 999,
    })
    result = opt.optimize(ctx, evaluator, hard, soft)

    best_genes = result.best_individual.genes
    hcp_totals = best_genes.sum(axis=(0, 2))  # (n_hcps,)

    ok &= check(f"优化后 hcp0 total={hcp_totals[0]} <= hi=5",
                hcp_totals[0] <= 5)
    ok &= check(f"优化后 hcp1 total={hcp_totals[1]} <= hi=4",
                hcp_totals[1] <= 4)
    ok &= check(f"优化后 hcp2 total={hcp_totals[2]} <= hi=3",
                hcp_totals[2] <= 3)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 10：Rep 全渠道约束在优化中生效
# ─────────────────────────────────────────────────────────────────────────────
def test_req10_rep_total_bounds():
    """验证 Rep 全渠道约束通过 ctx.shared 传入并在优化中生效"""
    print("\n[req10] Rep 全渠道约束在优化中生效")
    ok = True

    from visit_optimizer.constraints.common import CommonHardRepChannelBounds
    from visit_optimizer.optimizer.types import Individual

    n_reps, n_hcps = 3, 5
    channels = ["f2f", "online_event"]

    lo = np.zeros((n_reps, n_hcps, 2), dtype=np.int32)
    hi = np.full((n_reps, n_hcps, 2), 6, dtype=np.int32)

    rep_total_bounds = np.array([
        [20, 40],  # rep0
        [15, 35],  # rep1
        [10, 30],  # rep2
    ], dtype=np.int32)

    ctx = vo.Context(
        brand_id="vx_rsv_test",
        channels=channels,
        bounds=np.stack([lo, hi], axis=-1),
        shared={"rep_total_bounds": rep_total_bounds},
    )

    constraint = CommonHardRepChannelBounds(channels=None)

    # 运行有限差分优化
    hard = [
        vo.CONSTRAINT_REGISTRY.build("common_hard.bounds"),
        constraint,
    ]
    soft = []
    evaluator = vo.EVALUATOR_REGISTRY.build("dummy")

    opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
        "n_iterations": 15, "step": 1, "seed": 0, "log_every": 999,
    })
    result = opt.optimize(ctx, evaluator, hard, soft)

    best_genes = result.best_individual.genes
    rep_totals = best_genes.sum(axis=(1, 2))  # (n_reps,)

    ok &= check(f"优化完成, fitness={result.best_individual.fitness:.2f} 有限",
                np.isfinite(result.best_individual.fitness))

    for r in range(n_reps):
        ok &= check(f"rep{r} total={rep_totals[r]} ∈ [{rep_total_bounds[r,0]}, {rep_total_bounds[r,1]}]",
                    rep_total_bounds[r, 0] <= rep_totals[r] <= rep_total_bounds[r, 1] + 1)
        # +1 容差：有限差分爬山不一定严格在上限内，但不应大幅超出

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 12：CommonSoftHcpSegScore 正态分布打分
# ─────────────────────────────────────────────────────────────────────────────
def test_req12_hcp_seg_score():
    """验证 CommonSoftHcpSegScore 正态分布打分软约束正确计算惩罚"""
    print("\n[req12] CommonSoftHcpSegScore 正态分布打分")
    ok = True

    from visit_optimizer.constraints.common import CommonSoftHcpSegScore
    from visit_optimizer.optimizer.types import Individual

    guidance = {"p1": 6, "p2": 3, "p3": 1}
    hcp_seg = HCP_SEGMENTS  # ["p1", "p1", "p2", "p2", "p2", "p3", "p3", "p3", "p3", "p3"]

    lo = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    hi = np.full((N_REPS, N_HCPS, 2), 8, dtype=np.int32)
    ctx = vo.Context(
        brand_id="vx_rsv",
        channels=["f2f", "online_event"],
        bounds=np.stack([lo, hi], axis=-1),
        shared={"hcp_seg": hcp_seg},
    )

    constraint = CommonSoftHcpSegScore(
        seg_call_guidance=guidance,
        sigma=1.0,
        weight=1.5,
    )

    # 12.1 拜访次数正好等于推荐值 → 惩罚为 0
    # p1 HCP (hcp0, hcp1) 推荐=6, p2 (hcp2-4) 推荐=3, p3 (hcp5-9) 推荐=1
    genes_perfect = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    genes_perfect[0, 0, 0] = 6  # hcp0 (p1): total=6 = mu
    genes_perfect[0, 1, 0] = 6  # hcp1 (p1): total=6 = mu
    genes_perfect[0, 2, 0] = 3  # hcp2 (p2): total=3 = mu
    genes_perfect[0, 3, 0] = 3  # hcp3 (p2): total=3 = mu
    genes_perfect[0, 4, 0] = 3  # hcp4 (p2): total=3 = mu
    genes_perfect[0, 5, 0] = 1  # hcp5 (p3): total=1 = mu
    genes_perfect[0, 6, 0] = 1  # hcp6 (p3): total=1 = mu
    genes_perfect[0, 7, 0] = 1  # hcp7 (p3): total=1 = mu
    genes_perfect[0, 8, 0] = 1  # hcp8 (p3): total=1 = mu
    genes_perfect[0, 9, 0] = 1  # hcp9 (p3): total=1 = mu

    ind_perfect = Individual(genes=genes_perfect)
    pen_perfect = constraint.raw_penalty(ind_perfect, ctx)
    ok &= check(f"完美匹配推荐值 → raw_penalty = {pen_perfect:.4f} ≈ 0",
                abs(pen_perfect) < 0.01)

    # 12.2 全零拜访 → 惩罚最大（偏离大）
    genes_zero = np.zeros((N_REPS, N_HCPS, 2), dtype=np.int32)
    ind_zero = Individual(genes=genes_zero)
    pen_zero = constraint.raw_penalty(ind_zero, ctx)
    ok &= check(f"全零拜访 → raw_penalty = {pen_zero:.2f} > 0", pen_zero > 0)
    # 每个 hcp 的 pdf = exp(-0.5*(0-mu)^2)，penalty = sum(1-pdf)
    # 10 个 hcp 都偏离，惩罚应接近 n_hcps=10
    ok &= check(f"全零拜访 → raw_penalty < {N_HCPS} (理论上限)",
                pen_zero < N_HCPS)

    # 12.3 normalize 返回 [0, 1]
    norm_zero = constraint.normalize(pen_zero, ctx)
    ok &= check(f"normalize(全零) = {norm_zero:.4f} ∈ [0, 1]", 0.0 <= norm_zero <= 1.0)

    # 12.4 penalty() = weight * normalize()
    pen_final = constraint.penalty(ind_zero, ctx)
    expected_penalty = constraint.weight * norm_zero
    ok &= check(f"penalty() = {pen_final:.4f} ≈ weight*normalize = {expected_penalty:.4f}",
                abs(pen_final - expected_penalty) < 0.01)

    # 12.5 通过 vx_rsv 品牌的 build_context，验证 hcp_seg 已正确映射
    brand = vo.BRAND_REGISTRY.build("vx_rsv")
    raw = dict(VX_RSV_RAW)
    raw["hcp_total_bounds"] = HCP_TOTAL_BOUNDS
    raw["rep_total_bounds"] = REP_TOTAL_BOUNDS
    ctx_brand = brand.build_context(raw)
    ok &= check(f"build_context 后 ctx.shared['hcp_seg'] 存在",
                "hcp_seg" in ctx_brand.shared)
    ok &= check(f"hcp_seg 内容正确: {ctx_brand.shared['hcp_seg'][:3]}...",
                ctx_brand.shared["hcp_seg"] == HCP_SEGMENTS)

    # 12.6 品牌的 get_soft_constraints 中 CommonSoftHcpSegScore 能正常计算
    soft_constraints = brand.get_soft_constraints(ctx_brand)
    seg_score_constraint = [c for c in soft_constraints if isinstance(c, CommonSoftHcpSegScore)][0]
    pen_brand = seg_score_constraint.raw_penalty(ind_perfect, ctx_brand)
    ok &= check(f"品牌内 CommonSoftHcpSegScore 正常计算 penalty = {pen_brand:.4f}",
                abs(pen_brand) < 0.01)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 11：回归测试
# ─────────────────────────────────────────────────────────────────────────────
def test_req11_regression():
    """确保新增品牌不影响现有品牌和算法"""
    print("\n[req11] 回归测试（现有品牌+算法）")
    ok = True

    # 11.1 现有品牌仍可正常构建和运行
    for bid, raw_base in [
        ("brand_a", dict(
            n_reps=3, n_hcps=12,
            hcp_seg=["A","B","A","C","B","A","C","B","A","B","D","V"],
            hcp_listing=[True,False,True,True,False,True,False,True,True,False,True,False],
            extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
        )),
        ("brand_b", dict(
            n_reps=3, n_hcps=10,
            hcp_seg=["A","B","C","A","B","C","D","V","A","B"],
            hcp_listing=[True]*10,
        )),
    ]:
        brand = vo.BRAND_REGISTRY.build(bid)
        ctx = brand.build_context(raw_base)
        hard = brand.get_hard_constraints()
        soft = brand.get_soft_constraints(ctx)
        evaluator = brand.get_fitness_evaluator()
        opt = vo.ALGORITHM_REGISTRY.build(
            "finite_diff",
            config={"n_iterations": 3, "seed": 0, "log_every": 999},
        )
        r = opt.optimize(ctx, evaluator, hard, soft)
        ok &= check(f"{bid}: finite_diff fitness={r.best_individual.fitness:.2f} 有限",
                    np.isfinite(r.best_individual.fitness))

    # 11.2 所有算法仍然正常
    brand_a = vo.BRAND_REGISTRY.build("brand_a")
    raw_a = dict(
        n_reps=3, n_hcps=12,
        hcp_seg=["A","B","A","C","B","A","C","B","A","B","D","V"],
        hcp_listing=[True,False,True,True,False,True,False,True,True,False,True,False],
        extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
    )
    ctx_a = brand_a.build_context(raw_a)
    hard_a = brand_a.get_hard_constraints()
    soft_a = brand_a.get_soft_constraints(ctx_a)
    eval_a = brand_a.get_fitness_evaluator()

    for algo_key, cfg in [
        ("ga",          {"pop_size":10,"n_generations":3,"seed":0,"log_every":999}),
        ("tensor_ga",   {"pop_size":10,"n_generations":3,"seed":0,"log_every":999}),
        ("nsga3",       {"pop_size":12,"n_generations":3,"seed":0,"ref_points_p":2,"log_every":999}),
        ("tensor_nsga3",{"pop_size":12,"n_generations":3,"seed":0,"ref_points_p":2,"log_every":999}),
        ("pso",         {"n_particles":10,"n_iterations":3,"seed":0,"log_every":999}),
        ("finite_diff", {"n_iterations":3,"seed":0,"log_every":999}),
    ]:
        opt = vo.ALGORITHM_REGISTRY.build(algo_key, config=cfg)
        r = opt.optimize(ctx_a, eval_a, hard_a, soft_a)
        ok &= check(f"{algo_key}: fitness={r.best_individual.fitness:.2f} 有限",
                    np.isfinite(r.best_individual.fitness))

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 主入口
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    tests = [
        test_req1_registry,
        test_req2_algorithm,
        test_req3_channels,
        test_req4_hard_constraints,
        test_req5_soft_constraints,
        test_req6_segment_urgency,
        test_req7_f2f_priority,
        test_req8_finite_diff_optimization,
        test_req9_hcp_total_bounds,
        test_req10_rep_total_bounds,
        test_req11_regression,
        test_req12_hcp_seg_score,
    ]

    results = {}
    for t in tests:
        try:
            results[t.__name__] = t()
        except Exception as e:
            print(f"  EXCEPTION: {e}")
            import traceback; traceback.print_exc()
            results[t.__name__] = False

    print("\n" + "=" * 65)
    print("VX_RSV 品牌测试汇总")
    print("=" * 65)
    all_pass = True
    for i, (name, passed) in enumerate(results.items(), 1):
        icon = PASS if passed else FAIL
        print(f"  {icon} 需求{i}: {name}")
        if not passed:
            all_pass = False
    print("=" * 65)
    if all_pass:
        print(f"{PASS} 全部 {len(results)} 条需求均通过！")
    else:
        failed = [i+1 for i, v in enumerate(results.values()) if not v]
        print(f"{FAIL} {len(failed)} 条失败：需求 {failed}")
