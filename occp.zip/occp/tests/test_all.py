"""
tests/test_all.py — 全面测试，逐一核对 13 条需求

运行：python -m pytest tests/test_all.py -v
或：  python tests/test_all.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import logging
import numpy as np
import visit_optimizer as vo

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s",
                    datefmt="%H:%M:%S")

# ═══════════════════════════════════════════════════════════════════════════════
# 公共测试数据
# ═══════════════════════════════════════════════════════════════════════════════
N_REPS, N_HCPS = 3, 12
HCP_SEG     = ["A","B","A","C","B","A","C","B","A","B","D","V"]
HCP_LISTING = [True,False,True,True,False,True,False,True,True,False,True,False]

BASE_RAW_A = dict(
    n_reps=N_REPS, n_hcps=N_HCPS,
    hcp_seg=HCP_SEG, hcp_listing=HCP_LISTING,
    extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
)
BASE_RAW_B = dict(
    n_reps=N_REPS, n_hcps=N_HCPS,
    hcp_seg=HCP_SEG, hcp_listing=HCP_LISTING,
    extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
)

PASS = "[PASS]"
FAIL = "[FAIL]"


def check(label: str, cond: bool) -> bool:
    icon = PASS if cond else FAIL
    print(f"  {icon} {label}")
    return cond


# ═══════════════════════════════════════════════════════════════════════════════
def test_req1_module_structure():
    """需求1：algorithms/fitness 整合进 optimizer，可独立打包"""
    print("\n[需求1] optimizer 模块结构")
    ok = True
    ok &= check("GeneticAlgorithm 在 optimizer 模块",
                hasattr(vo.optimizer, "GeneticAlgorithm"))
    ok &= check("ParticleSwarmOptimizer 在 optimizer 模块",
                hasattr(vo.optimizer, "ParticleSwarmOptimizer"))
    ok &= check("FiniteDiffOptimizer 在 optimizer 模块",
                hasattr(vo.optimizer, "FiniteDiffOptimizer"))
    ok &= check("DummyEvaluator 在 optimizer 模块",
                hasattr(vo.optimizer, "DummyEvaluator"))
    ok &= check("optimizer 有 __init__.py（可打包）",
                os.path.exists("visit_optimizer/optimizer/__init__.py"))
    return ok


def test_req2_brands_in_constraints():
    """需求2：brands 整合进 constraints，common/ 下是通用约束"""
    print("\n[需求2] brands 在 constraints 下，通用约束 common_开头")
    ok = True
    cr_keys = vo.CONSTRAINT_REGISTRY.keys()
    common_hard  = [k for k in cr_keys if k.startswith("common_hard.")]
    common_soft  = [k for k in cr_keys if k.startswith("common_soft.")]
    ok &= check(f"通用硬约束（common_hard.*）: {common_hard}", len(common_hard) >= 4)
    ok &= check(f"通用软约束（common_soft.*）: {common_soft}", len(common_soft) >= 4)
    return ok


def test_req3_common_constraints_examples():
    """需求3：通用约束示例（rep/hcp 工作量上下限、总拜访次数上下限）"""
    print("\n[需求3] 通用约束示例验证")
    ok = True
    ok &= check("common_hard.rep_workload_range 已注册",
                "common_hard.rep_workload_range" in vo.CONSTRAINT_REGISTRY)
    ok &= check("common_hard.hcp_workload_range 已注册",
                "common_hard.hcp_workload_range" in vo.CONSTRAINT_REGISTRY)
    ok &= check("common_hard.total_visits_range 已注册",
                "common_hard.total_visits_range" in vo.CONSTRAINT_REGISTRY)
    ok &= check("common_hard.bounds 已注册",
                "common_hard.bounds" in vo.CONSTRAINT_REGISTRY)

    # 功能测试：总拜访次数约束
    from visit_optimizer.constraints.common.common_hard import CommonHardTotalVisitsRange
    from visit_optimizer.optimizer.types import Individual
    from visit_optimizer.core.base import Context
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    c = CommonHardTotalVisitsRange(lo_total=0, hi_total=9999)
    ind = Individual(genes=np.zeros(ctx.shape, dtype=np.int32))
    ok &= check("total_visits_range check pass for zeros", c.check(ind, ctx))
    ind2 = Individual(genes=np.ones(ctx.shape, dtype=np.int32) * 999)
    c2 = CommonHardTotalVisitsRange(lo_total=0, hi_total=1)
    ok &= check("total_visits_range check fail for large values", not c2.check(ind2, ctx))
    return ok


def test_req4_brand_specific_constraints():
    """需求4：品牌专属约束 brand_前缀，listing 状态决定上下限"""
    print("\n[需求4] 品牌专属约束（brand_a_hard.listing_workload）")
    ok = True
    cr_keys = vo.CONSTRAINT_REGISTRY.keys()
    brand_a_keys = [k for k in cr_keys if k.startswith("brand_a")]
    brand_b_keys = [k for k in cr_keys if k.startswith("brand_b")]
    ok &= check(f"品牌A专属约束: {brand_a_keys}", len(brand_a_keys) >= 2)
    ok &= check(f"品牌B专属约束: {brand_b_keys}", len(brand_b_keys) >= 1)

    # listing 功能测试
    from visit_optimizer.constraints.brands.brand_a.brand_a_hard import BrandAHardListingWorkload
    from visit_optimizer.optimizer.types import Individual
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    c = BrandAHardListingWorkload(hi_listing=10, hi_unlisting=8)

    # listing=True 的 hcp，总拜访 ≤10 应通过
    genes = np.zeros(ctx.shape, dtype=np.int32)
    ind = Individual(genes=genes.copy())
    ok &= check("listing hcp 访问量=0，通过", c.check(ind, ctx))

    # 超过上限应失败
    genes[:, 0, :] = 100   # hcp[0] listing=True，上限 10
    ind2 = Individual(genes=genes.copy())
    ok &= check("listing hcp 访问量=100，失败", not c.check(ind2, ctx))
    return ok


def test_req5_soft_constraint_normalization():
    """需求5：软约束归一化（penalty ∈ [0, weight]）"""
    print("\n[需求5] 软约束归一化")
    ok = True
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    soft = vo.BRAND_REGISTRY.build("brand_a").get_soft_constraints(ctx)

    # 随机个体
    genes = np.random.randint(0, 5, size=ctx.shape, dtype=np.int32)
    ind = vo.Individual(genes=genes)

    penalties = [c.penalty(ind, ctx) for c in soft]
    raw_penalties = [c.raw_penalty(ind, ctx) for c in soft]
    ok &= check(f"所有软约束 penalty ≥ 0: {penalties}", all(p >= 0 for p in penalties))
    ok &= check(f"软约束数量 >= 3", len(soft) >= 3)
    # 归一化：penalty = weight * normalize(raw) ≤ weight
    for c, pen in zip(soft, penalties):
        ok &= check(f"  {c.__class__.__name__} penalty={pen:.4f} ≤ weight={c.weight}",
                    pen <= c.weight + 1e-6)
    return ok


def test_req6_hcp_seg_score():
    """需求6：HCP 分级评分软约束（正态分布打分）"""
    print("\n[需求6] HCP 分级评分软约束")
    ok = True
    from visit_optimizer.constraints.common.common_soft import CommonSoftHcpSegScore
    guide = {"A": 5, "B": 3, "C": 2, "D": 1, "V": 1, "NA": 0}
    c = CommonSoftHcpSegScore(seg_call_guidance=guide, sigma=1.0, listing_only=False, weight=1.0)
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)

    # 完美匹配：每个 hcp 的拜访次数精确等于 seg 均值
    mu_map = {s: guide.get(s, 0) for s in HCP_SEG}
    perfect_visits = np.array([mu_map[s] for s in HCP_SEG], dtype=float)

    # 构造使每个 hcp 被所有 rep 在所有渠道的总拜访 = perfect_visits
    genes = np.zeros(ctx.shape, dtype=np.int32)
    for h, v in enumerate(perfect_visits):
        # 均分到第一个渠道的第一个 rep
        genes[0, h, 0] = int(v)
    ind_perfect = vo.Individual(genes=genes)

    # 均匀随机个体
    genes_rand = np.random.randint(0, 3, size=ctx.shape, dtype=np.int32)
    ind_rand = vo.Individual(genes=genes_rand)

    pen_perfect = c.penalty(ind_perfect, ctx)
    pen_rand    = c.penalty(ind_rand, ctx)

    ok &= check(f"完美匹配 penalty={pen_perfect:.6f} 接近 0", pen_perfect < 0.1)
    ok &= check(f"随机个体 penalty={pen_rand:.6f} > 完美匹配", pen_rand >= pen_perfect)
    ok &= check("listing_only=True 只对 listing hcp 评分",
                CommonSoftHcpSegScore(guide, listing_only=True).raw_penalty(ind_rand, ctx) >= 0)
    return ok


def test_req7_shared_context():
    """需求7：全流程共享数据（Context.shared）"""
    print("\n[需求7] Context.shared 全流程共享")
    ok = True
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    ok &= check("ctx.shared 包含 hcp_seg", "hcp_seg" in ctx.shared)
    ok &= check("ctx.shared 包含 hcp_listing", "hcp_listing" in ctx.shared)
    ok &= check("ctx.shared 包含 cost_matrix", "cost_matrix" in ctx.shared)
    ok &= check("ctx.shared 包含 listing_bounds", "listing_bounds" in ctx.shared)
    ok &= check("ctx.shared.listing_bounds shape 正确",
                ctx.shared["listing_bounds"].shape == (N_HCPS, 2))
    return ok


def test_req8_unified_data_structure():
    """需求8：统一 rep×hcp×channel 数据结构，算法可互换"""
    print("\n[req8] Unified data structure, algorithms interchangeable")
    ok = True
    raw = {**BASE_RAW_A}
    raw["extra"] = {"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}}
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(raw)

    for algo_key, extra_cfg in [
        ("ga",          {"pop_size":10,"n_generations":3,"seed":0,"log_every":999}),
        ("pso",         {"n_particles":10,"n_iterations":3,"seed":0,"log_every":999}),
        ("finite_diff", {"n_iterations":3,"seed":0,"log_every":999}),
    ]:
        brand     = vo.BRAND_REGISTRY.build("brand_a")
        hard      = brand.get_hard_constraints()
        soft      = brand.get_soft_constraints(ctx)
        evaluator = brand.get_fitness_evaluator()
        optimizer = vo.ALGORITHM_REGISTRY.build(algo_key, config=extra_cfg)
        r = optimizer.optimize(ctx, evaluator, hard, soft)

        shape_ok = r.best_individual.genes.shape == ctx.shape
        ok &= check(f"algo {algo_key}: genes.shape={r.best_individual.genes.shape} == {ctx.shape}",
                    shape_ok)
        ok &= check(f"algo {algo_key}: OptimizationResult complete",
                    isinstance(r, vo.OptimizationResult) and r.brand_id == "brand_a")
    return ok


def test_req9_matrix_ops():
    """需求9：优化过程矩阵运算（通过批量基因操作验证）"""
    print("\n[req9] Matrix ops acceleration")
    from visit_optimizer.optimizer._utils import batch_random_genes
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    batch = batch_random_genes(50, ctx, np.random.default_rng(0))
    ok = True
    ok &= check(f"batch_random_genes shape = (50, {ctx.shape})",
                batch.shape == (50, *ctx.shape))
    ok &= check("All genes within bounds",
                bool(np.all(batch >= ctx.lo) and np.all(batch <= ctx.hi)))
    return ok


def test_req10_brands_isolated():
    """需求10：品牌间互不影响（A/B 独立运行，结果不同）"""
    print("\n[req10] Brand isolation")
    ok = True
    ra = vo.run_brand("brand_a", BASE_RAW_A,
                      algo_override={"pop_size":20,"n_generations":5,"seed":1,"log_every":999})
    rb = vo.run_brand("brand_b", BASE_RAW_B,
                      algo_override={"pop_size":20,"n_generations":5,"seed":1,"log_every":999})
    ok &= check("Brand A channels: face_to_face/remote_call/digital",
                vo.BRAND_REGISTRY.build("brand_a").CHANNELS == ["face_to_face","remote_call","digital"])
    ok &= check("Brand B channels: face_to_face/email/conference",
                vo.BRAND_REGISTRY.build("brand_b").CHANNELS == ["face_to_face","email","conference"])
    ok &= check("Two brands have different brand_id",
                ra.brand_id != rb.brand_id)
    ok &= check(f"Brand A genes shape (reps, hcps, 3) = {ra.best_individual.genes.shape}",
                ra.best_individual.genes.shape == (N_REPS, N_HCPS, 3))
    return ok


def test_req11_three_algorithms():
    """需求11：GA / PSO / 有限差分 三算法均可用"""
    print("\n[req11] Three optimization algorithms")
    ok = True
    ok &= check("GA registered",          "ga"          in vo.ALGORITHM_REGISTRY)
    ok &= check("PSO registered",         "pso"         in vo.ALGORITHM_REGISTRY)
    ok &= check("finite_diff registered", "finite_diff" in vo.ALGORITHM_REGISTRY)

    ctx      = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    hard     = vo.BRAND_REGISTRY.build("brand_a").get_hard_constraints()
    soft     = vo.BRAND_REGISTRY.build("brand_a").get_soft_constraints(ctx)
    evaluator= vo.BRAND_REGISTRY.build("brand_a").get_fitness_evaluator()

    for algo_key, extra_cfg in [
        ("ga",          {"pop_size":8,"n_generations":3,"seed":0,"log_every":999}),
        ("pso",         {"n_particles":8,"n_iterations":3,"seed":0,"log_every":999}),
        ("finite_diff", {"n_iterations":3,"seed":0,"log_every":999}),
    ]:
        optimizer = vo.ALGORITHM_REGISTRY.build(algo_key, config=extra_cfg)
        r = optimizer.optimize(ctx, evaluator, hard, soft)
        ok &= check(f"  {algo_key} done, fitness={r.best_individual.fitness:.2f}",
                    np.isfinite(r.best_individual.fitness))
    return ok


def test_req12_yaml_io():
    """需求12：YAML 配置驱动数据读写（mock 模式）"""
    print("\n[需求12] YAML 配置驱动数据读写")
    from visit_optimizer.io.db import BrandDataLoader
    ok = True
    loader = BrandDataLoader("visit_optimizer/config/brand_a.yaml")
    raw    = loader.load()
    ok &= check("YAML 加载 brand_id=brand_a", loader.brand_id == "brand_a")
    ok &= check("raw 包含 n_reps", "n_reps" in raw)
    ok &= check("raw 包含 hcp_seg", "hcp_seg" in raw)
    ok &= check("raw 包含 extra.seg_call_guidance", "seg_call_guidance" in raw.get("extra", {}))
    return ok


def test_req13_no_hardcode():
    """需求13：无硬编码（关键参数来自 ctx/config）"""
    print("\n[需求13] 无硬编码，参数来自 ctx/config/YAML")
    ok = True
    # per-gene bounds 不再限制拜访次数（hi 默认极大值），由 listing/digital 等渠道级约束控制
    raw_mod = {**BASE_RAW_A, "bounds_lo": 0, "bounds_hi": 3}
    ctx = vo.BRAND_REGISTRY.build("brand_a").build_context(raw_mod)
    ok &= check("hi_max >= bounds_hi（per-gene bounds 不再作为硬限制）", int(ctx.hi.max()) >= 3)

    # 修改 seg_call_guidance，验证评分约束跟随：
    # 当 visits 接近 mu 时 penalty 低，远离 mu 时 penalty 高
    from visit_optimizer.constraints.common.common_soft import CommonSoftHcpSegScore
    guide = {"A": 5, "B": 3, "C": 2, "D": 1, "V": 1, "NA": 0}
    c_seg = CommonSoftHcpSegScore(guide, sigma=1.0, listing_only=False, weight=1.0)

    # 构造"完美匹配"个体：每个 hcp 的 visits ≈ seg 对应均值
    mu_map = {s: guide.get(s, 1) for s in HCP_SEG}
    genes_perfect = np.zeros(ctx.shape, dtype=np.int32)
    for h, s in enumerate(HCP_SEG):
        genes_perfect[0, h, 0] = int(mu_map[s])
    ind_perfect = vo.Individual(genes=genes_perfect)

    # 构造"全为0"个体（完全不拜访）
    genes_zero = np.zeros(ctx.shape, dtype=np.int32)
    ind_zero = vo.Individual(genes=genes_zero)

    p_perfect = c_seg.penalty(ind_perfect, ctx)
    p_zero    = c_seg.penalty(ind_zero, ctx)
    ok &= check(f"完美匹配 penalty={p_perfect:.4f} < 全零 penalty={p_zero:.4f}（seg 约束参数化正常）",
                p_perfect <= p_zero)
    return ok


# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    results = {}
    tests = [
        test_req1_module_structure,
        test_req2_brands_in_constraints,
        test_req3_common_constraints_examples,
        test_req4_brand_specific_constraints,
        test_req5_soft_constraint_normalization,
        test_req6_hcp_seg_score,
        test_req7_shared_context,
        test_req8_unified_data_structure,
        test_req9_matrix_ops,
        test_req10_brands_isolated,
        test_req11_three_algorithms,
        test_req12_yaml_io,
        test_req13_no_hardcode,
    ]

    for t in tests:
        try:
            results[t.__name__] = t()
        except Exception as e:
            print(f"  ❌ EXCEPTION: {e}")
            import traceback; traceback.print_exc()
            results[t.__name__] = False

    print("\n" + "=" * 60)
    print("测试汇总")
    print("=" * 60)
    all_pass = True
    for i, (name, passed) in enumerate(results.items(), 1):
        icon = PASS if passed else FAIL
        print(f"  {icon} 需求{i:2d}: {name}")
        if not passed:
            all_pass = False

    print("=" * 60)
    if all_pass:
        print(f"{PASS} 全部 {len(results)} 项需求均通过！")
    else:
        failed = [i+1 for i, v in enumerate(results.values()) if not v]
        print(f"{FAIL} {len(failed)} 项失败：需求 {failed}")
