"""
tests/test_v3.py — 核对 v3 新增需求

需求：
  1. 输入 Pipeline（数据处理→全局上下文→约束构建）
  2. 输出 Pipeline（优化结果→数据处理→写库）
  3. 随机种子统一设置（所有随机使用 seed）
  4. 分析需求4（GA种群生成方案 — 仅分析，不实现）

运行：python tests/test_v3.py
"""
import sys, os, asyncio
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import logging
import numpy as np
import visit_optimizer as vo

logging.basicConfig(level=logging.WARNING,
                    format="%(asctime)s [%(levelname)s] %(message)s",
                    datefmt="%H:%M:%S")

# ── 公共测试数据 ──────────────────────────────────────────────────────────────
N_REPS, N_HCPS = 3, 12
HCP_SEG     = ["A","B","A","C","B","A","C","B","A","B","D","V"]
HCP_LISTING = [True,False,True,True,False,True,False,True,True,False,True,False]
BASE_RAW_A = dict(
    n_reps=N_REPS, n_hcps=N_HCPS,
    hcp_seg=HCP_SEG, hcp_listing=HCP_LISTING,
    extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
)
BASE_RAW_B = dict(
    n_reps=N_REPS, n_hcps=N_HCPS,
    hcp_seg=HCP_SEG, hcp_listing=HCP_LISTING,
    extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
)
PASS = "[PASS]"
FAIL = "[FAIL]"

def check(label: str, cond: bool) -> bool:
    icon = PASS if cond else FAIL
    print(f"  {icon} {label}")
    return cond


# ─────────────────────────────────────────────────────────────────────────────
# 需求 1：输入 Pipeline — 数据处理→全局上下文→约束构建
# ─────────────────────────────────────────────────────────────────────────────
def test_req1_input_pipeline():
    """
    验证输入 Pipeline：
    - 品牌 A 声明了 input_pipeline_steps
    - Pipeline 运行后，中间数据存入全局上下文
    - 约束从全局上下文获取数据来构建
    - 品牌 A 和 品牌 B 的步骤列表不同（品牌间隔离）
    """
    print("\n[req1] 输入 Pipeline（数据处理→全局上下文→约束构建）")
    ok = True

    # 1.1 品牌声明了 input_pipeline_steps
    brand_a = vo.BRAND_REGISTRY.build("brand_a")
    brand_b = vo.BRAND_REGISTRY.build("brand_b")
    ok &= check("brand_a.input_pipeline_steps 非空", brand_a.input_pipeline_steps is not None)
    ok &= check("brand_b.input_pipeline_steps 非空", brand_b.input_pipeline_steps is not None)

    # 1.2 品牌间步骤列表不同
    steps_a_names = [s if isinstance(s, str) else s[0] if isinstance(s, tuple) else s.name
                     for s in brand_a.input_pipeline_steps]
    steps_b_names = [s if isinstance(s, str) else s[0] if isinstance(s, tuple) else s.name
                     for s in brand_b.input_pipeline_steps]
    ok &= check("品牌 A 步骤包含 compute_listing_bounds", "compute_listing_bounds" in steps_a_names)
    ok &= check("品牌 B 步骤不包含 compute_listing_bounds", "compute_listing_bounds" not in steps_b_names)
    ok &= check("品牌 A 包含品牌专属步骤 brand_a_digital_channel_cap", "brand_a_digital_channel_cap" in steps_a_names)
    ok &= check("品牌间步骤列表不同", steps_a_names != steps_b_names)

    # 1.3 通过 Pipeline 运行 BrandProblem.from_brand()
    prob_a = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                 algo_override={"pop_size":10,"n_generations":2,"seed":0,"log_every":999})
    ok &= check("Pipeline 集成：BrandProblem.from_brand() 创建成功", prob_a.brand_id == "brand_a")
    ok &= check("Pipeline 产物：ctx.shared 包含 listing_bounds",
                "listing_bounds" in prob_a.ctx.shared)
    ok &= check("Pipeline 产物：ctx.shared 包含 hcp_seg",
                "hcp_seg" in prob_a.ctx.shared)
    ok &= check("Pipeline 产物：ctx.shared 包含 seg_call_guidance",
                "seg_call_guidance" in prob_a.ctx.shared)
    ok &= check("Pipeline 产物：ctx.shared 包含 cost_matrix",
                "cost_matrix" in prob_a.ctx.shared)
    ok &= check("Pipeline 产物：listing_bounds shape 正确",
                prob_a.ctx.shared["listing_bounds"].shape == (N_HCPS, 2))

    # 1.4 约束从全局上下文获取数据
    result_a = prob_a.solve()
    ok &= check("Pipeline 集成：优化结果有效",
                np.isfinite(result_a.best_individual.fitness))

    # 1.5 品牌间互不影响：B 不受 A 的 listing 影响
    prob_b = vo.BrandProblem.from_brand("brand_b", BASE_RAW_B,
                 algo_override={"pop_size":10,"n_generations":2,"seed":0,"log_every":999})
    ok &= check("品牌 B 独立运行正常", prob_b.ctx.brand_id == "brand_b")
    result_b = prob_b.solve()
    ok &= check("品牌 B 约束正常：优化结果有效",
                np.isfinite(result_b.best_individual.fitness))

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 2：输出 Pipeline — 优化结果→数据处理→写库
# ─────────────────────────────────────────────────────────────────────────────
def test_req2_output_pipeline():
    """
    验证输出 Pipeline：
    - 品牌 A 声明了 output_pipeline_steps
    - run_output_pipeline() 生成 output_rows
    - output_rows 包含正确的列（task_id, brand_id, rep_idx, hcp_idx, channel, visits）
    """
    print("\n[req2] 输出 Pipeline（优化结果→数据处理→写库）")
    ok = True

    # 2.1 品牌声明了 output_pipeline_steps
    brand_a = vo.BRAND_REGISTRY.build("brand_a")
    ok &= check("brand_a.output_pipeline_steps 非空", brand_a.output_pipeline_steps is not None)

    # 2.2 通过 BrandProblem 运行输出 Pipeline
    prob_a = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                 algo_override={"pop_size":10,"n_generations":2,"seed":0,"log_every":999})
    result_a = prob_a.solve()

    out_ctx = prob_a.run_output_pipeline(result_a, channels=brand_a.CHANNELS)
    ok &= check("run_output_pipeline() 返回 Context", out_ctx is not None)
    ok &= check("output_rows 已生成",
                out_ctx is not None and "output_rows" in out_ctx)

    if out_ctx and "output_rows" in out_ctx:
        rows = out_ctx["output_rows"]
        ok &= check("output_rows 非空", len(rows) > 0)
        ok &= check("output_rows 数量 == n_reps*n_hcps*n_channels",
                    len(rows) == N_REPS * N_HCPS * len(brand_a.CHANNELS))

        # 2.3 验证列
        sample = rows[0]
        ok &= check("行包含 task_id", "task_id" in sample)
        ok &= check("行包含 brand_id", "brand_id" in sample)
        ok &= check("行包含 rep_idx", "rep_idx" in sample)
        ok &= check("行包含 hcp_idx", "hcp_idx" in sample)
        ok &= check("行包含 channel", "channel" in sample)
        ok &= check("行包含 visits（整数）", "visits" in sample and isinstance(sample["visits"], int))
        ok &= check("行包含 created_at", "created_at" in sample)
        ok &= check("task_id 正确", sample["task_id"] == prob_a.task_id)

        # 2.4 visits 在合理范围
        all_visits = [r["visits"] for r in rows]
        ok &= check("所有 visits >= 0", all(v >= 0 for v in all_visits))
    else:
        ok = False

    # 2.5 品牌 B 的 output_pipeline_steps 可以为 None（不影响运行）
    prob_b = vo.BrandProblem.from_brand("brand_b", BASE_RAW_B,
                 algo_override={"pop_size":10,"n_generations":2,"seed":0,"log_every":999})
    result_b = prob_b.solve()
    out_ctx_b = prob_b.run_output_pipeline(result_b)
    ok &= check("品牌 B output_pipeline=None → run_output_pipeline() 返回 None",
                out_ctx_b is None)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 3：随机种子统一设置
# ─────────────────────────────────────────────────────────────────────────────
def test_req3_seed_consistency():
    """
    验证随机种子统一设置：
    - 相同 seed 产生相同结果（确定性）
    - 不同 seed 产生不同结果
    - 所有算法均使用 seed 参数
    """
    print("\n[req3] 随机种子统一设置")
    ok = True

    def run_with_seed(seed):
        prob = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                     algo_override={"pop_size":20,"n_generations":5,"seed":seed,"log_every":999})
        result = prob.solve()
        return result.best_individual.fitness, result.best_individual.genes.copy()

    # 3.1 相同 seed → 相同结果
    f1, g1 = run_with_seed(42)
    f2, g2 = run_with_seed(42)
    ok &= check("seed=42 两次运行 fitness 相同", f1 == f2)
    ok &= check("seed=42 两次运行 genes 相同", np.array_equal(g1, g2))

    # 3.2 不同 seed → 很可能不同结果
    f3, g3 = run_with_seed(123)
    ok &= check("不同 seed 的 fitness 不同", f1 != f3 or not np.array_equal(g1, g3))

    # 3.3 测试 tensor_ga 的 seed
    opt_tga = vo.ALGORITHM_REGISTRY.build("tensor_ga", config={
        "pop_size": 15, "n_generations": 3, "seed": 7, "log_every": 999,
    })
    brand_a = vo.BRAND_REGISTRY.build("brand_a")
    ctx = brand_a.build_context(BASE_RAW_A)
    hard = brand_a.get_hard_constraints()
    soft = brand_a.get_soft_constraints(ctx)
    evaluator = brand_a.get_fitness_evaluator()

    r1 = opt_tga.optimize(ctx, evaluator, hard, soft)
    r2 = opt_tga.optimize(ctx, evaluator, hard, soft)
    ok &= check("tensor_ga seed=7 两次 fitness 相同", r1.best_individual.fitness == r2.best_individual.fitness)
    ok &= check("tensor_ga seed=7 两次 genes 相同",
                np.array_equal(r1.best_individual.genes, r2.best_individual.genes))

    # 3.4 测试 nsga3 的 seed
    opt_nsga = vo.ALGORITHM_REGISTRY.build("nsga3", config={
        "pop_size": 12, "n_generations": 3, "seed": 7, "ref_points_p": 2, "log_every": 999,
    })
    r3 = opt_nsga.optimize(ctx, evaluator, hard, soft)
    r4 = opt_nsga.optimize(ctx, evaluator, hard, soft)
    ok &= check("nsga3 seed=7 两次 fitness 相同", r3.best_individual.fitness == r4.best_individual.fitness)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 4（仅分析）：GA 种群生成方案分析
# ─────────────────────────────────────────────────────────────────────────────
def test_req4_population_generation_analysis():
    """
    仅分析（不实现代码）：GA 种群生成困难时的方案。
    """
    print("\n[req4] GA 种群生成方案分析（仅分析）")
    ok = True

    analysis = """
    ══════════════════════════════════════════════════════════════
    GA 种群生成困难分析 & 方案
    ══════════════════════════════════════════════════════════════

    问题场景：
      当硬约束空间非常紧凑时，随机生成 + repair + 重试
      可能在 max_retries 次内仍然无法满足所有硬约束，
      导致种群质量差（大量不满足约束的个体进入优化）。

    根本原因：
      1. 约束之间存在耦合（如 A 约束满足后 B 约束被破坏）
      2. 可行域在搜索空间中占比极小
      3. 当前 repair 是贪心的（逐约束修复），无法处理耦合约束

    ─── 推荐方案（按优先级）────────────────────────────────

    方案1：约束拓扑排序修复（最高效，推荐实现）
    ─────────────────────────────
    - 分析约束间的依赖关系，构建 DAG
    - 按 DAG 拓扑序执行 repair（而非顺序执行）
    - 示例：先修复 bounds → 再修复 total_visits → 最后修复 channel_exclusive
    - 优势：减少冲突，大多数场景 max_retries=1 即可
    - 复杂度：O(n_constraints × repair_cost)，只需在初始化时排序一次

    方案2：松驰采样 + 投影（数学优雅）
    ───────────────────────────────
    - 使用更宽松的边界初始化（如放宽 10-20%）
    - 生成后通过投影到可行域（连续松弛 + 投影 + 取整）
    - 可用交替方向乘子法 (ADMM) 或拉格朗日乘子
    - 优势：理论保证收敛到可行域
    - 劣势：需要将离散约束连续化，实现复杂度较高

    方案3：种子种群 + 变异扩展（最实用）
    ───────────────────────────────
    - 预先手工或启发式构造少量"种子个体"（确保满足所有约束）
    - 初始种群 = 种子个体 + 从种子变异扩展的个体
    - 变异时用小幅度扰动 + repair，可行率极高
    - 优势：利用领域知识，简单可靠
    - 劣势：需要人工构造种子

    方案4：惩罚式初始化（最后手段）
    ───────────────────────────────
    - 如果 max_retries 后仍无法满足，使用惩罚值代替严格拒绝
    - 在前几代中逐渐加大硬约束权重（"热身"期）
    - 优势：保证种群始终完整
    - 劣势：收敛速度可能下降

    ─── 综合推荐 ─────────────────────────────────────
    方案1 + 方案3 组合：
    - 用拓扑排序 repair 提升单次修复成功率
    - 对极少数修复失败的个体，从种子变异补充
    - 对仍失败的，回退到"最佳努力"个体（当前行为）

    实现优先级：方案1（改动最小，效果最好）
    ══════════════════════════════════════════════════════════════
    """
    print(analysis)
    ok &= check("方案分析完成（纯分析，不要求代码实现）", True)
    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 主入口
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    tests = [
        test_req1_input_pipeline,
        test_req2_output_pipeline,
        test_req3_seed_consistency,
        test_req4_population_generation_analysis,
    ]

    results = {}
    for t in tests:
        try:
            results[t.__name__] = t()
        except Exception as e:
            print(f"  EXCEPTION: {e}")
            import traceback; traceback.print_exc()
            results[t.__name__] = False

    print("\n" + "=" * 65)
    print("v3 新需求测试汇总")
    print("=" * 65)
    all_pass = True
    for i, (name, passed) in enumerate(results.items(), 1):
        icon = PASS if passed else FAIL
        print(f"  {icon} 需求{i}: {name}")
        if not passed:
            all_pass = False
    print("=" * 65)
    if all_pass:
        print(f"{PASS} 全部 {len(results)} 条需求均通过！")
    else:
        failed = [i+1 for i, v in enumerate(results.values()) if not v]
        print(f"{FAIL} {len(failed)} 条失败：需求 {failed}")
