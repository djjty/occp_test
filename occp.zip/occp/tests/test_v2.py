"""
tests/test_v2.py — 核对7条新需求

运行：python tests/test_v2.py
"""
import sys, os, asyncio
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import logging
import numpy as np
import visit_optimizer as vo

logging.basicConfig(level=logging.WARNING,
                    format="%(asctime)s [%(levelname)s] %(message)s",
                    datefmt="%H:%M:%S")

# ── 公共测试数据 ──────────────────────────────────────────────────────────────
N_REPS, N_HCPS = 3, 12
HCP_SEG     = ["A","B","A","C","B","A","C","B","A","B","D","V"]
HCP_LISTING = [True,False,True,True,False,True,False,True,True,False,True,False]
BASE_RAW_A = dict(
    n_reps=N_REPS, n_hcps=N_HCPS,
    hcp_seg=HCP_SEG, hcp_listing=HCP_LISTING,
    extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
)
BASE_RAW_B = dict(
    n_reps=N_REPS, n_hcps=N_HCPS,
    hcp_seg=HCP_SEG, hcp_listing=HCP_LISTING,
    extra={"seg_call_guidance": {"A":5,"B":3,"C":2,"D":1,"V":1,"NA":0}},
)
PASS = "[PASS]"
FAIL = "[FAIL]"

def check(label: str, cond: bool) -> bool:
    icon = PASS if cond else FAIL
    print(f"  {icon} {label}")
    return cond


# ─────────────────────────────────────────────────────────────────────────────
# 需求 1：BrandProblem + MultiBrandScheduler（串行/并行/异步）
# ─────────────────────────────────────────────────────────────────────────────
def test_req1_brand_problem_scheduler():
    print("\n[req1] BrandProblem + MultiBrandScheduler")
    ok = True

    # BrandProblem 工厂
    prob_a = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                 algo_override={"pop_size":10,"n_generations":3,"seed":0,"log_every":999})
    prob_b = vo.BrandProblem.from_brand("brand_b", BASE_RAW_B,
                 algo_override={"pop_size":10,"n_generations":3,"seed":0,"log_every":999})
    ok &= check("BrandProblem.from_brand() 创建成功", prob_a.brand_id == "brand_a")
    ok &= check("task_id 非空", bool(prob_a.task_id))
    ok &= check("problem 包含 ctx/hard/soft/evaluator/optimizer",
                all(hasattr(prob_a, attr) for attr in
                    ["ctx","hard","soft","evaluator","optimizer"]))

    # 串行调度
    sched_serial = vo.MultiBrandScheduler([prob_a, prob_b], mode="serial")
    results = sched_serial.run()
    ok &= check("串行调度：两品牌均有结果", set(results.keys()) == {"brand_a","brand_b"})
    ok &= check("串行结果类型正确",
                all(isinstance(r, vo.OptimizationResult) for r in results.values()))

    # 线程并行调度
    prob_a2 = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                  algo_override={"pop_size":8,"n_generations":2,"seed":1,"log_every":999})
    prob_b2 = vo.BrandProblem.from_brand("brand_b", BASE_RAW_B,
                  algo_override={"pop_size":8,"n_generations":2,"seed":1,"log_every":999})
    sched_thread = vo.MultiBrandScheduler([prob_a2, prob_b2], mode="thread", max_workers=2)
    results_t = sched_thread.run()
    ok &= check("线程并行调度：两品牌均有结果", set(results_t.keys()) == {"brand_a","brand_b"})

    # 异步调度
    prob_a3 = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                  algo_override={"pop_size":8,"n_generations":2,"seed":2,"log_every":999})
    prob_b3 = vo.BrandProblem.from_brand("brand_b", BASE_RAW_B,
                  algo_override={"pop_size":8,"n_generations":2,"seed":2,"log_every":999})
    sched_async = vo.MultiBrandScheduler([prob_a3, prob_b3], mode="async", max_workers=2)
    results_a = sched_async.run()
    ok &= check("异步调度：两品牌均有结果", set(results_a.keys()) == {"brand_a","brand_b"})

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 2：MLflow 记录 + task_id 存库
# ─────────────────────────────────────────────────────────────────────────────
def test_req2_tracking():
    print("\n[req2] OptimizationTracker (MLflow + TaskStore)")
    ok = True
    import tempfile, os

    tmpdir = tempfile.mkdtemp()
    try:
        db_path = os.path.join(tmpdir, "tasks.db")
        tracker = vo.OptimizationTracker(
            experiment="test_exp",
            tracking_uri=f"file:///{tmpdir}/mlruns",
            db_path=db_path,
        )
        ok &= check("OptimizationTracker 创建成功", tracker is not None)

        tid = tracker.new_task_id()
        ok &= check("new_task_id() 返回非空字符串", bool(tid) and len(tid) > 8)

        prob = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                   algo_override={"pop_size":8,"n_generations":2,"seed":0,"log_every":999})
        prob.task_id = tid
        result = None
        with tracker.start_run(brand_id="brand_a", task_id=tid, algo="ga",
                                config={"pop_size":8}):
            result = prob.solve()
            tracker.log_result(result, task_id=tid)

        task = tracker.task_store.get_task(tid)
        ok &= check("TaskStore: task 已记录", task is not None)
        ok &= check("TaskStore: status=completed", task and task["status"] == "completed")
        ok &= check("TaskStore: best_fitness 有效",
                    task and np.isfinite(task["best_fitness"]))
        ok &= check("result.task_id 注入成功", result is not None and result.task_id == tid)
    except Exception as e:
        print(f"  EXCEPTION in req2: {e}")
        ok = False
    finally:
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)
    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 3：task_id 存库（异步版）
# ─────────────────────────────────────────────────────────────────────────────
def test_req3_async_task_store():
    print("\n[req3] 异步 task_id 存库")
    ok = True
    import tempfile, os
    from visit_optimizer.io.async_db import async_upsert_task

    tmpdir = tempfile.mkdtemp()
    try:
        db_path = os.path.join(tmpdir, "tasks_async.db")
        tid = "test-async-tid-001"

        async def _test():
            await async_upsert_task(
                db_path, tid, "brand_a", algo="tensor_ga",
                status="completed", best_fitness=42.0, n_iters=10, elapsed_sec=1.5,
            )

        asyncio.run(_test())

        from visit_optimizer.core.tracking import TaskStore
        store = TaskStore(db_path)
        task = store.get_task(tid)
        ok &= check("异步 upsert: 任务已写入", task is not None)
        ok &= check("异步 upsert: best_fitness=42.0",
                    task and abs(task["best_fitness"] - 42.0) < 1e-6)
        ok &= check("异步 upsert: algo=tensor_ga",
                    task and task["algo"] == "tensor_ga")
    except Exception as e:
        print(f"  EXCEPTION in req3: {e}")
        import traceback; traceback.print_exc()
        ok = False
    finally:
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)
    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 4：异步数据库读写（asyncio + polars）
# ─────────────────────────────────────────────────────────────────────────────
def test_req4_async_db_io():
    print("\n[req4] 异步 DB 读写（BrandAsyncDataLoader / BrandAsyncResultWriter）")
    ok = True
    from visit_optimizer.io.async_db import BrandAsyncDataLoader

    async def _load():
        loader = BrandAsyncDataLoader("visit_optimizer/config/brand_a.yaml")
        return await loader.load()

    raw = asyncio.run(_load())
    ok &= check("异步加载 brand_a.yaml: 返回 raw dict", isinstance(raw, dict))
    ok &= check("raw 包含 n_reps/n_hcps", "n_reps" in raw and "n_hcps" in raw)
    ok &= check("raw 包含 hcp_seg", "hcp_seg" in raw)
    ok &= check("raw.extra 包含 seg_call_guidance",
                "seg_call_guidance" in raw.get("extra", {}))

    # 测试 _result_to_polars
    try:
        import polars as pl
        from visit_optimizer.io.async_db import _result_to_polars
        prob = vo.BrandProblem.from_brand("brand_a", BASE_RAW_A,
                   algo_override={"pop_size":8,"n_generations":2,"seed":0,"log_every":999})
        prob.task_id = "test-async-write-001"
        result = prob.solve()
        result.extra["channels"] = vo.BRAND_REGISTRY.build("brand_a").CHANNELS
        df = _result_to_polars(result)
        ok &= check("_result_to_polars: 返回 polars DataFrame",
                    isinstance(df, pl.DataFrame))
        ok &= check("DataFrame 包含 task_id/brand_id/rep_idx/hcp_idx/channel/visits",
                    set(df.columns) >= {"task_id","brand_id","rep_idx","hcp_idx","channel","visits"})
    except ImportError:
        ok &= check("polars 未安装，跳过 DataFrame 测试（预期可选）", True)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 5：TensorGA（4D tensor p×rep×hcp×channel）
# ─────────────────────────────────────────────────────────────────────────────
def test_req5_tensor_ga():
    print("\n[req5] TensorGA（4D tensor）")
    ok = True
    ok &= check("tensor_ga 已注册", "tensor_ga" in vo.ALGORITHM_REGISTRY)

    ctx      = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    hard     = vo.BRAND_REGISTRY.build("brand_a").get_hard_constraints()
    soft     = vo.BRAND_REGISTRY.build("brand_a").get_soft_constraints(ctx)
    evaluator= vo.BRAND_REGISTRY.build("brand_a").get_fitness_evaluator()

    optimizer = vo.ALGORITHM_REGISTRY.build("tensor_ga", config={
        "pop_size": 20, "n_generations": 5, "seed": 0, "log_every": 999,
    })
    result = optimizer.optimize(ctx, evaluator, hard, soft)

    ok &= check("TensorGA: 结果类型正确", isinstance(result, vo.OptimizationResult))
    ok &= check(f"TensorGA: genes.shape == {ctx.shape}",
                result.best_individual.genes.shape == ctx.shape)
    ok &= check(f"TensorGA: fitness={result.best_individual.fitness:.2f} 有限",
                np.isfinite(result.best_individual.fitness))
    ok &= check("TensorGA: history 长度 == n_generations",
                len(result.history) == 5)

    # 验证是 4D tensor 算法（通过算法类名确认）
    from visit_optimizer.optimizer.algorithms.tensor_ga.tensor_ga import TensorGeneticAlgorithm
    ok &= check("TensorGA: 算法类为 TensorGeneticAlgorithm",
                isinstance(optimizer, TensorGeneticAlgorithm))
    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 6：NSGA-III（普通版 + Tensor版）
# ─────────────────────────────────────────────────────────────────────────────
def test_req6_nsga3():
    print("\n[req6] NSGA-III 普通版 + Tensor版")
    ok = True
    ok &= check("nsga3 已注册",        "nsga3"        in vo.ALGORITHM_REGISTRY)
    ok &= check("tensor_nsga3 已注册", "tensor_nsga3" in vo.ALGORITHM_REGISTRY)

    ctx      = vo.BRAND_REGISTRY.build("brand_a").build_context(BASE_RAW_A)
    hard     = vo.BRAND_REGISTRY.build("brand_a").get_hard_constraints()
    soft     = vo.BRAND_REGISTRY.build("brand_a").get_soft_constraints(ctx)
    evaluator= vo.BRAND_REGISTRY.build("brand_a").get_fitness_evaluator()

    mini_cfg = {"pop_size":16,"n_generations":4,"ref_points_p":2,"seed":0,"log_every":999}

    for algo_key in ("nsga3", "tensor_nsga3"):
        opt = vo.ALGORITHM_REGISTRY.build(algo_key, config=mini_cfg)
        r   = opt.optimize(ctx, evaluator, hard, soft)

        ok &= check(f"{algo_key}: 结果类型正确", isinstance(r, vo.OptimizationResult))
        ok &= check(f"{algo_key}: genes.shape == {ctx.shape}",
                    r.best_individual.genes.shape == ctx.shape)
        ok &= check(f"{algo_key}: fitness={r.best_individual.fitness:.2f} 有限",
                    np.isfinite(r.best_individual.fitness))
        ok &= check(f"{algo_key}: n_obj 记录在 extra",
                    "n_obj" in r.extra and r.extra["n_obj"] == len(soft) + 1)

        # 多目标 objectives 已填充
        ok &= check(f"{algo_key}: objectives 已填充（shape=n_obj）",
                    r.best_individual.objectives is not None and
                    len(r.best_individual.objectives) == len(soft) + 1)

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 需求 7：core 只处理注册/调度（base/types 已并入 optimizer）
# ─────────────────────────────────────────────────────────────────────────────
def test_req7_core_structure():
    print("\n[req7] core 只保留注册/调度，base/types 并入 optimizer")
    ok = True


    # optimizer 包直接包含 types 和算法基类
    from visit_optimizer.optimizer.types import Individual, OptimizationResult
    from visit_optimizer.core.base import Context
    from visit_optimizer.optimizer.algorithms.base import (
        BaseFitnessEvaluator, BaseOptimizer,
    )
    from visit_optimizer.core.base import HardConstraint, SoftConstraint, BaseBrand
    ok &= check("Individual 定义在 optimizer.types", Individual is not None)
    ok &= check("Context 定义在 core.base", Context is not None)
    ok &= check("BaseOptimizer 定义在 optimizer.algorithms.base", BaseOptimizer is not None)

    # core.base 包含约束基类和 BaseBrand（但不含 BaseOptimizer/BaseFitnessEvaluator）
    import visit_optimizer.core.base as cb
    from visit_optimizer.core.base import HardConstraint as HC2, BaseBrand as BB2
    ok &= check("core.base.HardConstraint 可用", HC2 is HardConstraint)
    ok &= check("core.base.BaseBrand 可用", BB2 is BaseBrand)


    # core 只包含：registry + scheduler + tracking
    import visit_optimizer.core as core_mod
    ok &= check("core 包含 Registry",         hasattr(core_mod, "Registry"))
    ok &= check("core 包含 BrandProblem",      hasattr(core_mod, "BrandProblem"))
    ok &= check("core 包含 MultiBrandScheduler", hasattr(core_mod, "MultiBrandScheduler"))

    # core 不再包含 types.py（已删除）
    import importlib
    try:
        importlib.import_module("visit_optimizer.core.types")
        ok &= check("core/types.py 已删除", False)
    except ImportError:
        ok &= check("core/types.py 已删除", True)

    # core/base.py 不再包含 BaseFitnessEvaluator/BaseOptimizer（已移到 optimizer/algorithms/base.py）
    ok &= check("core.base 不含 BaseOptimizer",
                not hasattr(cb, "BaseOptimizer"))
    ok &= check("core.base 不含 BaseFitnessEvaluator",
                not hasattr(cb, "BaseFitnessEvaluator"))

    return ok


# ─────────────────────────────────────────────────────────────────────────────
# 主入口
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    tests = [
        test_req1_brand_problem_scheduler,
        test_req2_tracking,
        test_req3_async_task_store,
        test_req4_async_db_io,
        test_req5_tensor_ga,
        test_req6_nsga3,
        test_req7_core_structure,
    ]

    results = {}
    for t in tests:
        try:
            results[t.__name__] = t()
        except Exception as e:
            print(f"  EXCEPTION: {e}")
            import traceback; traceback.print_exc()
            results[t.__name__] = False

    print("\n" + "=" * 65)
    print("新需求测试汇总（7条）")
    print("=" * 65)
    all_pass = True
    for i, (name, passed) in enumerate(results.items(), 1):
        icon = PASS if passed else FAIL
        print(f"  {icon} 需求{i}: {name}")
        if not passed:
            all_pass = False
    print("=" * 65)
    if all_pass:
        print(f"{PASS} 全部 {len(results)} 条新需求均通过！")
    else:
        failed = [i+1 for i, v in enumerate(results.values()) if not v]
        print(f"{FAIL} {len(failed)} 条失败：需求 {failed}")
