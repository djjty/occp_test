"""
tests/test_v7.py — VX_RSV 品牌 pytest 全量单元测试

渠道：f2f, online_event（2个渠道）
基因矩阵 shape = (n_reps, n_hcps, n_channels)

覆盖范围：
  1. Mock 评估器（sklearn 模型预测销售量）
  2. 硬约束单元测试
  3. 软约束单元测试
  4. finite_diff 算法集成测试
  5. GA 算法集成测试
  6. 输出维度验证（rep × hcp × channel）

运行：pytest tests/test_v7.py -v
"""
from __future__ import annotations

import sys
import os
from unittest.mock import MagicMock, patch
from typing import List

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import visit_optimizer as vo
from visit_optimizer.optimizer.types import Individual, OptimizationResult
from visit_optimizer.core.base import Context, HardConstraint, SoftConstraint
from visit_optimizer.optimizer.evaluators import (
    DummyEvaluator, SklearnEvaluator,
)
from visit_optimizer.constraints.common import (
    CommonHardBounds,
    CommonHardRepWorkloadRange,
    CommonHardHcpChannelBounds,
    CommonHardRepChannelBounds,
    CommonSoftRepWorkloadBalance,
    CommonSoftHcpSegScore,
)
from visit_optimizer.constraints.brands.brand_vx_rsv.brand_vx_rsv_soft import (
    BrandVxRsvSoftSegmentUrgency,
    BrandVxRsvSoftF2fPriority,
)

import logging
logging.basicConfig(level=logging.WARNING)


# ═════════════════════════════════════════════════════════════════════════════
# 模拟数据
# ═════════════════════════════════════════════════════════════════════════════

N_REPS = 4
N_HCPS = 10
CHANNELS = ["f2f", "online_event"]
N_CH = len(CHANNELS)

# HCP 分级：2 个 p1，3 个 p2，5 个 p3
HCP_SEGMENTS = ["p1", "p1", "p2", "p2", "p2", "p3", "p3", "p3", "p3", "p3"]
HCP_LISTING = [True, True, True, True, True, False, True, True, False, True]

SEG_GUIDANCE = {"p1": 6, "p2": 3, "p3": 1}

# HCP 全渠道 bounds：(n_hcps=10, 2)
HCP_TOTAL_BOUNDS = np.array([
    [5, 20],   # hcp0 (p1)
    [5, 20],   # hcp1 (p1)
    [2, 15],   # hcp2 (p2)
    [2, 15],   # hcp3 (p2)
    [2, 15],   # hcp4 (p2)
    [0, 8],    # hcp5 (p3)
    [0, 8],    # hcp6 (p3)
    [0, 8],    # hcp7 (p3)
    [0, 8],    # hcp8 (p3)
    [0, 8],    # hcp9 (p3)
], dtype=np.int32)

# Rep 全渠道 bounds：(n_reps=4, 2)
REP_TOTAL_BOUNDS = np.array([
    [60, 100],
    [70, 110],
    [50, 90],
    [40, 80],
], dtype=np.int32)


def make_vx_rsv_raw() -> dict:
    """构造 VX_RSV 模拟数据 raw dict"""
    # Per-channel HCP bounds: (n_hcps, n_channels, 2)
    # Each channel gets half of the total bounds as a reasonable default
    n_ch = len(["f2f", "online_event"])
    hcp_channel_bounds = np.zeros((N_HCPS, n_ch, 2), dtype=np.int32)
    for h in range(N_HCPS):
        for ch in range(n_ch):
            hcp_channel_bounds[h, ch, 1] = HCP_TOTAL_BOUNDS[h, 1]  # hi = total hi

    # Per-channel Rep bounds: (n_reps, n_channels, 2)
    # Split total bounds evenly across channels
    rep_channel_bounds = np.zeros((N_REPS, n_ch, 2), dtype=np.int32)
    for r in range(N_REPS):
        for ch in range(n_ch):
            rep_channel_bounds[r, ch, 0] = max(1, REP_TOTAL_BOUNDS[r, 0] // n_ch)
            rep_channel_bounds[r, ch, 1] = REP_TOTAL_BOUNDS[r, 1]

    return {
        "n_reps": N_REPS,
        "n_hcps": N_HCPS,
        "hcp_segment": HCP_SEGMENTS,
        "hcp_listing": HCP_LISTING,
        "hcp_channel_bounds": hcp_channel_bounds,
        "hcp_total_bounds": HCP_TOTAL_BOUNDS,
        "rep_channel_bounds": rep_channel_bounds,
        "rep_total_bounds": REP_TOTAL_BOUNDS,
        "extra": {"seg_call_guidance": SEG_GUIDANCE},
    }


def make_vx_rsv_ctx(raw: dict | None = None) -> Context:
    """构建 VX_RSV Context"""
    brand = vo.BRAND_REGISTRY.build("vx_rsv")
    return brand.build_context(raw or make_vx_rsv_raw())


def make_individual(genes: np.ndarray | None = None) -> Individual:
    """构造 Individual"""
    if genes is None:
        genes = np.random.randint(0, 5, size=(N_REPS, N_HCPS, N_CH), dtype=np.int32)
    return Individual(genes=genes.astype(np.int32))


# ═════════════════════════════════════════════════════════════════════════════
# Fixture
# ═════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def brand():
    return vo.BRAND_REGISTRY.build("vx_rsv")


@pytest.fixture
def raw():
    return make_vx_rsv_raw()


@pytest.fixture
def ctx(raw):
    return make_vx_rsv_ctx(raw)


@pytest.fixture
def hard_constraints(brand):
    return brand.get_hard_constraints()


@pytest.fixture
def soft_constraints(brand, ctx):
    return brand.get_soft_constraints(ctx)


@pytest.fixture
def mock_sklearn_model():
    """Mock sklearn 模型：predict 返回销售量"""
    model = MagicMock()
    # 模型对输入特征线性响应，简单模拟销售预测
    model.predict = MagicMock(side_effect=lambda X: np.array([float(np.sum(X) * 10.0 + 50.0)]))
    return model


@pytest.fixture
def mock_evaluator(mock_sklearn_model):
    """构造 SklearnEvaluator（使用 Mock 模型）"""
    return SklearnEvaluator(model=mock_sklearn_model)


# ═════════════════════════════════════════════════════════════════════════════
# 1. 品牌基础验证
# ═════════════════════════════════════════════════════════════════════════════

class TestBrandBasics:
    """品牌注册、渠道、配置基础测试"""

    def test_brand_registered(self):
        assert "vx_rsv" in vo.BRAND_REGISTRY

    def test_brand_instance(self, brand):
        assert brand.brand_id == "vx_rsv"
        assert isinstance(brand, vo.BaseBrand)

    def test_channels(self, brand):
        assert brand.CHANNELS == ["f2f", "online_event"]
        assert len(brand.CHANNELS) == 2

    def test_algorithm_key(self, brand):
        assert brand.get_algorithm_key() == "finite_diff"

    def test_algorithm_config(self, brand):
        cfg = brand.get_algorithm_config()
        assert cfg["n_iterations"] == 30
        assert cfg["step"] == 1
        assert cfg["seed"] == 42

    def test_context_shape(self, ctx):
        assert ctx.shape == (N_REPS, N_HCPS, N_CH)
        assert ctx.channels == ["f2f", "online_event"]

    def test_context_shared_hcp_seg(self, ctx):
        assert "hcp_seg" in ctx.shared
        assert ctx.shared["hcp_seg"] == HCP_SEGMENTS

    def test_context_shared_bounds(self, ctx):
        assert "hcp_total_bounds" in ctx.shared
        assert ctx.shared["hcp_total_bounds"].shape == (N_HCPS, 2)
        assert "rep_total_bounds" in ctx.shared
        assert ctx.shared["rep_total_bounds"].shape == (N_REPS, 2)


# ═════════════════════════════════════════════════════════════════════════════
# 2. Mock 评估器测试
# ═════════════════════════════════════════════════════════════════════════════

class TestMockEvaluator:
    """Mock sklearn 评估器测试"""

    def test_sklearn_evaluator_predict(self, mock_evaluator, ctx):
        """验证 Mock 评估器的 predict_sales 返回合理销售量"""
        ind = make_individual()
        sales = mock_evaluator.predict_sales(ind, ctx)
        assert isinstance(sales, float)
        assert sales > 0  # 销售量应为正数

    def test_sklearn_evaluator_evaluate_no_penalty(self, mock_evaluator, ctx):
        """无软约束时 fitness == sales"""
        ind = make_individual()
        mock_evaluator.evaluate(ind, ctx, soft=None, penalty_weight=1.0)
        assert ind.fitness == ind.penalty + mock_evaluator.predict_sales(
            Individual(genes=ind.genes), ctx
        )

    def test_sklearn_evaluator_evaluate_with_penalty(self, mock_evaluator, ctx):
        """有软约束时 fitness = sales - penalty"""
        ind = make_individual()
        sales_before = mock_evaluator.predict_sales(ind, ctx)

        # 用一个简单的 mock 软约束
        mock_soft = MagicMock()
        mock_soft.penalty.return_value = 5.0

        mock_evaluator.evaluate(ind, ctx, soft=[mock_soft], penalty_weight=1.0)
        assert ind.fitness == pytest.approx(sales_before - 5.0, abs=0.01)

    def test_sklearn_evaluator_with_soft_constraints(self, mock_evaluator, ctx, soft_constraints):
        """Mock 评估器配合真实软约束计算 fitness"""
        ind = make_individual()
        mock_evaluator.evaluate(ind, ctx, soft=soft_constraints, penalty_weight=1.0)
        assert np.isfinite(ind.fitness)
        assert ind.penalty >= 0
        # fitness 应 <= sales（因为 penalty >= 0）
        assert ind.fitness <= mock_evaluator.predict_sales(
            Individual(genes=ind.genes), ctx
        )

    def test_dummy_evaluator(self, ctx):
        """DummyEvaluator 返回 sum(genes)"""
        evaluator = DummyEvaluator()
        genes = np.ones((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = Individual(genes=genes)
        sales = evaluator.predict_sales(ind, ctx)
        assert sales == float(N_REPS * N_HCPS * N_CH)

    def test_dummy_evaluator_with_coeff(self, ctx):
        """DummyEvaluator 支持自定义系数矩阵"""
        coeff = np.full((N_REPS, N_HCPS, N_CH), 2.0)
        evaluator = DummyEvaluator(coeff_matrix=coeff)
        genes = np.ones((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = Individual(genes=genes)
        sales = evaluator.predict_sales(ind, ctx)
        assert sales == float(N_REPS * N_HCPS * N_CH * 2)


# ═════════════════════════════════════════════════════════════════════════════
# 3. 硬约束单元测试
# ═════════════════════════════════════════════════════════════════════════════

class TestV18SparseAssignmentAndNALimit:
    """v18: 稀疏 assignment mask + rep 下界强制 + NA 限制"""

    def test_sparse_assignment_mask(self):
        """每个 HCP 最多 2 个 rep"""
        mask = np.array([
            [1,1, 1,1, 1,1, 1,1, 1,1, 0,0, 1,1, 1,1, 0,0, 0,0],
            [1,1, 1,1, 1,1, 1,1, 0,0, 1,1, 0,0, 0,0, 1,1, 0,0],
            [0,0, 0,0, 0,0, 0,0, 1,1, 1,1, 1,1, 0,0, 0,0, 0,0],
            [0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 1,1, 1,1, 1,1],
        ], dtype=bool).reshape(4, 10, 2)
        for h in range(10):
            n_assigned = sum(1 for r in range(4) if mask[r, h, :].any())
            assert n_assigned <= 2, f"HCP {h} has {n_assigned} reps, max 2"

    def test_constraint_aware_init_no_na_when_normal_has_room(self):
        """正常 HCP 未满时不给 NA 分配"""
        from visit_optimizer.constraints.brands.brand_vx_rsv.brand import BrandVxRsv
        from visit_optimizer.optimizer._utils import constraint_aware_random_genes

        brand = BrandVxRsv()
        mask = np.array([
            [1,1, 1,1, 1,1, 1,1, 1,1, 0,0, 1,1, 1,1, 0,0, 0,0],
            [1,1, 1,1, 1,1, 1,1, 0,0, 1,1, 0,0, 0,0, 1,1, 0,0],
            [0,0, 0,0, 0,0, 0,0, 1,1, 1,1, 1,1, 0,0, 0,0, 0,0],
            [0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 1,1, 1,1, 1,1],
        ], dtype=bool).reshape(4, 10, 2)
        raw = {
            "n_reps": 4, "n_hcps": 10,
            "hcp_segment": ["A","A","B","B","B","C","C","D","D","NA"],
            "hcp_listing": [True]*10,
            "hcp_channel_bounds": np.array([
                [[0,10],[0,10]], [[0,10],[0,10]],
                [[0,7],[0,7]], [[0,7],[0,7]], [[0,7],[0,7]],
                [[0,3],[0,3]], [[0,3],[0,3]], [[0,3],[0,3]],
                [[0,3],[0,3]],
                [[0,1000],[0,1000]],
            ], dtype=np.int32),
            "hcp_total_bounds": np.array([
                [0,18],[0,18],[0,12],[0,12],[0,12],[0,5],[0,5],[0,5],[0,5],[0,1000],
            ], dtype=np.int32),
            "rep_channel_bounds": np.array([
                [[30,60],[30,60]], [[35,65],[35,65]], [[25,50],[25,50]], [[20,45],[20,45]],
            ], dtype=np.int32),
            "rep_total_bounds": np.array([[60,100],[70,110],[50,90],[40,80]], dtype=np.int32),
            "assignment_mask": mask,
            "extra": {"seg_call_guidance": {"A":6,"B":3,"C":1,"D":1,"NA":0}},
        }
        ctx = brand.build_context(raw)
        hard = brand.get_hard_constraints()
        rng = np.random.default_rng(42)

        # Generate and verify
        for _ in range(20):
            g = constraint_aware_random_genes(ctx, rng)
            # Check: if NA has visits, all normal HCPs accessible to the same rep must be full
            for r in range(4):
                na_visits = sum(
                    int(g[r, h, :].sum())
                    for h in range(10)
                    if raw["hcp_segment"][h] == "NA" and mask[r, h, :].any()
                )
                if na_visits > 0:
                    # Verify all normal HCPs are at their total bounds
                    for h in range(10):
                        if raw["hcp_segment"][h] == "NA":
                            continue
                        if not mask[r, h, :].any():
                            continue
                        hcp_total = int(g[:, h, :].sum())
                        hcp_hi = int(raw["hcp_total_bounds"][h, 1])
                        # Normal HCP should be saturated (at or very near its upper bound)
                        assert hcp_total >= hcp_hi - 1, (
                            f"Rep {r}: NA has {na_visits} visits but HCP {h} total={hcp_total} < hi={hcp_hi}"
                        )


class TestHardConstraints:
    """硬约束单元测试"""

    def test_hard_constraint_count(self, hard_constraints):
        # bounds + rep_workload + per-channel hcp + per-channel rep + overall hcp + overall rep = 6
        assert len(hard_constraints) == 6

    def test_hard_constraint_types(self, hard_constraints):
        names = [c.__class__.__name__ for c in hard_constraints]
        assert "CommonHardBounds" in names
        assert "CommonHardRepWorkloadRange" in names
        # 2个 HCP bounds: per-channel + overall
        assert names.count("CommonHardHcpChannelBounds") == 2
        # 2个 Rep bounds: per-channel + overall
        assert names.count("CommonHardRepChannelBounds") == 2

    def test_bounds_check_pass(self, ctx):
        """正常范围内的个体通过 bounds 检查"""
        genes = np.full((N_REPS, N_HCPS, N_CH), 4, dtype=np.int32)
        ind = make_individual(genes)
        constraint = CommonHardBounds()
        assert constraint.check(ind, ctx) is True

    def test_bounds_check_fail_upper(self, ctx):
        """超出上界的个体不通过"""
        genes = np.full((N_REPS, N_HCPS, N_CH), ctx.hi.max() + 1, dtype=np.int32)
        ind = make_individual(genes)
        constraint = CommonHardBounds()
        assert constraint.check(ind, ctx) is False

    def test_bounds_check_fail_lower(self, ctx):
        """低于下界的个体不通过"""
        genes = np.full((N_REPS, N_HCPS, N_CH), -1, dtype=np.int32)
        ind = make_individual(genes)
        constraint = CommonHardBounds()
        assert constraint.check(ind, ctx) is False

    def test_bounds_repair(self, ctx):
        """repair 将超出范围的值裁剪到边界"""
        genes = np.full((N_REPS, N_HCPS, N_CH), 10, dtype=np.int32)
        constraint = CommonHardBounds()
        repaired = constraint.repair(genes, ctx, np.random.default_rng(0))
        assert np.all(repaired <= ctx.hi)
        assert np.all(repaired >= ctx.lo)

    def test_rep_workload_check_pass(self, ctx):
        """Rep 总工作量在范围内"""
        # 每个Rep总和需要 >= 1
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        for r in range(N_REPS):
            genes[r, 0, 0] = 2  # 每个 rep 至少 2 次拜访
        ind = make_individual(genes)
        constraint = CommonHardRepWorkloadRange(lo_total=1)
        assert constraint.check(ind, ctx) is True

    def test_rep_workload_check_fail(self, ctx):
        """Rep 总工作量为 0 时不通过"""
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = make_individual(genes)
        constraint = CommonHardRepWorkloadRange(lo_total=1)
        assert constraint.check(ind, ctx) is False

    def test_hcp_total_bounds_check_pass(self, ctx):
        """HCP 全渠道在 bounds 内"""
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        for h in range(N_HCPS):
            lo_h = int(HCP_TOTAL_BOUNDS[h, 0])
            genes[0, h, 0] = lo_h  # 每个 hcp 给最低拜访
        ind = make_individual(genes)
        constraint = CommonHardHcpChannelBounds(channels=None)
        assert constraint.check(ind, ctx) is True

    def test_hcp_total_bounds_check_fail(self, ctx):
        """HCP 总拜访超出上限"""
        genes = np.full((N_REPS, N_HCPS, N_CH), 10, dtype=np.int32)
        ind = make_individual(genes)
        constraint = CommonHardHcpChannelBounds(channels=None)
        assert constraint.check(ind, ctx) is False

    def test_hcp_total_bounds_repair(self, ctx):
        """HCP 全渠道 repair 后总拜访不超过上限"""
        genes = np.full((N_REPS, N_HCPS, N_CH), 10, dtype=np.int32)
        constraint = CommonHardHcpChannelBounds(channels=None)
        rng = np.random.default_rng(42)
        repaired = constraint.repair(genes.copy(), ctx, rng)
        hcp_totals = repaired.sum(axis=(0, 2))
        for h in range(N_HCPS):
            assert hcp_totals[h] <= HCP_TOTAL_BOUNDS[h, 1]

    def test_rep_total_bounds_check_pass(self, ctx):
        """Rep 全渠道在 bounds 内（简单场景：使用宽松 bounds）"""
        lo_test = np.zeros((N_REPS, 2), dtype=np.int32)
        hi_test = np.full((N_REPS, 2), 100, dtype=np.int32)
        shared_local = dict(ctx.shared)
        shared_local["rep_total_bounds"] = np.stack([lo_test[:, 0], hi_test[:, 1]], axis=1)
        ctx_local = Context(
            brand_id="vx_rsv_test",
            channels=CHANNELS,
            bounds=ctx.bounds,
            shared=shared_local,
        )
        genes = np.full((N_REPS, N_HCPS, N_CH), 3, dtype=np.int32)
        ind = make_individual(genes)
        constraint = CommonHardRepChannelBounds(channels=None)
        assert constraint.check(ind, ctx_local) is True

    def test_rep_total_bounds_check_fail(self, ctx):
        """Rep 总工作量超出上限"""
        genes = np.full((N_REPS, N_HCPS, N_CH), 10, dtype=np.int32)
        ind = make_individual(genes)
        constraint = CommonHardRepChannelBounds(channels=None)
        assert constraint.check(ind, ctx) is False

    def test_rep_total_bounds_repair(self, ctx):
        """Rep 全渠道 repair 后不超过上限"""
        genes = np.full((N_REPS, N_HCPS, N_CH), 10, dtype=np.int32)
        constraint = CommonHardRepChannelBounds(channels=None)
        rng = np.random.default_rng(42)
        repaired = constraint.repair(genes.copy(), ctx, rng)
        rep_totals = repaired.sum(axis=(1, 2))
        for r in range(N_REPS):
            assert rep_totals[r] <= REP_TOTAL_BOUNDS[r, 1]

    def test_all_hard_constraints_combined(self, ctx, hard_constraints):
        """组合硬约束检查"""
        # 合法个体
        genes = np.full((N_REPS, N_HCPS, N_CH), 3, dtype=np.int32)
        ind = make_individual(genes)
        all_pass = all(c.check(ind, ctx) for c in hard_constraints)
        # 不一定全通过（可能 HCP/Rep bounds 不满足），但应能运行不报错
        assert isinstance(all_pass, bool)


# ═════════════════════════════════════════════════════════════════════════════
# 4. 软约束单元测试
# ═════════════════════════════════════════════════════════════════════════════

class TestSoftConstraints:
    """软约束单元测试"""

    def test_soft_constraint_count(self, soft_constraints):
        assert len(soft_constraints) == 4

    def test_soft_constraint_types(self, soft_constraints):
        names = [c.__class__.__name__ for c in soft_constraints]
        assert "CommonSoftRepWorkloadBalance" in names
        assert "BrandVxRsvSoftSegmentUrgency" in names
        assert "BrandVxRsvSoftF2fPriority" in names
        assert "CommonSoftHcpSegScore" in names

    def test_rep_workload_balance_penalty(self, ctx):
        """Rep 工作量方差惩罚"""
        constraint = CommonSoftRepWorkloadBalance(weight=1.0)
        genes = np.full((N_REPS, N_HCPS, N_CH), 5, dtype=np.int32)
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        # 所有 rep 工作量相同 → 方差 = 0
        assert pen == pytest.approx(0.0, abs=0.01)

    def test_rep_workload_balance_penalty_unbalanced(self, ctx):
        """不均衡工作量有惩罚"""
        constraint = CommonSoftRepWorkloadBalance(weight=1.0)
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        genes[0, :, :] = 10  # rep0 很多
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        assert pen > 0

    def test_segment_urgency_zero_visits(self, ctx):
        """全零拜访时 p1/p2/p3 惩罚"""
        constraint = BrandVxRsvSoftSegmentUrgency(p1_min=6, p2_min=3, weight=2.0)
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        # p1: 2 HCP, min=6, shortfall=6, weight=2 → 2 * (6)^2 = 72
        # p2: 3 HCP, min=3, shortfall=3, weight=2 → 2 * 3 * 3 = 18  ... 但 p2 非高优先级用线性
        # 注意：weight=2.0 不乘以 penalty，raw_penalty 不含 weight
        # p1(2个): 2*(6-0)^2 = 72, p2(3个): 3*(3-0) = 9, p3(5个): 5*(1-0) = 5
        # 合计 = 72 + 9 + 5 = 86
        assert pen == pytest.approx(86.0, abs=0.01)

    def test_segment_urgency_satisfied(self, ctx):
        """p1 满足后 p2/p3 惩罚"""
        constraint = BrandVxRsvSoftSegmentUrgency(p1_min=6, p2_min=3, weight=2.0)
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        genes[0, 0, 0] = 6  # hcp0 (p1) = 6
        genes[0, 1, 0] = 6  # hcp1 (p1) = 6
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        # p1 满足(6>=6)，无惩罚
        # p2(3个): 每个 shortfall=3, 线性 → 3*3=9
        # p3(5个): 每个 shortfall=1, 线性 → 5*1=5
        # 合计 = 9 + 5 = 14
        assert pen == pytest.approx(14.0, abs=0.01)

    def test_segment_urgency_normalize(self, ctx):
        """归一化在 [0, 1]"""
        constraint = BrandVxRsvSoftSegmentUrgency(p1_min=6, p2_min=3, weight=2.0)
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = make_individual(genes)
        raw_pen = constraint.raw_penalty(ind, ctx)
        norm = constraint.normalize(raw_pen, ctx)
        assert 0.0 <= norm <= 1.0

    def test_f2f_priority_full_f2f(self, ctx):
        """100% f2f → 无惩罚"""
        constraint = BrandVxRsvSoftF2fPriority(
            target_ratio=0.5, weight=1.0, f2f_channel="f2f"
        )
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        genes[:, :, 0] = 5  # 全 f2f
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        assert pen == pytest.approx(0.0, abs=0.01)

    def test_f2f_priority_no_f2f(self, ctx):
        """0% f2f → 惩罚最大"""
        constraint = BrandVxRsvSoftF2fPriority(
            target_ratio=0.5, weight=1.0, f2f_channel="f2f"
        )
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        genes[:, :, 1] = 5  # 全 online_event
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        total = float(genes.sum())
        expected = 0.5 * total  # shortfall = 0.5, penalty = 0.5 * total
        assert pen == pytest.approx(expected, abs=0.01)

    def test_f2f_priority_half_f2f(self, ctx):
        """50% f2f → 无惩罚"""
        constraint = BrandVxRsvSoftF2fPriority(
            target_ratio=0.5, weight=1.0, f2f_channel="f2f"
        )
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        genes[:, :, 0] = 5  # f2f
        genes[:, :, 1] = 5  # online_event
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        assert pen == pytest.approx(0.0, abs=0.01)

    def test_hcp_seg_score_perfect_match(self, ctx):
        """完美匹配推荐值 → 惩罚为 0"""
        constraint = CommonSoftHcpSegScore(
            seg_call_guidance=SEG_GUIDANCE, sigma=1.0, weight=1.5
        )
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        # 每个 hcp 总拜访 = 推荐值
        for h, seg in enumerate(HCP_SEGMENTS):
            genes[0, h, 0] = int(SEG_GUIDANCE[seg])
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        assert pen == pytest.approx(0.0, abs=0.01)

    def test_hcp_seg_score_zero_visits(self, ctx):
        """全零拜访 → 惩罚 > 0"""
        constraint = CommonSoftHcpSegScore(
            seg_call_guidance=SEG_GUIDANCE, sigma=1.0, weight=1.5
        )
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = make_individual(genes)
        pen = constraint.raw_penalty(ind, ctx)
        assert pen > 0
        assert pen < N_HCPS  # 理论上限

    def test_hcp_seg_score_normalize(self, ctx):
        """归一化在 [0, 1]"""
        constraint = CommonSoftHcpSegScore(
            seg_call_guidance=SEG_GUIDANCE, sigma=1.0, weight=1.5
        )
        genes = np.zeros((N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = make_individual(genes)
        raw_pen = constraint.raw_penalty(ind, ctx)
        norm = constraint.normalize(raw_pen, ctx)
        assert 0.0 <= norm <= 1.0

    def test_penalty_weight(self, soft_constraints):
        """每个软约束的 weight > 0"""
        for c in soft_constraints:
            assert c.weight > 0

    def test_all_soft_penalties_non_negative(self, ctx, soft_constraints):
        """所有软约束 penalty >= 0"""
        genes = np.random.randint(0, 5, size=(N_REPS, N_HCPS, N_CH), dtype=np.int32)
        ind = make_individual(genes)
        for c in soft_constraints:
            pen = c.penalty(ind, ctx)
            assert pen >= 0


# ═════════════════════════════════════════════════════════════════════════════
# 5. finite_diff 算法集成测试
# ═════════════════════════════════════════════════════════════════════════════

class TestFiniteDiffOptimization:
    """finite_diff 算法集成测试（使用 Mock 评估器）"""

    def test_finite_diff_converges(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """finite_diff 使用 Mock 评估器能正常收敛"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 15,
            "step": 1,
            "penalty_weight": 1.0,
            "seed": 42,
            "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        assert result.brand_id == "vx_rsv"
        assert np.isfinite(result.best_individual.fitness)
        assert result.best_individual.genes.shape == (N_REPS, N_HCPS, N_CH)
        assert len(result.history) > 0

    def test_finite_diff_respects_bounds(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """finite_diff 结果满足 bounds 约束"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 10, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        assert np.all(genes >= 0)
        # Per-gene hi 不再限制为固定值；由更高层 HCP/Rep bounds 约束控制
        # genes 应为非负整数
        assert np.all(genes == genes.astype(int))

    def test_finite_diff_hcp_total_bounds(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """finite_diff 结果 HCP 全渠道在 bounds 内"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 10, "seed": 0, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        hcp_totals = genes.sum(axis=(0, 2))
        for h in range(N_HCPS):
            assert hcp_totals[h] <= HCP_TOTAL_BOUNDS[h, 1] + 1  # +1 容差

    def test_finite_diff_rep_total_bounds(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """finite_diff 结果 Rep 全渠道在 bounds 内"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 10, "seed": 0, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        rep_totals = genes.sum(axis=(1, 2))
        for r in range(N_REPS):
            # finite_diff 是爬山算法，初始随机解可能不在 rep bounds 内
            # 只检查不超过上限（上界约束优先）
            assert rep_totals[r] <= REP_TOTAL_BOUNDS[r, 1] + 2

    def test_finite_diff_output_shape(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """输出 shape = (n_reps, n_hcps, n_channels)"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 5, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        assert genes.shape == (N_REPS, N_HCPS, N_CH)
        assert genes.dtype == np.int32

    def test_finite_diff_history_monotonic(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """history 中 fitness 应单调不降"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 10, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        history = result.history
        for i in range(1, len(history)):
            assert history[i] >= history[i - 1]


# ═════════════════════════════════════════════════════════════════════════════
# 6. GA 算法集成测试
# ═════════════════════════════════════════════════════════════════════════════

class TestGAOptimization:
    """GA 算法集成测试（使用 Mock 评估器）"""

    def test_ga_converges(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """GA 使用 Mock 评估器能正常完成"""
        opt = vo.ALGORITHM_REGISTRY.build("ga", config={
            "pop_size": 10,
            "n_generations": 5,
            "seed": 42,
            "log_every": 999,
            "oversample_ratio": 10,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        assert result.brand_id == "vx_rsv"
        assert np.isfinite(result.best_individual.fitness)
        assert result.best_individual.genes.shape == (N_REPS, N_HCPS, N_CH)

    def test_ga_respects_bounds(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """GA 结果满足 bounds 约束（非负 + hi 不超限）"""
        opt = vo.ALGORITHM_REGISTRY.build("ga", config={
            "pop_size": 10, "n_generations": 5, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        assert np.all(genes >= 0)
        assert np.all(genes <= ctx.hi)

    def test_ga_output_shape(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """GA 输出 shape 正确"""
        opt = vo.ALGORITHM_REGISTRY.build("ga", config={
            "pop_size": 10, "n_generations": 5, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        assert result.best_individual.genes.shape == (N_REPS, N_HCPS, N_CH)

    def test_ga_hcp_total_bounds(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """GA 结果 HCP 全渠道 bounds — 验证约束在优化中被考虑"""
        opt = vo.ALGORITHM_REGISTRY.build("ga", config={
            "pop_size": 20, "n_generations": 15, "seed": 0, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        hcp_totals = genes.sum(axis=(0, 2))
        # GA 对随机初始解使用 repair，但不能保证每个 HCP 都在 bounds 内
        # 这里只验证约束结构正确、优化完成无报错
        assert len(hcp_totals) == N_HCPS
        assert np.all(hcp_totals >= 0)

    def test_ga_rep_total_bounds(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """GA 结果 Rep 全渠道 bounds"""
        opt = vo.ALGORITHM_REGISTRY.build("ga", config={
            "pop_size": 10, "n_generations": 5, "seed": 0, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        rep_totals = genes.sum(axis=(1, 2))
        for r in range(N_REPS):
            # GA 对随机初始解使用 repair，但不保证每个 rep 都在 bounds 内
            # 这里验证优化完成无报错，且 rep total 非负
            assert rep_totals[r] >= 0


# ═════════════════════════════════════════════════════════════════════════════
# 7. 输出维度与渠道验证
# ═════════════════════════════════════════════════════════════════════════════

class TestOutputDimensions:
    """验证输出维度 = rep × hcp × channel"""

    def test_finite_diff_output_channels(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """finite_diff 输出有 2 个渠道维度"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 5, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        assert genes.ndim == 3
        assert genes.shape[2] == N_CH  # 2 个渠道

    def test_ga_output_channels(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """GA 输出有 2 个渠道维度"""
        opt = vo.ALGORITHM_REGISTRY.build("ga", config={
            "pop_size": 10, "n_generations": 3, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        assert genes.ndim == 3
        assert genes.shape[2] == N_CH

    def test_channel_sum_breakdown(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """每个渠道的拜访总和可以独立计算"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 5, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes

        f2f_total = int(genes[:, :, 0].sum())
        online_total = int(genes[:, :, 1].sum())
        all_total = int(genes.sum())

        assert f2f_total >= 0
        assert online_total >= 0
        assert f2f_total + online_total == all_total

    def test_f2f_ratio_valid(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """f2f 占比在 [0, 1] 范围内"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 5, "seed": 42, "log_every": 999,
        })
        result = opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)
        genes = result.best_individual.genes
        total = float(genes.sum())
        if total > 0:
            f2f_ratio = float(genes[:, :, 0].sum()) / total
            assert 0.0 <= f2f_ratio <= 1.0


# ═════════════════════════════════════════════════════════════════════════════
# 8. 约束与优化结果汇总
# ═════════════════════════════════════════════════════════════════════════════

class TestOptimizationSummary:
    """优化结果汇总（用于生成 test_v7.md）"""

    @pytest.fixture
    def fd_result(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """运行 finite_diff 优化获取结果"""
        opt = vo.ALGORITHM_REGISTRY.build("finite_diff", config={
            "n_iterations": 20,
            "step": 1,
            "penalty_weight": 1.0,
            "seed": 42,
            "log_every": 999,
        })
        return opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)

    @pytest.fixture
    def ga_result(self, mock_evaluator, ctx, hard_constraints, soft_constraints):
        """运行 GA 优化获取结果"""
        opt = vo.ALGORITHM_REGISTRY.build("ga", config={
            "pop_size": 20,
            "n_generations": 10,
            "seed": 42,
            "log_every": 999,
            "oversample_ratio": 10,
        })
        return opt.optimize(ctx, mock_evaluator, hard_constraints, soft_constraints)

    def test_fd_summary(self, fd_result, request):
        """finite_diff 结果汇总"""
        genes = fd_result.best_individual.genes
        info = {
            "algorithm": "finite_diff",
            "brand_id": fd_result.brand_id,
            "fitness": fd_result.best_individual.fitness,
            "penalty": fd_result.best_individual.penalty,
            "total_visits": int(genes.sum()),
            "f2f_total": int(genes[:, :, 0].sum()),
            "online_event_total": int(genes[:, :, 1].sum()),
            "f2f_ratio": float(genes[:, :, 0].sum() / max(genes.sum(), 1)),
            "shape": tuple(genes.shape),
            "iterations": fd_result.iterations_run,
        }

        # 保存到 pytest 标记中，供 report 使用
        request.node._summary = info

        assert np.isfinite(info["fitness"])
        assert info["total_visits"] > 0
        assert info["shape"] == (N_REPS, N_HCPS, N_CH)
        assert 0.0 <= info["f2f_ratio"] <= 1.0

    def test_ga_summary(self, ga_result, request):
        """GA 结果汇总"""
        genes = ga_result.best_individual.genes
        info = {
            "algorithm": "ga",
            "brand_id": ga_result.brand_id,
            "fitness": ga_result.best_individual.fitness,
            "penalty": ga_result.best_individual.penalty,
            "total_visits": int(genes.sum()),
            "f2f_total": int(genes[:, :, 0].sum()),
            "online_event_total": int(genes[:, :, 1].sum()),
            "f2f_ratio": float(genes[:, :, 0].sum() / max(genes.sum(), 1)),
            "shape": tuple(genes.shape),
            "iterations": ga_result.iterations_run,
        }

        request.node._summary = info

        assert np.isfinite(info["fitness"])
        assert info["total_visits"] > 0
        assert info["shape"] == (N_REPS, N_HCPS, N_CH)

    def test_fd_per_hcp_breakdown(self, fd_result, request):
        """finite_diff 每 HCP 拜访汇总"""
        genes = fd_result.best_individual.genes
        hcp_totals = genes.sum(axis=(0, 2))
        breakdown = []
        for h in range(N_HCPS):
            breakdown.append({
                "hcp": f"hcp{h}",
                "segment": HCP_SEGMENTS[h],
                "total": int(hcp_totals[h]),
                "f2f": int(genes[:, h, 0].sum()),
                "online_event": int(genes[:, h, 1].sum()),
                "lo": int(HCP_TOTAL_BOUNDS[h, 0]),
                "hi": int(HCP_TOTAL_BOUNDS[h, 1]),
                "within_bounds": HCP_TOTAL_BOUNDS[h, 0] <= hcp_totals[h] <= HCP_TOTAL_BOUNDS[h, 1] + 1,
            })
        request.node._breakdown = breakdown
        # 至少 80% 的 HCP 在 bounds 内（+1 容差）
        within = sum(1 for b in breakdown if b["within_bounds"])
        assert within >= N_HCPS * 0.8

    def test_fd_per_rep_breakdown(self, fd_result, request):
        """finite_diff 每 Rep 拜访汇总"""
        genes = fd_result.best_individual.genes
        rep_totals = genes.sum(axis=(1, 2))
        breakdown = []
        for r in range(N_REPS):
            breakdown.append({
                "rep": f"rep{r}",
                "total": int(rep_totals[r]),
                "f2f": int(genes[r, :, 0].sum()),
                "online_event": int(genes[r, :, 1].sum()),
                "lo": int(REP_TOTAL_BOUNDS[r, 0]),
                "hi": int(REP_TOTAL_BOUNDS[r, 1]),
                "within_bounds": REP_TOTAL_BOUNDS[r, 0] <= rep_totals[r] <= REP_TOTAL_BOUNDS[r, 1] + 1,
            })
        request.node._breakdown = breakdown
        # 检查至少一半的 Rep 大致在合理范围（+容差，因初始随机可能不满足下限）
        within = sum(1 for b in breakdown if b["total"] <= b["hi"] + 5)
        assert within >= N_REPS * 0.5

    def test_fd_soft_penalty_breakdown(self, fd_result, ctx, soft_constraints, request):
        """finite_diff 各软约束惩罚分解"""
        ind = fd_result.best_individual
        penalties = []
        for c in soft_constraints:
            pen = c.penalty(ind, ctx)
            penalties.append({
                "name": c.__class__.__name__,
                "weight": c.weight,
                "penalty": pen,
                "raw_penalty": c.raw_penalty(ind, ctx),
                "normalized": c.normalize(c.raw_penalty(ind, ctx), ctx),
            })
        request.node._penalties = penalties
        # 每个惩罚 >= 0
        for p in penalties:
            assert p["penalty"] >= 0
