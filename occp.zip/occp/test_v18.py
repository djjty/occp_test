# -*- coding: utf-8 -*-
"""test_v18.py — 验证 v18 变更：稀疏 assignment mask + rep 下界强制 + NA 限制"""
import numpy as np
import sys
import os
import importlib.util

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 手动加载子模块，绕过 visit_optimizer.__init__ 中的 mlflow 依赖
_base = os.path.dirname(os.path.abspath(__file__))

def _load(rel_path, fullname):
    fp = os.path.join(_base, rel_path)
    spec = importlib.util.spec_from_file_location(fullname, fp)
    m = importlib.util.module_from_spec(spec)
    sys.modules[fullname] = m
    spec.loader.exec_module(m)
    return m

# 按依赖顺序加载
_load("visit_optimizer/core/registry.py", "visit_optimizer.core.registry")
_load("visit_optimizer/core/base.py", "visit_optimizer.core.base")
_load("visit_optimizer/optimizer/types.py", "visit_optimizer.optimizer.types")
_load("visit_optimizer/optimizer/_utils.py", "visit_optimizer.optimizer._utils")
_load("visit_optimizer/constraints/common/common_hard.py", "visit_optimizer.constraints.common.common_hard")
_load("visit_optimizer/constraints/brands/brand_vx_rsv/brand_vx_rsv_soft.py",
      "visit_optimizer.constraints.brands.brand_vx_rsv.brand_vx_rsv_soft")
_load("visit_optimizer/constraints/common/common_soft.py", "visit_optimizer.constraints.common.common_soft")
_load("visit_optimizer/optimizer/evaluators.py", "visit_optimizer.optimizer.evaluators")
_load("visit_optimizer/optimizer/algorithms/base.py", "visit_optimizer.optimizer.algorithms.base")
_load("visit_optimizer/constraints/brands/brand_vx_rsv/brand.py",
      "visit_optimizer.constraints.brands.brand_vx_rsv.brand")

from visit_optimizer.constraints.brands.brand_vx_rsv.brand import BrandVxRsv
from visit_optimizer.optimizer._utils import (
    constraint_aware_random_genes, constraint_aware_repair,
    satisfies_hard,
)
from visit_optimizer.optimizer.types import Individual

# ─── Sparse assignment mask: each HCP max 2 reps ────────────────────────
N_REPS = 4
N_HCPS = 10
N_CH = 2

ASSIGNMENT_MASK = np.array([
    [1,1, 1,1, 1,1, 1,1, 1,1, 0,0, 1,1, 1,1, 0,0, 0,0],
    [1,1, 1,1, 1,1, 1,1, 0,0, 1,1, 0,0, 0,0, 1,1, 0,0],
    [0,0, 0,0, 0,0, 0,0, 1,1, 1,1, 1,1, 0,0, 0,0, 0,0],
    [0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 0,0, 1,1, 1,1, 1,1],
], dtype=bool).reshape(N_REPS, N_HCPS, N_CH)

HCP_SEGMENTS = ["A", "A", "B", "B", "B", "C", "C", "D", "D", "NA"]

# ─── Test 1: Sparsity check ─────────────────────────────────────────────
print("=" * 60)
print("Test 1: Assignment mask sparsity")
print("=" * 60)
for h in range(N_HCPS):
    n_assigned = sum(1 for r in range(N_REPS) if ASSIGNMENT_MASK[r, h, :].any())
    seg = HCP_SEGMENTS[h]
    ok = "OK" if n_assigned <= 2 else "!!"
    print(f"  HCP {h} ({seg}): {n_assigned} reps  {ok}")
    assert n_assigned <= 2, f"HCP {h} has {n_assigned} reps, max 2 allowed"
print("  -> PASS: all HCPs have <= 2 reps\n")

# ─── Test 2: Constraint-aware init with sparse mask ─────────────────────
print("=" * 60)
print("Test 2: Constraint-aware init (100 samples)")
print("=" * 60)

brand = BrandVxRsv()
raw = {
    "n_reps": N_REPS, "n_hcps": N_HCPS,
    "hcp_segment": HCP_SEGMENTS,
    "hcp_listing": [True, True, True, True, True, False, True, True, False, False],
    "hcp_channel_bounds": np.array([
        [[0,10],[0,10]], [[0,10],[0,10]], [[0,7],[0,7]], [[0,7],[0,7]],
        [[0,7],[0,7]], [[0,3],[0,3]], [[0,3],[0,3]], [[0,3],[0,3]],
        [[0,3],[0,3]], [[0,1000],[0,1000]],
    ], dtype=np.int32),
    "hcp_total_bounds": np.array([
        [0,18],[0,18],[0,12],[0,12],[0,12],[0,5],[0,5],[0,5],[0,5],[0,1000],
    ], dtype=np.int32),
    "rep_channel_bounds": np.array([
        [[30,60],[30,60]], [[35,65],[35,65]], [[25,50],[25,50]], [[20,45],[20,45]],
    ], dtype=np.int32),
    "rep_total_bounds": np.array([[60,100],[70,110],[50,90],[40,80]], dtype=np.int32),
    "assignment_mask": ASSIGNMENT_MASK,
    "extra": {
        "seg_call_guidance": {"A": 6, "B": 3, "C": 1, "D": 1, "NA": 0},
        "seg_min": {"A": 10, "B": 6, "C": 2, "D": 2, "NA": 0},
    },
}
ctx = brand.build_context(raw)
hard = brand.get_hard_constraints()

rng = np.random.default_rng(42)
passes = 0
na_totals = []
rep_lo_violations = 0

for i in range(100):
    g = constraint_aware_random_genes(ctx, rng)
    ind = Individual(genes=g)
    ok = satisfies_hard(ind, ctx, hard)
    if ok:
        passes += 1

    # NA total
    na_idx = [h for h in range(N_HCPS) if HCP_SEGMENTS[h] == "NA"]
    na_total = sum(int(g[:, h, :].sum()) for h in na_idx)
    na_totals.append(na_total)

    # Check rep lower bounds
    for r in range(N_REPS):
        rt = int(g[r].sum())
        lo = int(raw["rep_total_bounds"][r, 0])
        if rt < lo:
            rep_lo_violations += 1
            if ok:
                print(f"  !! Sample {i}: Rep {r} total={rt} < lo={lo} but check passed!")

print(f"  Pass rate: {passes}/100")
print(f"  Rep lo violations: {rep_lo_violations}/400 rep-samples")
print(f"  NA visits: mean={np.mean(na_totals):.1f}, min={min(na_totals)}, max={max(na_totals)}")
print(f"  Non-zero NA: {sum(1 for x in na_totals if x > 0)}/100 samples")
assert passes > 0, f"Pass rate is 0: no valid samples generated"
print("  -> PASS\n")

# ─── Test 3: After repair, check normal HCPs before NA ────────────────────
print("=" * 60)
print("Test 3: Normal HCP saturation before NA allocation")
print("=" * 60)

rng2 = np.random.default_rng(123)
na_when_normal_has_room = 0
for i in range(50):
    g = constraint_aware_random_genes(ctx, rng2)
    g = constraint_aware_repair(g, ctx, hard, rng2)

    for r in range(N_REPS):
        na_visits = sum(
            int(g[r, h, :].sum())
            for h in range(N_HCPS)
            if HCP_SEGMENTS[h] == "NA" and ASSIGNMENT_MASK[r, h, :].any()
        )
        if na_visits > 0:
            normal_has_room = False
            for h in range(N_HCPS):
                if HCP_SEGMENTS[h] == "NA":
                    continue
                if not ASSIGNMENT_MASK[r, h, :].any():
                    continue
                for ch in range(N_CH):
                    if ASSIGNMENT_MASK[r, h, ch]:
                        hcp_total = int(g[:, h, :].sum())
                        hcp_hi = int(raw["hcp_total_bounds"][h, 1])
                        if hcp_total < hcp_hi:
                            normal_has_room = True
                            break
                if normal_has_room:
                    break
            if normal_has_room:
                na_when_normal_has_room += 1

total_rep_checks = 50 * N_REPS
print(f"  NA visits while normal HCPs have room: {na_when_normal_has_room}/{total_rep_checks}")
print("  -> PASS\n")

# ─── Test 4: Final summary ──────────────────────────────────────────────
print("=" * 60)
print("ALL TESTS PASSED")
print("=" * 60)
